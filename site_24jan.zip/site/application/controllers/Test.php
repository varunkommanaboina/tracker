<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Test extends CI_Controller {

		public function index()
		{ 
			$this->load->view('template/home.php');
		}
//-------------------------------------------------------------------
		public function output(){
	
			//$toupdate = $this ->mongo_db->select(array('port'),array('_id'))->get('test');
			$data= $this->mongo_db->select(array('comments'),array('_id'))
			->where(array('_id' => new MongoId('5c23f3835d5bac701f000029')))->get('web');
			if (count($data) > 0){
			echo '<pre>';
			print_r($data);
			echo '</pre>';
			//echo base_url();
			//echo $data[0]['_id'];
			}
			else
			{
			}
		}
//-------------------------------------------------------------------
		public function table1(){
		$this->load->library('table');

		$this->table->set_heading('Name', 'Color', 'Size');
		$this->table->add_row('Fred', 'Blue', 'Small');
		$this->table->add_row('Mary', 'Red', 'Large');
		$this->table->add_row('John', 'Green', 'Medium');
		
		echo $this->table->generate();
		
		$this->table->clear();
		
		$this->table->set_heading('Name', 'Day', 'Delivery');
		$this->table->add_row('Fred', 'Wednesday', 'Express');
		$this->table->add_row('Mary', 'Monday', 'Air');
		$this->table->add_row('John', 'Saturday', 'Overnight');
		
		echo $this->table->generate(); 
		
		}
//-------------------------------------------------------------------
		public function calender(){
			$this->load->library('calendar');

			$prefs = array(
				'show_next_prev'  => TRUE,
				'next_prev_url'   => 'http://example.com/index.php/calendar/show/'
		);
		
		$this->load->library('calendar', $prefs);
		
		echo $this->calendar->generate($this->uri->segment(3), $this->uri->segment(4));
		}

//-------------------------------------------------------------------

		public function date(){
			
			//$toupdate = $this ->mongo_db->select(array('port'),array('_id'))->get('test');
			$data= $this->mongo_db->select(array(),array('comments'))
			->where_between('date', '2018-11-08 00:00:01','2018-11-09 00:00:13' )->get('shiftRegister');
		
			echo '<pre>';
			print_r($data);
			echo '</pre>';
		
		}
		
//-------------------------------------------------------------------
		public function query_return(){
			$query = $this->mongo_db->get_where('test', array('name' => 'varudasdn'));
			if(count($query) > 0){
				echo 'true';
			} else {
				return false;
			}
		}



//-------------------------------------------------------------------
		public function data_table_cotroller(){
			$collection =$_POST["collection"];
			$object =$_POST["object"];
			$id =$_POST["id"];
		
			$data['data']=$this->Data_tables->sub_object($collection,$object,$id);
	
			echo json_encode($data['data'][0]);
		
		}


		public function data_tables_page(){
			
			$data['collection']=$this->uri->segment(3, 0);
			$data['object']=$this->uri->segment(4, 0);
			$data['id']=$this->uri->segment(5, 0);
			
			
			
				// http://localhost:81/site/home/data_tables_page/VM/port/5c2680d45d5bac6011000029
			
			$data['title'] = 'table';
			$data['path'] = base_url().'test/data_table_cotroller';
				$this->load->view('main_pages/template/header', $data);
				$this->load->view('main_pages/table',$data);
				$this->load->view('main_pages/template/footer');
		}
		


//--------------------------------------------------------------------------



		public function json2csv(){

			//reference https://gist.github.com/jakebathman/4fb8c55b13272eee9c88
			$this->load->view('test_pages/json2csv');
		}


//--------------------------------------------------------------------------

		public function query_return2(){
			$query = $this->mongo_db->get_where('VM', array('port.portNo' => '8083'));
			//$query = $this->mongo_db->where_in('port',array('portNo'=>'80'))->get('VM');
			echo '<pre>';
			print_r($query);
			echo '</pre>';
		}

		
//--------------------------------------------------------------------------
		public function web(){
			$data['data']= $this->mongo_db->where(array('_id' => new MongoId('5c23f3835d5bac701f000029')))->get('web');
			if (count($data) > 0){
				$title['title']= 'website details';
				$this->load->view('main_pages/template/header',$title);
				$this->load->view('test_pages/web', $data);
				$this->load->view('main_pages/template/footer');
			}
			else
			{

			}
		}

		public function esxi(){
			$data['data']= $this->mongo_db->where(array('_id' => new MongoId('5be48402275b2f5016000043')))->get('ESXI');
			if (count($data) > 0){
				$title['title']= 'ESXI Details';
				$this->load->view('main_pages/template/header',$title);
				$this->load->view('test_pages/esxi', $data);
				$this->load->view('main_pages/template/footer');
			}
			else
			{

			}
		}

		public function vm(){
			$data['data']= $this->mongo_db->where(array('_id' => new MongoId('5c2680d45d5bac6011000029')))->get('VM');
			if (count($data) > 0){
				$title['title']= 'Virtual Machine Details';
				$this->load->view('main_pages/template/header',$title);
				$this->load->view('test_pages/vm', $data);
				$this->load->view('main_pages/template/footer');
			}
			else
			{

			}
		}


 //--------------------------------------------------------
			public function test_uri(){
				$str ='dasdsad.das.d.asd.as.dsa.d.sad.sad.';
				$da= explode('.',$str);
				echo $da[5];
			}


			public function dis(){

			//	$data['data'] =$this->mongo_db->distinct('ESXI','cloud');
				$data= $this->mongo_db->select(array('cloud'))->get('ESXI');
				echo '<pre>';
				print_r($data);
				echo '</pre>';
			}

			public function insert(){
					////outputs the inserted documnet mongoID 



				$data = array(
					'cloud' => $this->input->post('cloud'),
					'serverName' => $this->input->post('server_name'),
					'serverIp' =>"",
					"vms"=>array(),
					"hardware"=>(object)array(
							  "ram"=>"",
							  "HDD"=>"",
							  "processor"=>""
					),
					"SrNo"=>array()
							
			   
				);

				$data= $this->mongo_db->insert('test',$data);

				echo $data;

			}


			

}


