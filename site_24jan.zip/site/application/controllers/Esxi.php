<?php
	class ESXI extends CI_Controller{
		
		
		public function insert(){


					$this->form_validation->set_rules('vm_name', 'vm_name', 'required');
					$this->form_validation->set_rules('esxi_id', 'esxi_id', 'required');
					
					if($this->form_validation->run() === FALSE){

											
					} else {
						$this->collection->add_vm();
						// Set message
						$this->session->set_flashdata('added_VM', 'esxi server is created');
						redirect('details/all/ESXI');
						
					}


		}

		
       
    }   