<?php
class Collection extends CI_Model{
	
		public function get($collection,$id){
			
			
			
			$data['data'] =$this->mongo_db->where(array('_id' => new MongoId($id)))->get($collection);
			
				if (count($data) > 0){
				return $data['data'];
				}
				else
				{
					return false;
				}

		}

		public function all($collection){
			$data['data'] =$this->mongo_db->order_by(array('cloud' => 'ASC'))->get($collection);

			if (count($data) > 0){
				return $data['data'];
				}
				else
				{
					return false;
				}
		}

		public function add_esxi(){

			$data = array(
				'cloud' => $this->input->post('cloud'),
				'serverName' => $this->input->post('server_name'),
				'serverIp' =>"",
				"vms"=>array(),
				"hardware"=>(object)array(
						  "ram"=>"",
						  "HDD"=>"",
						  "processor"=>""
				),
				"SrNo"=>array()
						
           
			);

			// Insert user
			return $this->mongo_db->insert('ESXI', $data);
		}


		public function add_vm(){

			$data = array(
				"VMFunction"=>$this->input->post('vm_name'),
				"hostName"=>"GSDCDEPTAPP02",
				"vHardware"=>(object)array(
				  "ram"=>"3GB",
				  "HDD"=>"200",
				  "processor"=>"value"),
			  
				"serverType"=>"staging",
				"RDlogins"=>(object)array(
						"usertype"=>"sdc",
						"username"=>"varun",
				  ),
				"ips"=>(object)array(
				  "public"=>"10.189.47.75",
				  "private"=>"10.189.47.75",
				  "gateway"=>"10.189.47.75"
				),
				"port"=>(object)array(
					  (object)array(
						"portNo"=>"80",
						"portName"=>"http",
						"reqBy"=>"client",
						"reason"=>"test",
						"timePeriod"=>"1hr",
						"securityThreat"=>"sql injection",
						"from"=>"10.189.47.75",
						"to"=>"10.189.47.74"
					  ),
					  (object)array(
						"portNo"=>"8080",
						"portName"=>"http",
						"reqBy"=>"client",
						"reason"=>"test",
						"timePeriod"=>"1hr",
						"securityThreat"=>"sql injection",
						"from"=>"10.189.47.75",
						"to"=>"10.189.47.74"
						)
				  ),
				"internet"=>"yes",
				"os"=>"windows 2012R2",
				"patches"=>(object)array(
				  "patch"=>"patch id collection",
				  "date"=>"12-07-1018",
				  "updatedBy"=>"arjun",
				  "status"=>"yes",
				  "comments"=>"comments"
				),
				"softwaresInstalled"=>(object)array(
				  array("name"=>"wamp","licence"=>"no","remarks"=>"text"),
				  array("name"=>"ms sql","licence"=>"yes","remarks"=>"text")
				),
				"antiVirus"=>(object)array(
				  "antiVirus"=>"type",
				  "licence"=>"text",
				  "expiryDate"=>new MongoDate()
				),
				"storage"=>(object)array(
				  "Backupdate"=>new MongoDate(),
				  "sourcecodeDir"=>"string",
				  "sourcecodeDirSize"=>"1GB",
				  "backupTap"=>"yes",
				  "backupToTapeOn"=>new MongoDate(),
				  "backupToTapeby"=>"text",
				  ),
				"webapps"=>array("32423rfwer4324","32423rfwer4324","32423rfwer4324","32423rfwer4324"),
				"servicerReqNo"=>array(434344,43243,4234,34324),
				"visits"=>array(4324432432,4324234234,42342342343),
				"comments"=>(object)array(
				  "commentby"=>"varun",
				  "date"=>new MongoDate(),
				  "comment"=>"dsadas"),
				"clone"=>(object)array(
				  "name"=>"webserverclone2",
				  "date"=>new MongoDate()
				  )
			  
			  );
			  

			// Insert user
			$mongo_id = $this->mongo_db->insert('VM', $data);
			$this->mongo_db->where(array('_id'=>new MongoId($this->input->post('esxi_id'))))->push('vms',$mongo_id )->update('ESXI');
		}

}

	