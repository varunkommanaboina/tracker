


<div class="w3-third" >
               



                 <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

                <header class="w3-container w3-blue">
                <h5 class="w3-left"><b>Server Details</b></h5> 
                <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
                </header>

                <div class="w3-container" style="padding-top:5px;">
                <p>Cloud : <?php echo $data[0]['cloud'] ?></p>
                <p>Server Name : <?php echo $data[0]['serverName'] ?> </p>
                <p>Server IP : <?php echo $data[0]['serverIp'] ?> </p>
                             
                </div>
                </div>


            <div class="w3-card-4"   style="margin:0px 5px 10px 5px">
            <header class="w3-container w3-blue">
            <h5 class="w3-left"><b>hardware</b></h5> 
            <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
            </header>

            <div class="w3-container" style="padding-top:5px;">
            <p>RAM:  <?php echo $data[0]['hardware']['ram'] ?></p>
            <p>HDD:  <?php echo $data[0]['hardware']['HDD'] ?></p>
            <p>Processor :  <?php echo $data[0]['hardware']['processor'] ?></p>
            </div>

            </div>



                
                <div class="w3-card-4"  style="margin:0px 5px 10px 5px" >

                <header class="w3-container w3-blue">
                <h5 class="w3-left"><b>Logs</b></h5> 
                <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
                </header>

                <div class="w3-container" style="padding-top:5px;">
                <p>Service Requests  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
                <p>Comments    <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
                 <p>Tracker Logs  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
                </div>

                </div>

</div>



<div class="w3-third" >
               



               <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

              <header class="w3-container w3-blue">
              <h5 class="w3-left"><b>Virtual Machines</b></h5> 
              <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
              </header>

              <div class="w3-container" style="padding-top:5px;">
              <p>webserver 2  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
              <p>webserver 2  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
              <p>webserver 2  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
              <p>webserver 2  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
              <p>webserver 2  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
              <p>webserver 2  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
              <p>webserver 2  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
              <p>webserver 2  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
              <p>webserver 2  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>

                           
              </div>
              </div>
              
</div>


