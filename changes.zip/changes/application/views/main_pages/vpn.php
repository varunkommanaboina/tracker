
		



<style>





table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #4CAF50;
  color: white;
}




</style>


<div class="w3-card-4"  style="margin:0px 5px 10px 5px">

		<header class="w3-container w3-blue">
		<p><b class="w3-left" style="padding-top:10px">
					<?php if($this->uri->segment(3, 0) ==! ''){ echo $this->uri->segment(3, 0); }else {echo '';} ?>
			</b>
			<b class="w3-right" style="padding:5px 0px">
			<a  style="width:100%;text-decoration:none;padding:5px 10px;" href="#" onclick="addnew()" class="w3-btn w3-teal">ADD NEW</a>
			</b>
			
			</p> 

		</header>


			<div class="w3-container" style="padding-top:5px;">
										
							
						<?php

							
	

							echo '<table>
								<tr>
								<th>Destnation</th>
								<th>VmName</th>
								<th>Service</th>
								<th>vpn_username</th>
								<th>remark</th>
								<th>delete</th>
								<th>edit</th>
								<th>file</th>
								</tr>';
							
							$arrlength = count($data);
							
							$x=0;


							for ($i=0;$i<$arrlength;$i++){

								$x++;

								echo '<tr>';
								
								echo	'<td>'.$data[$i]['destination'].'</td>';
								echo 	'<td>'.$data[$i]['VmName'].'</td>';
								echo 	'<td>'.$data[$i]['service'].'</td>';
								echo 	'<td>'.$data[$i]['vpn_username'].'</td>';
								echo 	'<td>'.$data[$i]['remark'].'</td>';
								echo 	'<td><i class="fas fa-trash w3-button w3-circle w3-red w3-hover-red" onclick="delete_p(\''.$data[$i]['vpno'].'\')" style="margin-top:3px;padding:8px"></i></td>';
								echo 	'<td><a href="'.base_url().'VM/vpn_edit_page/'.$data[$i]['vpno'].'"<i class="fas fa-edit w3-button w3-circle w3-green w3-hover-black"  style="margin-top:3px;padding:8px"></i></a></td>';
								echo  '<td><a href="'.base_url().'uploads/lou/'.$data[$i]['LOU'].'" ><i class="fas fa-external-link-alt w3-button w3-circle w3-green w3-hover-black"  style="margin-top:3px;padding:8px"></i></a></td>';
								echo '</tr>'; 
								


							}

							echo '</table>'
						

 
						

						?>
							<br>

			
							

  





			</div>








</div>

<script>


function delete_p(id) {
	document.getElementById("popup_title_delete").innerHTML ="#"+id;
	document.getElementById("did").value =id;

	document.getElementById('id04').style.display="block";

}

function addnew() {
document.getElementById('id03').style.display="block";
}


</script>

 <script src="<?php echo base_url();?>assets/ckeditor/ckeditor.js"></script>

<style>

label {    
	font-weight: 200;
	margin-bottom: 0px;
	margin-top:0px;

}

.w3-input {
    padding: 2px;
}

</style>
 
<div id="id03" class="w3-modal" style="padding-top:10px;">
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:80%;">
                    <header class="w3-container w3-green"> 
                        <span onclick="document.getElementById('id03').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Add New VPN login</h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
											<?php echo validation_errors(); ?>
                            <?php echo form_open_multipart('VM/add_vpn'); ?>

								<div class="w3-half" style="padding:10px;">
								
								<p>
								<label>Destination</label>
								<input class="w3-input" type="text" name="destination" value="<?php if($this->uri->segment(3, 0) ==! ''){ echo $this->uri->segment(3, 0); }else {echo '';} ?>"></p>
								<p>

								<p>
								<label>VPN Type</label>
								<input class="w3-input" type="text" name="type"  ></p>

								<p>
								<label>VM Name</label>
								<input class="w3-input" type="text" name="vmname"  ></p>

								<p>
								<label>Service</label>
								<input class="w3-input" type="text" name="service"  ></p>

								<p>
								<label>Req By</label>
								<input class="w3-input" type="text" name="reqby"  ></p>

								<p>
								<label>Vendor</label>
								<input class="w3-input" type="text" name="vendor"  ></p>

								<p>
								<label>Effective from</label>
								<input class="w3-input" type="date" name="date"  ></p>
								

								</div>
								<div class="w3-half" style="padding:10px;">
							
								<p>
								<label>VPN Username</label>
								<input class="w3-input" type="text" name="vusername"  ></p>
								<p>
								<label>Server Username</label>
								<input class="w3-input" type="text" name="susername"  ></p>

							
								<p>
								<label>Contact</label>
								<input class="w3-input" type="text" name="contact"  ></p>

								<p>
								<label>LOU</label>
								<input class="w3-input" type="file" name="userfile"  ></p>

								<label>Remark</label>
								<textarea class="w3-input" type="text" name="remark" style="width: 538px; height: 212px;"></textarea></p>						

								<p>
								<input type="hidden" name="current" value="<?php echo current_url();?>">
							
								<input class="w3-button w3-round w3-teal" type="submit"></p>
								</div>
							<?php echo form_close();?>
							</form>
						
                        </div>

                          <footer class="w3-container w3-green">
                        <p></p>
                        </footer>
                </div>
</div>



<div id="id04" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:50%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id04').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4 id="popup_title_delete"></h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
						<?php echo validation_errors(); ?>
                            <?php echo form_open('VM/delete_vpn'); ?>
										<p style="font-size:20px;text-align:center;"><b>Are you sure want to delete this VPN login</b></p><br>
								<input type="hidden" name="current" value="<?php echo current_url();?>" >
								<input type="hidden" name="fid" id="did">

							
								
						
								<input class="w3-btn w3-round w3-red "  value="Yes" style="margin-top:5px;width:200px;margin-left:120px;" type="submit">
								<input class="w3-btn w3-round w3-blue w3-hover-blue" value="No" onclick="document.getElementById('id04').style.display='none'" style="margin-top:5px;margin-left:20px;">
								<?php echo form_close();?>
							</form>
							<br>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>
