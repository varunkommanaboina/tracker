<?php
	class Details extends CI_Controller{
		
		public function single(){
	
		$data['collection']=$this->uri->segment(3, 0);
		$data['id_original']=$this->uri->segment(4, 0);

		
		$data['id']= explode('.',$data['id_original']);
				
		if($data['collection']=='ESXI'){
		
			$title['title']='ESXI Details' ;
			$da =$data['id'][0];

		}else if($data['collection']=='VM'){
			$title['title']='<a href="'.base_url().'details/single/ESXI/'.$data['id'][0].'">ESXI</a> < VM  Details';
			$da =$data['id'][1];
			
		}else if($data['collection']=='web'){
			$title['title']='<a href="'.base_url().'details/single/ESXI/'.$data['id'][0].'">ESXI</a> < <a href="'.base_url().'details/single/VM/'.$data['id'][0].'.'.$data['id'][1].'">VM </a> < Web Details';
			$da =$data['id'][2];
		}

					$data['data']= $this->mongo_db->where(array('_id' => new MongoId($da)))->get($data['collection']);
					if (count($data) > 0){				


					
						
						

						
						$this->load->view('main_pages/template/header',$title);
						$this->load->view('main_pages/collections/'.$data['collection'], $data);
						$this->load->view('main_pages/template/footer');
					}
					else
					{

					}


		}

		
       
    }   