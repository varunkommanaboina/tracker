


<div class="w3-third" >
               



               <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

              <header class="w3-container w3-blue">
              <h5 class="w3-left"><b>Basic</b></h5> 
              <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
              </header>

              <div class="w3-container" style="padding-top:5px;">
              <p>VM Function : <?php echo $data[0]['VMFunction']?></p>
              <p>HostName : <?php echo $data[0]['hostName']?></p>
              <p>Server type : <?php echo $data[0]['serverType']?></p>
              <p>RD logins <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
            
             

                           
              </div>
              </div>

              
            <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

            <header class="w3-container w3-blue">
            <h5 class="w3-left"><b>Clone</b></h5> 
            <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
            </header>

            <div class="w3-container" style="padding-top:5px;">
           
            <p>Name: <?php echo $data[0]['clone']['name']?></p>
            <p>date: <?php echo $data[0]['clone']['date']?></p>
            <p>remark: remark</p>


                        
            </div>
            </div>


                        
             <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

            <header class="w3-container w3-blue">
            <h5 class="w3-left"><b>Virtual Hardware</b></h5> 
            <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
            </header>

            <div class="w3-container" style="padding-top:5px;">
            <p>RAM : <?php echo $data[0]['vHardware']['ram']?></p>
            <p>HDD : <?php echo $data[0]['vHardware']['HDD']?></p>
            <p>Provessor : <?php echo $data[0]['vHardware']['processor']?></p>
       

                        
            </div>
            </div>
                        
</div>



<div class="w3-third"  >
               



               <div class="w3-card-4"  style="margin:0px 5px 10px 5px; ">

              <header class="w3-container w3-blue">
              <h5 class="w3-left"><b>Softwares Info</b></h5> 
              <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
              </header>

              <div class="w3-container" style="padding-top:5px;">
              <p>Operationg system : <?php echo $data[0]['os']?></p>
              <p>Third party Softwares <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
              <p>Antivirus : yes <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
            
             

                           
              </div>
              </div>


            <div class="w3-card-4"  style="margin:0px 5px 10px 5px" >

            <header class="w3-container w3-blue">
            <h5 class="w3-left"><b>Network</b></h5> 
            <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
            </header>

            <div class="w3-container" style="padding-top:5px;">
            <p>Public IP : <?php echo $data[0]['ips']['public']?> <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
            <p>Private IP : <?php echo $data[0]['ips']['private']?></p>
            <p>Gateway IP : <?php echo $data[0]['ips']['gateway']?></p>
            <p>Internet : <?php echo $data[0]['internet']?></p>
            <p>Ports  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
          
            </div>

            </div>
                        
             <div class="w3-card-4"  style="margin:0px 5px 10px 5px" >

            <header class="w3-container w3-blue">
            <h5 class="w3-left"><b>Logs</b></h5> 
            <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
            </header>

            <div class="w3-container" style="padding-top:5px;">
            <p>Service Requests  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
            <p>Comments    <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
            <p>Visits  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
            <p>Storage  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
            <p>Tracker Logs  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
            </div>

            </div>



</div>




<div class="w3-third"  >
               



               <div class="w3-card-4"  style="margin:0px 5px 10px 5px; ">

              <header class="w3-container w3-blue">
              <h5 class="w3-left"><b>Websites/Applications</b></h5> 
              <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
              </header>

              <div class="w3-container" style="padding-top:5px;">
            
             
              <?php  foreach ($data[0]['webapps'] as $value) {

            $data['data']= $this->mongo_db->where(array('_id' => new MongoId($value)))->get('web');
            echo '<p><a href="'.base_url().'details/single/web/'.$id_original.'.'.$value.'">'.$data['data'][0]['url'].'<a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>';

              }
              ?>
             
            
              
              
             
            
            
             

                           
              </div>
              </div>


</div>



