
                      <br><?php echo validation_errors(); ?>
					             <?php echo form_open('users/login'); ?>
                        <div class="w3-section">
                          <label><b>Username</b></label>
                          <input class="w3-input w3-border w3-margin-bottom" type="text" placeholder="Enter Username" name="username" >
                          <label><b>Password</b></label>
                          <input class="w3-input w3-border" type="password" placeholder="Enter Password" name="password" >
						              <input class="w3-button w3-block w3-green w3-section w3-padding" type="submit" name="submit" value="Login">
                          
                        </div>
                      <?php echo form_close(); ?>

                       

