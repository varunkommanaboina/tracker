
<style>
a.card {
    text-decoration: none !important;
}

.w3-quarter{
    padding:0px 15px;

}
h4{
    padding:5px 0px !important;
}

</style>


<div class="w3-quarter" >

 
               <a class="card"  href="<?php echo base_url();?>details/all/ESXI" ><div class="w3-blue w3-center w3-hover-shadow w3-center" >
                <p><h3  style="padding:20px 5px;">Physical servers</h3></p>
                </div></a>

              <a class="card" href="" ><div class="w3-card w3-orange w3-center w3-hover-shadow w3-center" >
              <p><h3  style="padding:20px 5px;">Virtual Server</h3></p>
                </div></a>


               <a class="card" href="" ><div class="w3-card w3-red w3-center w3-hover-shadow w3-center" >
               <p><h3  style="padding:20px 5px;">Storage capacity</h3></p>
                </div></a>

                 <a class="card" href="" ><div class="w3-card w3-yellow w3-center w3-hover-shadow w3-center" >
                 <p><h3  style="padding:20px 5px;">Shift roster</h3></p>
                </div></a>


                <a class="card" href="" ><div class="w3-card w3-purple w3-center w3-hover-shadow w3-center" >
                <p><h3  style="padding:20px 5px;">Network Map</h3></p>
                </div></a>

                 <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                 <p><h3  style="padding:20px 5px;">Service Requests</h3></p>
                </div></a>

</div>






<div class="w3-quarter" >

              <a class="card"  href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p ><h3 style="padding:20px 5px;">Capacity Plan</h3></p>
                </div></a>

              <a class="card" href="" ><div class="w3-card w3-purple w3-center w3-hover-shadow w3-center" >
                <p ><h3 style="padding:20px 5px;">Server Availibility</h3></p>
                </div></a>


               <a class="card" href="" ><div class="w3-card w3-red w3-center w3-hover-shadow w3-center" >
                <p ><h3 style="padding:20px 5px;">Softwares</h3></p>
                </div></a>

                 <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p ><h3 style="padding:20px 5px;">Licencing</h3></p>
                </div></a>


                <a class="card" href="" ><div class="w3-card w3-orange w3-center w3-hover-shadow w3-center" >
                <p ><h3 style="padding:20px 5px;">Documentation</h3></p>
                </div></a>

                 <a class="card" href="" ><div class="w3-card w3-green w3-center w3-hover-shadow w3-center" >
                <p ><h3 style="padding:20px 5px;">KEDB</h3></p>
                </div></a>

</div>




<div class="w3-quarter" >

 
<a class="card"  href="<?php echo base_url();?>details/all/ESXI" ><div class="w3-blue w3-center w3-hover-shadow w3-center" >
 <p><h3  style="padding:20px 5px;">Physical servers</h3></p>
 </div></a>

<a class="card" href="" ><div class="w3-card w3-orange w3-center w3-hover-shadow w3-center" >
<p><h3  style="padding:20px 5px;">Virtual Server</h3></p>
 </div></a>


<a class="card" href="" ><div class="w3-card w3-red w3-center w3-hover-shadow w3-center" >
<p><h3  style="padding:20px 5px;">Storage capacity</h3></p>
 </div></a>

  <a class="card" href="" ><div class="w3-card w3-yellow w3-center w3-hover-shadow w3-center" >
  <p><h3  style="padding:20px 5px;">Shift roster</h3></p>
 </div></a>


 <a class="card" href="" ><div class="w3-card w3-purple w3-center w3-hover-shadow w3-center" >
 <p><h3  style="padding:20px 5px;">Network Map</h3></p>
 </div></a>

  <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
  <p><h3  style="padding:20px 5px;">Service Requests</h3></p>
 </div></a>

</div>


<div class="w3-quarter" >

<a class="card"  href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
  <p ><h3 style="padding:20px 5px;">Capacity Plan</h3></p>
  </div></a>

<a class="card" href="" ><div class="w3-card w3-purple w3-center w3-hover-shadow w3-center" >
  <p ><h3 style="padding:20px 5px;">Server Availibility</h3></p>
  </div></a>


 <a class="card" href="" ><div class="w3-card w3-red w3-center w3-hover-shadow w3-center" >
  <p ><h3 style="padding:20px 5px;">Softwares</h3></p>
  </div></a>

   <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
  <p ><h3 style="padding:20px 5px;">Licencing</h3></p>
  </div></a>


  <a class="card" href="" ><div class="w3-card w3-orange w3-center w3-hover-shadow w3-center" >
  <p ><h3 style="padding:20px 5px;">Documentation</h3></p>
  </div></a>

   <a class="card" href="" ><div class="w3-card w3-green w3-center w3-hover-shadow w3-center" >
  <p ><h3 style="padding:20px 5px;">KEDB</h3></p>
  </div></a>

</div>