<?php
	class ESXI extends CI_Controller{
		
		
				public function insert(){


							$this->form_validation->set_rules('vm_name', 'vm_name', 'required');
							$this->form_validation->set_rules('esxi_id', 'esxi_id', 'required');
							

							$current=$this->input->post('current'); 
							if($this->form_validation->run() === FALSE){
								redirect($current);
													 
							} else {

								$insert_type=$this->input->post('type');
								$id=$this->input->post('esxi_id');
								$name= $this->input->post('vm_name'); 
								if ($insert_type == "new"){	
												$data = array(
													"VMFunction"=>$this->input->post('vm_name'),
													"hostName"=>"",
													"vHardware"=>(object)array(
														"ram"=>"",
														"HDD"=>"",
														"processor"=>""),
													
													"serverType"=>"",
													"RDlogins"=>(object)array(
															"usertype"=>"",
															"username"=>"",
														),
													"ips"=>(object)array(
														"public"=>"",
														"private"=>"",
														"gateway"=>""
													),
													"port"=>(object)array(
															(object)array(
															"portNo"=>"",
															"portName"=>"",
															"reqBy"=>"",
															"reason"=>"",
															"timePeriod"=>"",
															"securityThreat"=>"",
															"from"=>"",
															"to"=>""
															)
														),
													"internet"=>"",
													"os"=>"windows 2012R2",
													"patches"=>(object)array(
														"patch"=>"patch id collection",
														"date"=>"12-07-1018",
														"updatedBy"=>"arjun",
														"status"=>"yes",
														"comments"=>"comments"
													),
													"softwaresInstalled"=>(object)array(
														array("name"=>"wamp","licence"=>"no","remarks"=>"text"),
														array("name"=>"ms sql","licence"=>"yes","remarks"=>"text")
													),
													"antiVirus"=>(object)array(
														"antiVirus"=>"type",
														"licence"=>"text",
														"expiryDate"=>"date"
													),
													"storage"=>(object)array(
														"Backupdate"=>"date",
														"sourcecodeDir"=>"",
														"sourcecodeDirSize"=>"",
														"backupTap"=>"yes",
														"backupToTapeOn"=>"date",
														"backupToTapeby"=>"",
														),
													"webapps"=>array(),
													"servicerReqNo"=>array(),
													"visits"=>array(),
													"comments"=>(object)array(
														(object)array(
														"commentId"=>"",
														"commentby"=>"",
														"date"=>"",
														"comment"=>"")
													),
													"trackerLogs"=>(object)array(
														(object)array(
															"date"=>"date",
															"log"=>"mytrackerLogssql",
														)
													),
													"clone"=>(object)array(
														"name"=>"",
														"date"=>"",
														"remarks"=>""
														)
													
													);
												$insert_id=$this->collection->insert('VM',$data);//create new VM doc
											
												$where=array('_id'=>new MongoId($id));
												$this->collection->push($insert_id,'ESXI',$where,'vms'); //push newly created VM Doc ID to ESXI vms array

												// Set message
												$this->session->set_flashdata('added_VM', 'esxi server is created');
												redirect('details/single/ESXI/'.$id);
												
											}else if ($insert_type == "migrate"){


																$result= $this->mongo_db->select(array('vms'))->where(array('_id' => new MongoId($id)))->get('ESXI');
																if(in_array(new MongoId($name),$result[0]['vms'])){
																	redirect('alredy exist $current');
																}else{
																		$where=array('_id'=>new MongoId($id));
																		$this->collection->push(new MongoId($name),'ESXI',$where,'vms'); 
																		// Set message
																		$this->session->set_flashdata('added_VM', 'esxi server is created');
																		redirect($current);
																}
							
							
											}
						}

				}

				public function edit_server(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
					$this->form_validation->set_rules('server_name', 'server name', 'required');
					$this->form_validation->set_rules('server_ip', 'server ip', 'required');

					
					if($this->form_validation->run() === FALSE){

													
					} else {

						$id=$this->input->post('esxi_id');
						$data=array(
						'cloud' => $this->input->post('cloud'),
						'serverName' => $this->input->post('server_name'),
						'serverIp' => $this->input->post('server_ip')          
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'ESXI');
						// Set message
						$this->session->set_flashdata('added_VM', 'esxi server is created');
						redirect('details/single/ESXI/'.$id);
						
					}



				}  

				public function edit_hardware(){
					$this->form_validation->set_rules('esxi_ram', 'Ram', 'required');
					$this->form_validation->set_rules('esxi_hdd', 'HDD', 'required');
					$this->form_validation->set_rules('esxi_processor', 'Processor', 'required');

					
					if($this->form_validation->run() === FALSE){

													
					} else {

						$id=$this->input->post('esxi_id');
						$data=array(
						'hardware.ram' => $this->input->post('esxi_ram'),
						'hardware.HDD' => $this->input->post('esxi_hdd'),
						'hardware.processor' => $this->input->post('esxi_processor')          
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'ESXI');
						// Set message
						$this->session->set_flashdata('added_VM', 'esxi server is created');
						redirect('details/single/ESXI/'.$id);
						
					}



				}  

				


		
       
    }   
