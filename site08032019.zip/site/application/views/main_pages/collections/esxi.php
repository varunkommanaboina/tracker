<style>
               .w3-hover-red:hover {
                  color: #fff!important;
                  background-color: #f44336!important;
               }
 </style>


<div class="w3-third" >
              



                 <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

                <header class="w3-container w3-blue">
                <h5 class="w3-left"><b>Server Details</b></h5> 
                <div class="w3-right"><b> 
                     <a href="#" onclick="document.getElementById('id01').style.display='block'"><i class="fas fa-edit w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a>
                     <a href="#"><i class="fas fa-trash w3-button w3-circle w3-hover-red" style="margin-top:3px;padding:8px"></i></a>
                </b></div>
                </header>

                <div class="w3-container" style="padding-top:5px;">
                <p>ID : <?php echo $data[0]['_id'] ?></p>
                <p>Cloud : <?php echo $data[0]['cloud'] ?></p>
                <p>Server Name : <?php echo $data[0]['serverName'] ?> </p>
                <p>Server IP : <?php echo $data[0]['serverIp'] ?> </p>
                             
                </div> 
                </div>


                <div class="w3-card-4"   style="margin:0px 5px 10px 5px">
                <header class="w3-container w3-blue">
                <h5 class="w3-left"><b>hardware</b></h5> 
                <div class="w3-right"><b>
                <a href="#" onclick="document.getElementById('id03').style.display='block'"><i class="fas fa-edit w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a></b>
                </header>

                <div class="w3-container" style="padding-top:5px;">
                <p>RAM:  <?php echo $data[0]['hardware']['ram'] ?></p>
                <p>HDD:  <?php echo $data[0]['hardware']['HDD'] ?></p>
                <p>Processor :  <?php echo $data[0]['hardware']['processor'] ?></p>
                </div>

                </div>



                
                <div class="w3-card-4"  style="margin:0px 5px 10px 5px" >

                <header class="w3-container w3-blue">
                <h5 class="w3-left"><b>Logs</b></h5> 
                
                </header>

                <div class="w3-container" style="padding-top:5px;">
                <p>Service Requests  <a href="<?php echo base_url().'logs/sr/ESXI/'.$data[0]['_id']?>" ><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
                <p>Comments    <a href="<?php echo base_url().'logs/comments/ESXI/'.$data[0]['_id']?>" ><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
                 <p>Tracker Logs  <a href="<?php echo base_url().'logs/tl/ESXI/'.$data[0]['_id']?>"><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
                </div>

                </div>


</div>



<div class="w3-third" >
               



               <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

                    <header class="w3-container w3-blue">
                    <h5 class="w3-left"><b>Virtual Machines</b></h5> 
                    <div class="w3-right"><b> 
                    <a href="#" onclick="document.getElementById('id02').style.display='block'"><i class="fas fa-plus w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a></b>
                            
                        </b></div>
                    </header>

                    <div class="w3-container" style="padding-top:5px;">

                    
                        <?php  foreach ($data[0]['vms'] as $value) {

                        $data1['data']= $this->mongo_db->where(array('_id' => new MongoId($value)))->get('VM');
                        echo '<p><a href="'.base_url().'details/single/VM/'.$id_original.'.'.$value.'">'.$data1['data'][0]['VMFunction'].'</a></p>';
        
        
                
                        }
                        ?>

                                
                    </div>
              </div>
              
</div>





 <div id="id01" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id01').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Update Server Details</h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('Esxi/edit_server'); ?>
                            <p>
                            <label>Select Cloud</label>
                            <select class="w3-select" name="cloud">
                                <?php 
                                

                                    
                                    foreach ($clouds as $cloud ){
                                       if($data[0]['cloud'] == $cloud){
                                           $selected ='selected';
                                          
                                           echo '<option   selected="'.$selected.' " value="'.$cloud.'">'.$cloud.'</option>';
                                       }else{
                                        echo '<option    " value="'.$cloud.'">'.$cloud.'</option>';
                                       }

                                        
                                    }
                                    
                                
                                ?>
                            </select>
                            </p>

                            <p>
                            <label>Server Name</label>
                            <input class="w3-input" type="text" name="server_name" value="<?php echo $data[0]['serverName']?>"></p>

                            <p>

                            <p>
                            <label>Server IP</label>
                            <input class="w3-input" type="text" name="server_ip" value="<?php echo $data[0]['serverIp']?>"></p>

                            <p>
                            <input type="hidden" name="esxi_id" value="<?php  echo $data[0]['_id'];?>">
                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>


 

 <div id="id02" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id02').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Add Virtual Machines</h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('Esxi/insert'); ?>

                            <input type="radio" name="type" value="new"> New &nbsp;
                            <input type="radio" name="type" value="migrate"> Migrate   
                          
                            <p>
                            <br>
                            <label>VM Name</label>
                            <input class="w3-input" type="text" name="vm_name"></p>
                            <input type="hidden" name="esxi_id" value="<?php  echo $data[0]['_id'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >
                            <p>
                            
                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>



 <div id="id03" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id03').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Update Hardware</h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('Esxi/edit_hardware'); ?>
                          
                            <p>
                            <label>RAM:</label>
                            <input class="w3-input" type="text" name="esxi_ram" value="<?php echo $data[0]['hardware']['ram']?>"></p>
                            <p>

                             <p>
                            <label>HDD:</label>
                            <input class="w3-input" type="text" name="esxi_hdd"  value="<?php echo $data[0]['hardware']['HDD']?>"></p>
                            <p>
                            <p>
                            <label>Processor</label>
                            <input class="w3-input" type="text" name="esxi_processor"  value="<?php echo $data[0]['hardware']['processor']?>"></p>
                            <p>
                            


                             <input type="hidden" name="esxi_id" value="<?php  echo $data[0]['_id'];?>">
                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>
