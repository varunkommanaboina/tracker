<?php
	class User_model extends CI_Model{
		public function register($enc_password){
			// User data array
			$data = array(
				'name' => $this->input->post('name'),
				'email' => $this->input->post('email'),
				'password' => $enc_password,
				'DOB' => '',
				'empid' => '',
				'DOJ' => '',
				'Plevel' => '',
				'dept' => '',
				'designation' => '',
				"locked"=>0,
				"gender"=>"",
				'username'=>(object)array('fname'=>'','lname'=>'')	
						
           
			);
			// Insert user
			return $this->mongo_db->insert('test', $data);
		} 
		public function login($username, $password){
			// Validate
		
			$data= $this->mongo_db->select(array(),array('zipcode'))
			->where(array('name' => $username,'password'=>$password))
			->get('test');
			if (count($data) > 0){
			return $data[0]['_id'];
			}
			else
			{
				return false;
			}
		}

		public function check_username_exists($Name){
			
			$query = $this->mongo_db->get_where('test', array('name' => $Name));
			if(count($query) > 0){
				return false;
			} else {
				return true;
			}
		}
		
		public function edituser(){

			
		}
	}