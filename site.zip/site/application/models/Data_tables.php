<?php
	class Data_tables extends CI_Model{
	
		public function sub_object($collection,$object,$id){
			//collection , what data, ID
			$data= $this->mongo_db->select(array($object),array('_id'))
			->where(array('_id' => new MongoId($id)))->get($collection);
		
			 
           return $data;
		}

	}


	