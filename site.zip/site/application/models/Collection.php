<?php
class Collection extends CI_Model{
	
		public function get($collection,$where,$select,$deselect,$order){			
			$data['data'] =$this->mongo_db->select($select,$deselect)->order_by($order)->where($where)->get($collection);
			
				if (count($data) > 0){
				return $data['data'];
				}
				else
				{
					return false;
				}

		}

		public function insert($collection,$data){
			return $this->mongo_db->insert($collection, $data);
		}


		public function edit($where,$data,$collection){
			return $this->mongo_db->where($where)->set($data)->update($collection);
		}

		
		public function push($data,$collection,$where,$field){	  
			return $this->mongo_db->where($where)->push($field,$data)->update($collection);
		}



		public function distinct($collection,$cloud){
			$data = $this->mongo_db->distinct($collection, $cloud);
			if (count($data)> 0){
				return $data;
			}else{
				return false;
			}
		}

		

}

	