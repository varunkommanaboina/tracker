
<h2><?= $title ?></h2>
<p><?php echo $message?></p>