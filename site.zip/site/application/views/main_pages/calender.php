


<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8' />
<link href='<?php echo base_url();?>assets/calender/fullcalendar/packages/core/main.css' rel='stylesheet' />
<link href='<?php echo base_url();?>assets/calender/fullcalendar/packages/daygrid/main.css' rel='stylesheet' />
<link href='<?php echo base_url();?>assets/calender/fullcalendar/packages/timegrid/main.css' rel='stylesheet' />
<link href='<?php echo base_url();?>assets/calender/fullcalendar/packages/list/main.css' rel='stylesheet' />
<script src='<?php echo base_url();?>assets/calender/fullcalendar/packages/core/main.js'></script>
<script src='<?php echo base_url();?>assets/calender/fullcalendar/packages/interaction/main.js'></script>
<script src='<?php echo base_url();?>assets/calender/fullcalendar/packages/daygrid/main.js'></script>
<script src='<?php echo base_url();?>assets/calender/fullcalendar/packages/timegrid/main.js'></script>
<script src='<?php echo base_url();?>assets/calender/fullcalendar/packages/list/main.js'></script>
<script>

  document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
      plugins: [ 'interaction', 'dayGrid', 'timeGrid', 'list' ],
      header: {
        left: 'prev,next today',
        center: 'title',
       // right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
        right: 'dayGridMonth,listMonth'
      },
     
      navLinks: true, // can click day/week names to navigate views
      businessHours: true, // display business hours
      defaultDate: '<?php echo date('m-d-Y');?>',
      editable: true,
            
      
      events: [
        {
          title: 'Business Lunch',
          start: '2019-03-03',
      
        }
        <?php
                    foreach ($data as $sample){
                        echo ',{';
                    echo "title:'ssl expiry: ".$sample['appName']."',";
                    
                    echo "start:'".$sample['ssl']['expiration']."'}";


                    
                //  echo json_encode($sample);
                
                }

        ?>
        ]

      
    });

    calendar.render();
  });

</script>
<style>



   #calendar {
            
            max-width: 670px;
            margin: auto 10px;
            font-size:11px;
            }

</style>
</head>
<body>

  <div id='calendar'></div>

</body>
</html>


