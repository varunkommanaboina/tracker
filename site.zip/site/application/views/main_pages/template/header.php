
<!DOCTYPE html>
<html>
<title>Home</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/w3.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/fa/web-fonts-with-css/css/fontawesome-all.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/fa/web-fonts-with-css/css/fa-solid.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">


<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
 <script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
 <link href="https://fonts.googleapis.com/css?family=Averia+Libre|Rammetto+One" rel="stylesheet">


<script defer src="<?php echo base_url(); ?>assets/css/fa/svg-with-js/js/fa-solid.js" integrity="sha384-+Ga2s7YBbhOD6nie0DzrZpJes+b2K1xkpKxTFFcx59QmVPaSA8c7pycsNaFwUK6l" crossorigin="anonymous"></script>
<script defer src="<?php echo base_url(); ?>assets/css/fa/svg-with-js/js/fontawesome.js" integrity="sha384-7ox8Q2yzO/uWircfojVuCQOZl+ZZBg2D2J5nkpLqzH1HY0C1dHlTKIbpRz/LG23c" crossorigin="anonymous"></script>
<body >

<style>
.w3-bar .w3-bar-item{
  padding:21px 16px;
}
.w3-button:hover {
    color: #000!important;
    background-color:  	#4CAF50 !important;
}

.w3-badge {
    font-size: 10px;
}
.w3-badge, .w3-tag {
    padding-left: 4px;
    padding-right: 3px;
    padding-top: 2px;
    padding-bottom: 2px;
}

</style>
<!-- Navigation Bar -->
<div class="w3-top">
    <div class="w3-bar  w3-light-grey w3-large w3-card">

      <div class="row">
        <!-- <a href="#" class="w3-bar-item w3-button w3-red w3-mobile">OrangeComp &nbsp;</a>-->

        <div class="col-sm-2"  style="width:10%;">
          <image src="<?php echo base_url(); ?>assets/css/logo.png" style="height:70px;"></image>
        </div>
        <div class="col-sm-10"  style="width:90%;">
            <div class="row" style="background-color:#4d636f;">
              <div class="w3-right" style="padding:0px 20px 0px 0px">
              
                <a href="#" class="btn" style="padding:3px 4px;" role="button"><i class="fas fa-envelope" style="font-size:22px;"><span class="w3-badge w3-red">1</span></i></a>
                <a href="#" class="btn" style="padding:3px 4px;" role="button"><i class="fas fa-bell" style="font-size:22px;"><span class="w3-badge w3-red">10</span></i></a>
                <a href="#" class="btn" style="padding:3px 4px;" role="button"><i class="fas fa-calendar-alt" style="font-size:22px;"><span class="w3-badge w3-red">10</span></i></a>
                <a href="#" class="btn" style="padding:3px 4px;" role="button"><i class="fas fa-question-circle" style="font-size:22px;"></i></a>
                <a href="#" class="btn" style="padding:3px 4px;" role="button"><i class="fas fa-phone" style="font-size:22px;"></i></a>
                <a href="#" class="btn" style="padding:3px 4px;" role="button"><i class="fas fa-cog" style="font-size:22px;"></i></a>
                <a href="<?php echo base_url();?>users/logout" class="btn" style="padding:3px 4px;" role="button"><i class="fas fa-power-off" style="font-size:22px;color:red;"></i></a>

              </div>
            </div>
            <div class="row" style="background-color:#f1f1f1;">
                <div class="w3-left" style="padding:0px 50px 0px 0px">LINK</div>
                <div class="w3-right" style="padding:0px 50px 0px 0px">
                      <div class="row" >

                                  <form>
                                    <div class="col-sm-10" style="width:68%;margin-top:6px;font-size:12px;">
                                        <input type="text" id="fname" name="fname">

                                    </div>
                                    <div class="col-sm-2" style="width:32%;margin:0px;">
                                          <button style="font-size:12px;padding:3px;margin-top:6px;" type="button" class="btn"><i class="fas fa-search" style="font-size:15px;"></i> </button>
                                    </div>
                                </form>



                      </div>

                </div>



            </div>

       </div>

      </div>


    </div>
</div>

<div class="w3-sidebar  w3-bar-block w3-teal w3-card" style="width:123px;margin-top:70px;">
  <div ><img src="<?php echo base_url(); ?>assets/css/avatar/a.png" class="w-padding" align="middle" alt="Norway" style="width:50%;border-radius: 45px;margin:5px 0px 0px 30px;"></div>
  <h5 style="text-align:center"><?php echo $this->session->userdata('username');?></h5>
  <button  class="w3-button w3-block w3-left-align" style="margin-top:5px;padding:2px 20px; ">
    <div style="float:left;"><i class="fas fa-home" style="font-size:19px;"></i></div>
      <div style="float:left;padding-left:5px;">Home</div>
      </button>

  <button class="w3-button w3-block w3-left-align" onclick="myAccFunc('network')" style="margin-top:5px;padding:2px 18px;">
  <div style="float:left;"><i class="fas fa-sitemap" style="font-size:18px"></i></div>
  <div style="float:left;padding-left:5px;">Network</div>
  </button>

  <button class="w3-button w3-block w3-left-align" onclick="myAccFunc('database')" style="margin-top:5px;padding:2px 18px; ">
 <div style="float:left;"><i class="fas fa-database" style="font-size:19px"></i></div>
 <div style="float:left;padding-left:6px;"> Database</div>
  </button>

  <button class="w3-button w3-block w3-left-align" onclick="myAccFunc('helpdesk')" style="margin-top:5px;padding:2px 18px;">

  <div style="float:left;"><i class="fas fa-desktop" style="font-size:18px"></i></div>
    <div style="float:left;padding-left:5px;">HelpDesk</div>


  </button>

  <button class="w3-button w3-block w3-left-align" onclick="myAccFunc('storage')" style="margin-top:5px;padding:2px 18px">
   <div style="float:left;"><i class="fas fa-minus-square" style="font-size:21px;"></i></div>
     <div style="float:left;padding-left:6px;">Storage</div>
  </button>



  <button class="w3-button w3-block w3-left-align" onclick="myAccFunc('server')" style="margin-top:5px;padding:2px 18px;">
  <div style="float:left;"><i class="fas fa-mobile" style="font-size:22px"></i></div>
    <div style="float:left;padding-left:7px;">&nbspServer</div>
  </button>

   <button class="w3-button w3-block w3-left-align" onclick="myAccFunc('bms')" style="margin-top:5px;padding:2px 18px;">
     <div style="float:left;"><i class="fas fa-video" style="font-size:18px"></i></div>
     <div style="float:left;padding-left:5px;">BMS</div>
  </button>




</div>