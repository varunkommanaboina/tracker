
		



<style>
table{

		width:100%;
}

th{
	text-align: right;
    background: #f4f4ee;
    padding: 1px 8px;
    color: #666;
	border: 2px solid #fff;
}

td {
    background: #e3ebe2;
    padding: 1px 8px;
}

tr {
	border: 2px solid #fff;

}

</style>

 <script src="<?php echo base_url();?>assets/ckeditor/ckeditor.js"></script>


<div class="w3" >
              






			  <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

					<header class="w3-container w3-blue">
					<h5 class="w3-left"><b>
                 <?php
                    if ($collection == 'ESXI'){
					echo 'ESXI : '.$data[0]['serverName'];
                    
                }


                ?>
                    
                    </b></h5> 
					
					</header>

						<div class="w3-container" style="padding-top:5px;">

							
						<?php
							$tracker_all =$data[0]['trackerLogs'];

							krsort($tracker_all);
							foreach ( $tracker_all as $track){
		
								$comment ='<h5 class="w3-text-teal" ><b>['.$track['date'].']</b></h5>&nbsp;&nbsp;'.$track['log'];
						
								echo $comment;
							
							}
                            
                            

						?>
                        <br><br>

						</div>


			
			 </div>


			


</div>

	






