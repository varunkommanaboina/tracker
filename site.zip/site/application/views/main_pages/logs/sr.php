
		



<style>
table{

		width:100%;
}

th{
	text-align: right;
    background: #f4f4ee;
    padding: 1px 8px;
    color: #666;
	border: 2px solid #fff;
}

td {
    background: #e3ebe2;
    padding: 1px 8px;
}

tr {
	border: 2px solid #fff;

}

</style>


<div class="w3-card-4"  style="margin:0px 5px 10px 5px">

		<header class="w3-container w3-blue">
		<p><b class="w3-left" style="padding-top:10px">
			<?php
			if ($collection == 'ESXI'){
			echo 'ESXI : '.$data[0]['serverName'];

			}
			
			?>
			</b>
			<b class="w3-right" style="padding:5px 0px">
			<a  style="width:100%;text-decoration:none;padding:5px 10px;" href="#" onclick="addnew()" class="w3-btn w3-teal">ADD NEW</a>
			</b>
			
			</p> 

		</header>


			<div class="w3-container" style="padding-top:5px;">
										
							
						<?php
						krsort($srno );
						foreach ($srno as $srnoeach){

							$var ='<table>
							<tr>
							<th style="background-color:#009688;color:#fff;width:100px;">SR Number:</th> <td style="width:750px;">#'.$srnoeach['srno'].'</td><th style="width:90px;">Status:</th><td >'.$srnoeach['status'].'</td>
							</tr>
							<tr>
							<th>request Raised By:</th><td>'.$srnoeach['requestRaisedBy'].'</td><th>Assiggned to:</th><td>'.$srnoeach['AssignedTo'].'</td>
							</tr>
							<tr><th>Date:</th><td>'.$srnoeach['date'].'</td><th>comment:</th><td style="padding:0px;"><a  style="width:100%;text-decoration:none;" href="#" onclick="popup(\''.$srnoeach['srno'].'\',\''.$srnoeach['_id'].'\');" class="w3-btn w3-teal">ADD</a></td></tr>
							<tr><th>Title:</th><td ">'.$srnoeach['title'].'</td></tr><tr><th>Description:</th><td>'.$srnoeach['Desscription'].'</td></tr><tr><th>Solution:</th> <td>'.$srnoeach['solution'].'</td>
							</tr>
							
							</table>';
							echo $var;


							echo '<div class="container">';
							krsort($srnoeach['comments']);
							foreach ($srnoeach['comments'] as $comments){
								
								$comment ='<h5><b>['.$comments['date'].']</b>&nbsp;&nbsp;'.$comments['commentby'].'</h5>'.$comments['comment'];

								echo $comment;

							}

							echo '</div>';	
							echo '<br>';				
							

						}
					


						?>
							<br>

			
			</div>

</div>

<script>
function popup(srno,id) {

	document.getElementById("popup_title").innerHTML ="#"+srno;
	document.getElementById("id").value =id;
	document.getElementById('id02').style.display="block";
	document.getElementById("editor1").value="";

 
}

function addnew() {



document.getElementById('id03').style.display="block";


}
</script>

 <script src="<?php echo base_url();?>assets/ckeditor/ckeditor.js"></script>

<div id="id02" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:90%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id02').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4 id="popup_title"></h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
						<?php echo validation_errors(); ?>
                            <?php echo form_open('logs/comments_insert'); ?>

								<textarea name="comment" id="editor1" rows="100" cols="80">
									
								</textarea>
								<script>
								
									CKEDITOR.replace( 'comment' );
								</script>
								<input type="hidden" name="current" value="<?php echo current_url();?>" >
								<input type="hidden" name="id" id="id">
								<input type="hidden" name="collection" value="SR" >
								<input class="w3-button w3-round w3-blue" value="submit" style="margin-top:5px" type="submit">
								<?php echo form_close();?>
							</form>
							<br>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>


<div id="id03" class="w3-modal" style="padding-top:20px;">
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:80%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id03').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Add New Service Request</h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
						<?php echo validation_errors(); ?>
                            <?php echo form_open('logs/sr_insert'); ?>

								<p>
								<label>Sr Number:</label>
								<input class="w3-input" type="text" name="sr_number"></p>
								<p>

								<p>
								<label>Assigned to:</label>
								<input class="w3-input" type="text" name="assignet_to"  ></p>
								<p>
								<p>
								<label>Status:</label>
								<input class="w3-input" type="text" name="status"></p>

								<p>
								<label>Title:</label>
								<input class="w3-input" type="text" name="title"></p>
								<p>
								<label>Description:</label>
								<textarea class="w3-input" type="text" name="description"></textarea></p>
								<p>
								<label>Solution:</label>
								<textarea class="w3-input" type="text" name="solution"></textarea></p>						

								<p>
								<input type="hidden" name="current" value="<?php echo current_url();?>">
								<input type="hidden" name="collection" value="<?php echo $this->uri->segment(3, 0);?>">
								<input type="hidden" name="id" value="<?php echo $this->uri->segment(4, 0);?>">
								<input class="w3-button w3-round w3-teal" type="submit"></p>
							<?php echo form_close();?>
							</form>
							<br>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>