
		



<style>






table{

		width:100%;
		border: 2px solid black;
}

th{
	text-align: center;
    background: #f4f4ee;
    padding: 1px 8px;
    color: #666;
	border: 2px solid #fff;

}

td {
    background: #e3ebe2;

	color: #666;
	border: 2px solid #fff;
}

tr {
	border: 2px solid #fff;
	color: #666;
	border: 2px solid #fff;

}
input{
	width:100%;	
}




</style>


<div class="w3-card-4"  style="margin:0px 5px 10px 5px">

		<header class="w3-container w3-blue">
		<p><b class="w3-left" style="padding-top:10px">
			
			</b>
			<b class="w3-right" style="padding:5px 0px">
			<a  style="width:100%;text-decoration:none;padding:5px 10px;" href="#" onclick="addnew()" class="w3-btn w3-teal">ADD NEW</a>
			</b>
			
			</p> 

		</header>


			<div class="w3-container" style="padding-top:5px;">
										
							
						<?php



						krsort($data);
						echo '<table>';
						foreach ($data as $edata){
						


							$var =
							'<tr>
							<th style="background-color:#009688;color:#fff;width:110px;text-align:left;">Visit Number:</th><td style="width:130px;"><a target="_blank" href="'.base_url().'logs/visit_single/'.$edata['_id'].'">#'.$edata['_id'].'</a></td>
							<th style="width:90px;text-align:left">Visit Date:</th><td style="width:90px;" >'.$edata['date'].'</td>
							<th style="width:110px;text-align:left">Visit  Purpose</th><td>'.$edata['VisitPurpose'].'</td>
							
							</tr>';
							
							
							echo $var;

							


											
							

						}
						echo '</table>';
						


						?>
							<br>

			
			</div>

</div>

<script>
function popup(srno,id) {

	document.getElementById("popup_title").innerHTML ="#"+srno;
	document.getElementById("id").value =id;
	document.getElementById('id02').style.display="block";
	document.getElementById("editor1").value="";

 
}
function delete_sr(srno,id) {
	document.getElementById("popup_title_delete").innerHTML ="#"+srno;
	document.getElementById("did").value =id;
	document.getElementById('id04').style.display="block";

}




function addnew() {



document.getElementById('id03').style.display="block";


}
</script>

 <script src="<?php echo base_url();?>assets/ckeditor/ckeditor.js"></script>

<div id="id02" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:90%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id02').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4 id="popup_title"></h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
						<?php echo validation_errors(); ?>
                            <?php echo form_open('logs/comments_insert'); ?>

								<textarea name="comment" id="editor1" rows="100" cols="80">
									
								</textarea>
								<script>
								
									CKEDITOR.replace( 'comment' );
								</script>
								<input type="hidden" name="current" value="<?php echo current_url();?>" >
								<input type="hidden" name="id" id="id">
								<input type="hidden" name="collection" value="SR" >
								<input class="w3-button w3-round w3-blue" value="submit" style="margin-top:5px" type="submit">
								<?php echo form_close();?>
							</form>
							<br>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>

<div id="id04" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:50%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id04').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4 id="popup_title_delete"></h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
						<?php echo validation_errors(); ?>
                            <?php echo form_open('logs/delete_sr'); ?>
										<p style="font-size:20px;text-align:center;"><b>Are you sure want to delete this Service request </b></p><br>
								<input type="hidden" name="current" value="<?php echo current_url();?>" >
								<input type="hidden" name="id" id="did">
								<input type="hidden" name="parent_id" value="<?php echo $data[0]['_id'];?>">
								<input type="hidden" name="collection" value="SR" >
								<input type="hidden" name="parent_collection" value="<?php echo $collection;?>" >
								<input class="w3-btn w3-round w3-red "  value="Yes" style="margin-top:5px;width:200px;margin-left:90px;" type="submit">
								<input class="w3-btn w3-round w3-blue w3-hover-blue" value="No" onclick="document.getElementById('id04').style.display='none'" style="margin-top:5px;margin-left:20px;">
								<?php echo form_close();?>
							</form>
							<br>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>


<div id="id03" class="w3-modal" style="padding-top:20px;">
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:90%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id03').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>visitor Access request form</h4>
                    </header>
                    
                        <div class="w3-container" style="padding:0px;margin:0px;">
						<?php echo validation_errors(); ?>
                            <?php echo form_open('logs/sr_insert'); ?>

							<table>
									<tr style="background-color:#000;color:#fff">
									<th colspan="7" style="background-color:#000;color:#fff;text-align:center">visitor Access request form</th>
									</tr>

								<tr style="background-color:#ccc;color:#000" >
								<th style="background-color:#ccc;color:#000">SrNo</th>
								<th style="background-color:#ccc;color:#000">name</th>
								<th style="background-color:#ccc;color:#000">designation</th>
								<th style="background-color:#ccc;color:#000">department</th>
								<th style="background-color:#ccc;color:#000">mobile no</th>
								
								</tr>
								<tr>
								<td>1</td>
								<td><input type="text"></td>
								<td><input type="text"></td>
								<td><input type="text"></td>
								<td><input type="text"></td>
								
								
								</tr>
								<tr>
								<td>2</td>
								<td><input type="text"></td>
								<td><input type="text"></td>
								<td><input type="text"></td>
								<td><input type="text"></td>
								
								</tr>
								<tr>
								<td>3</td>
								<td><input type="text"></td>
								<td><input type="text"></td>
								<td><input type="text"></td>
								<td><input type="text"></td>
								
								</tr>
								<tr>
								<td>4</td>
								<td><input type="text"></td>
								<td><input type="text"></td>
								<td><input type="text"></td>
								<td><input type="text"></td>
								
								</tr>
								<tr>
								<td>5</td>
								<td><input type="text"></td>
								<td><input type="text"></td>
								<td><input type="text"></td>
								<td><input type="text"></td>
							
								</tr>
								<tr >
								<td colspan="2" style="background-color:#ccc;color:#000">purose of visit</td>
								<td colspan="4"><input type="text"></td>
								
								</tr>
									<tr >
								<td colspan="2" style="background-color:#ccc;color:#000">Signature and date</td>
								<td colspan="1"><input type="text"></td>
								
								</tr>
									<tr >
								<td colspan="2" style="background-color:#ccc;color:#000">date</td>
								<td colspan="1"><input type="date"></td>
								
								</tr>
								<tr >
								<td colspan="2" style="background-color:#ccc;color:#000">from</td>
								<td colspan="1"><input type="text"></td>
								
								</tr>
								<tr >
								<td colspan="2" style="background-color:#ccc;color:#000">to</td>
								<td colspan="1"><input type="text"></td>
								
								</tr>
								<tr style="background-color:#000;color:#fff">
									<th colspan="7" style="background-color:#000;color:#fff;text-align:center">Approval by ITG</th>
									</tr>
									<tr>
								<td colspan="2" style="background-color:#ccc;color:#000">Name of the Approving</td>
								<td colspan="1"><input type="text"></td>
								<td colspan="2" style="background-color:#ccc;color:#000">Designation</td>
								<td colspan="2"><input type="text"></td>
								
								</tr>
								<tr>
								<td colspan="2" style="background-color:#ccc;color:#000">Signature and date</td>
								<td colspan="1"><input type="text"></td>
								<td colspan="2" style="background-color:#ccc;color:#000">Seal of the dept/Org</td>
								<td colspan="2"><input type="text"></td>
								
								</tr>
								<tr>
									<th colspan="7" style="text-align:center">&nbsp;</th>
									</tr>
								<tr>
									<th colspan="7" style="background-color:#000;color:#fff;text-align:center">DCO project manager Approval</th>
									</tr>
									<tr>
								<td colspan="2" style="background-color:#ccc;color:#000">Name of the Approving</td>
								<td colspan="1"><input type="text"></td>
								<td colspan="2" style="background-color:#ccc;color:#000">Designation</td>
								<td colspan="2"><input type="text"></td>
								
								</tr>
								<tr>
								<td colspan="2" style="background-color:#ccc;color:#000">Signature and date</td>
								<td colspan="1"><input type="text"></td>
								<td colspan="2" style="background-color:#ccc;color:#000">Seal of the dept/Org</td>
								<td colspan="2"><input type="text"></td>
								
								</tr>
								
								<tr>
									<th colspan="5" style="text-align:center">&nbsp;</th>
									<th colspan="2" style="text-align:center">Add</th>
								
									</tr>
								
								</table>
							<?php echo form_close();?>
							</form>
							<br>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>
