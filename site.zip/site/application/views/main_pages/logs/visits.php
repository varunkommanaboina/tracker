
		



<style>
table{

		width:100%;
}

th{
	text-align: right;
    background: #f4f4ee;
    padding: 1px 8px;
    color: #666;
	border: 2px solid #fff;
}

td {
    background: #e3ebe2;
    padding: 1px 8px;
}

tr {
	border: 2px solid #fff;

}

</style>


<div class="w3-card-4"  style="margin:0px 5px 10px 5px">

		<header class="w3-container w3-blue">
		<p><b class="w3-left" style="padding-top:10px">
			<?php
			if ($collection == 'ESXI'){
			echo 'ESXI : '.$data[0]['serverName'];

			}else if($collection == 'VM'){
				echo 'VM : '.$data[0]['VMFunction'];
			}
			else if($collection == 'web'){
				echo 'Web/App : '.$data[0]['appName'];
			}
			
			?>
			</b>
			<b class="w3-right" style="padding:5px 0px">
			<a  style="width:100%;text-decoration:none;padding:5px 10px;" href="#" onclick="addnew()" class="w3-btn w3-teal">ADD NEW</a>
			</b>
			
			</p> 

		</header>


			<div class="w3-container" style="padding-top:5px;">
										
							
						<?php
						krsort($visits);
						foreach ($visits as $visit){

						echo '<pre>';
						
						print_r($visit);

						echo '</pre>';	
							

						}
					


						?>
							<br>

			
			</div>

</div>

<script>
function popup(srno,id) {

	document.getElementById("popup_title").innerHTML ="#"+srno;
	document.getElementById("id").value =id;
	document.getElementById('id02').style.display="block";
	document.getElementById("editor1").value="";

 
}

function addnew() {



document.getElementById('id03').style.display="block";


}
</script>

 <script src="<?php echo base_url();?>assets/ckeditor/ckeditor.js"></script>

<div id="id02" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:90%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id02').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4 id="popup_title"></h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
						<?php echo validation_errors(); ?>
                            <?php echo form_open('logs/comments_insert'); ?>

								<textarea name="comment" id="editor1" rows="100" cols="80">
									
								</textarea>
								<script>
								
									CKEDITOR.replace( 'comment' );
								</script>
								<input type="hidden" name="current" value="<?php echo current_url();?>" >
								<input type="hidden" name="id" id="id">
								<input type="hidden" name="collection" value="SR" >
								<input class="w3-button w3-round w3-blue" value="submit" style="margin-top:5px" type="submit">
								<?php echo form_close();?>
							</form>
							<br>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>


<div id="id03" class="w3-modal" style="padding-top:20px;">
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:80%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id03').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Add New Service Request</h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
						<?php echo validation_errors(); ?>
                            <?php echo form_open('logs/sr_insert'); ?>

								<p>
								<label>Sr Number:</label>
								<input class="w3-input" type="text" name="sr_number"></p>
								<p>

								<p>
								<label>Assigned to:</label>
								<input class="w3-input" type="text" name="assignet_to"  ></p>
								<p>
								<p>
								<label>Status:</label>
								<input class="w3-input" type="text" name="status"></p>

								<p>
								<label>Title:</label>
								<input class="w3-input" type="text" name="title"></p>
								<p>
								<label>Description:</label>
								<textarea class="w3-input" type="text" name="description"></textarea></p>
								<p>
								<label>Solution:</label>
								<textarea class="w3-input" type="text" name="solution"></textarea></p>						

								<p>
								<input type="hidden" name="current" value="<?php echo current_url();?>">
								<input type="hidden" name="collection" value="<?php echo $this->uri->segment(3, 0);?>">
								<input type="hidden" name="id" value="<?php echo $data[0]['_id'] ;?>">
								<input class="w3-button w3-round w3-teal" type="submit"></p>
							<?php echo form_close();?>
							</form>
							<br>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>