


<div class="w3-third" >
               



                 <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

                    <header class="w3-container w3-blue">
                    <h5 class="w3-left"><b>Website/Application</b></h5> 
                    <div class="w3-right"><b> 
                    <a href="#"  onclick="document.getElementById('id01').style.display='block'" ><i class="fas fa-edit w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a>
                     <a href="#"><i class="w3-hover-red fas fa-trash w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a> 
                    </b></div>
                    </header>

                            <div class="w3-container" style="padding-top:5px;">
                            <p>ID : <?php echo $data[0]['_id'] ?></p>
                            <p>URL : <?php echo $data[0]['url'] ?></p>
                            <p>Type : <?php echo $data[0]['type'] ?> </p>
                            <p>Name : <?php echo $data[0]['appName'] ?> </p>
                            <p>Dept : <?php echo $data[0]['deptname'] ?> </p>
                            </div>
                </div>


                <div class="w3-card-4"   style="margin:0px 5px 10px 5px">
                    <header class="w3-container w3-blue">
                    <h5 class="w3-left"><b>Package details</b></h5> 
                    <div class="w3-right">
                    <a href="#"  onclick="document.getElementById('id02').style.display='block'" ><i class="fas fa-edit w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a>
                    </div>
                    </header>

                        <div class="w3-container" style="padding-top:5px;">
                        <p><b>Web server:</b> <?php echo $data[0]['webServer'] ?></p>
                        <p><b>Database:</b> <?php echo $data[0]['databaseSoftware'] ?></p>
                        </div>

                </div>

</div>


<div class="w3-third">

                 <div class="w3-card-4"   style="margin:0px 5px 10px 5px" >

                        <header class="w3-container w3-blue">
                        <h5 class="w3-left"><b>Hosting</b></h5> 
                        <div class="w3-right">
                        <a href="#"  onclick="document.getElementById('id03').style.display='block'" ><i class="fas fa-edit w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a>
                        </div>
                        </header>

                            <div class="w3-container" style="padding-top:5px;">
                            <p>Hosting Type : <?php echo $data[0]['hostingDetails']['hostingType'] ?> </p>
                            <p>Hosted Date : <?php echo $data[0]['hostingDetails']['date'] ?> </p>
                            <p>Remark : <?php echo $data[0]['hostingDetails']['remark'] ?></p>
                            </div>


                 </div>


                <div class="w3-card-4"  style="margin:0px 5px 10px 5px" >

                    <header class="w3-container w3-blue">
                    <h5 class="w3-left"><b>Developer</b></h5> 
                    <div class="w3-right">
                    <a href="#"  onclick="document.getElementById('id04').style.display='block'" ><i class="fas fa-edit w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a>
                    </div>
                    </header>

                        <div class="w3-container" style="padding-top:5px;">
                        <p>Vendor Name : <?php echo $data[0]['vendorDetails']['vendor'] ?> </p>
                        <p>Contact Person : <?php echo $data[0]['vendorDetails']['contactPerson'] ?> </p>
                        <p>Email : <?php echo $data[0]['vendorDetails']['email'] ?> </p>
                        <p>Contact Number : <?php echo $data[0]['vendorDetails']['contactNo'] ?></p>
                        <p>Designation : <?php echo $data[0]['vendorDetails']['designation'] ?></p>
                        </div>

                </div>
                    
                <div class="w3-card-4"  style="margin:0px 5px 10px 5px" >

                    <header class="w3-container w3-blue">
                    <h5 class="w3-left"><b>Logs</b></h5> 
                    
                    </header>

                        <div class="w3-container" style="padding-top:5px;">
                        <p>Service Requests  <a href="<?php echo base_url().'logs/sr/web/'.$id[0].'.'.$id[1].'.'.$data[0]['_id']?>" ><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
                        <p>Comments    <a href="<?php echo base_url().'logs/comments/web/'.$id[0].'.'.$id[1].'.'.$data[0]['_id']?>" ><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
                        <p>Visits  <a href="<?php echo base_url().'logs/sr/web/'.$id[0].'.'.$id[1].'.'.$data[0]['_id']?>" ><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
                        <p>Tracker Logs  <a href="<?php echo base_url().'logs/tl/web/'.$id[0].'.'.$id[1].'.'.$data[0]['_id']?>" ><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
                        </div>

                </div>


                 
</div>

<div class="w3-third">
                    <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

                        <header class="w3-container w3-blue">
                        <h5 class="w3-left"><b>SSL Certificate</b></h5> 
                        <div class="w3-right">
                            <a href="#"  onclick="document.getElementById('id05').style.display='block'" ><i class="fas fa-edit w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a>
                            </div>
                        </header>

                                <div class="w3-container" style="padding-top:5px;">
                                <p>Status : <?php if ($data[0]['ssl']['status']=='0'){echo 'No';}else {echo 'Yes'; } ?> </p>
                                <p>Expiry Date : <?php echo $data[0]['ssl']['expiration'] ?></p>
                                </div>


                    </div>

                    <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

                        <header class="w3-container w3-blue">
                        <h5 class="w3-left"><b>Audit Certificate<?php echo $error;?></b></h5> 
                        <div class="w3-right">
                            <a href="#"  onclick="document.getElementById('id06').style.display='block'" ><i class="fas fa-edit w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a>
                            </div>
                        </header>

                                <div class="w3-container" style="padding-top:5px;">
                                <p>Audit Status : <?php if ($data[0]['auditCert']['status'] =='0'){echo 'No';}else {echo 'Yes'; } ?></p>
                                <p>validated By : <?php echo $data[0]['auditCert']['validatedBy'] ?></p>
                                <p>Valid : <?php if($data[0]['auditCert']['valid']=='0'){echo 'No';}else {echo 'Yes'; } ?></p>
                                <p>Issued Date : <?php echo $data[0]['auditCert']['issuedate'] ?></p>
                                <p>Expiry Date : <?php echo $data[0]['auditCert']['expdate'] ?></p>
                                <p>Open certificate <a href="<?php echo base_url().'uploads/audit/'.$data[0]['auditCert']['path']?>" ><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
                                <p>Remark : <?php echo $data[0]['auditCert']['remark'] ?></p>
                                </div>

                    </div>


                    

</div>





 <div id="id01" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id01').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Update Website/Application details</h4>
                    </header>
                    
                    <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('Web/edit_basic'); ?>
                          
                            <p>
                            <label>URL</label>
                            <input class="w3-input date" type="text" name="url" value="<?php echo $data[0]['url'];?>"></p>
                       
                            <p>
                            
                            <p>
                            <label>Type </label>
                            <input class="w3-input" type="text" name="type" value="<?php echo $data[0]['type'];?>"></p>
                           
                            <p>

                            <p>
                            <label>Name</label>
                            <input class="w3-input" type="text" name="name" value="<?php echo $data[0]['appName'];?>"></p>                        
                            <p>

                             <p>
                            <label>Dept</label>
                            <input class="w3-input" type="text" name="dname" value="<?php echo $data[0]['deptname'];?>"></p>                        
                            <p>
                            <br>

                            <input type="hidden" name="web_id" value="<?php  echo $data[0]['_id'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >

                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>



            <div id="id02" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id02').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Update Package details</h4>
                    </header>
                    
                    <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('Web/db_basic'); ?>
                          
                            <p>
                            <label>Web server</label>
                            <input class="w3-input date" type="text" name="wserver" value="<?php echo $data[0]['webServer'];?>"></p>
                       
                            <p>
                            
                            <p>
                            <label>Database </label>
                            <input class="w3-input" type="text" name="dbsoftware" value="<?php echo $data[0]['databaseSoftware'];?>"></p>
                         
                            <br>

                            <input type="hidden" name="web_id" value="<?php  echo $data[0]['_id'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >

                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>


             <div id="id03" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id03').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Update Hosting details</h4>
                    </header>
                    
                    <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('Web/edit_hosting'); ?>
                          
                            <p>
                            <label>Hosting Type</label>
                            <input class="w3-input date" type="text" name="type" value="<?php echo $data[0]['hostingDetails']['hostingType'];?>"></p>
                       
                            <p>
                            
                            <p>
                            <label>Hosted Date </label>
                            <input class="w3-input" type="date" name="date" value="<?php echo $data[0]['hostingDetails']['date'];?>"></p>

                            <p>
                            <label>Remark </label>
                            <input class="w3-input" type="text" name="remark" value="<?php echo $data[0]['hostingDetails']['remark'];?>"></p>
                         
                         
                            <br>

                            <input type="hidden" name="web_id" value="<?php  echo $data[0]['_id'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >

                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>



                     <div id="id04" class="w3-modal" >
                    <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                        <header class="w3-container w3-teal"> 
                            <span onclick="document.getElementById('id04').style.display='none'" 
                            class="w3-button w3-display-topright">&times;</span>
                            <h4>Update Vendor details</h4>
                        </header>
                    
                    <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('Web/edit_vendor'); ?>
                          
                            <p>
                            <label>Vendor Name</label>
                            <input class="w3-input date" type="text" name="vendor" value="<?php echo $data[0]['vendorDetails']['vendor'];?>"></p>
                       
                            <p>
                            
                            <p>
                            <label>Contact Person </label>
                            <input class="w3-input" type="text" name="cperson" value="<?php echo $data[0]['vendorDetails']['contactPerson'];?>"></p>

                            <p>
                            <label>Email </label>
                            <input class="w3-input" type="text" name="cemail" value="<?php echo $data[0]['vendorDetails']['email'];?>"></p>
                         
                            <p>
                            <label>Contact Number </label>
                            <input class="w3-input" type="text" name="cnumber" value="<?php echo $data[0]['vendorDetails']['contactNo'];?>"></p>
                         
                            <p>
                            <label>Designation </label>
                            <input class="w3-input" type="text" name="desig" value="<?php echo $data[0]['vendorDetails']['designation'];?>"></p>
                         
                         
                            <br>

                            <input type="hidden" name="web_id" value="<?php  echo $data[0]['_id'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >

                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>



             <div id="id05" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id05').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Update SSL details</h4>
                    </header>
                    
                    <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('Web/edit_ssl'); ?>
                          
                            <p>
                            <label>Status</label>
                            <br>

                             <input type="radio" name="status" <?php if($data[0]['ssl']['status']=="1"){echo 'checked="true"';}?> value="1" >Yes &nbsp;
                             <input type="radio" name="status" <?php if($data[0]['ssl']['status']=="0"){echo 'checked="true"';}?>  value="0">No
                           
                         
                       
                            <p>
                            
                            <p>
                            <label>Expiery date </label>
                            <input class="w3-input" type="date" name="date" value="<?php echo $data[0]['ssl']['expiration'];?>"></p>
                            
                            <br>

                            <input type="hidden" name="web_id" value="<?php  echo $data[0]['_id'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >

                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>



              <div id="id06" class="w3-modal" style="padding-top: 10px;" >
                    <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                        <header class="w3-container w3-teal"> 
                            <span onclick="document.getElementById('id06').style.display='none'" 
                            class="w3-button w3-display-topright">&times;</span>
                            <h4>Update Audit Certificate details</h4>
                        </header>
                    
                    <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open_multipart('Web/edit_audit'); ?>
                          
                            <p>
                            <label>Audit Status</label>
                            <br>
                            <input type="radio" name="status" <?php if($data[0]['auditCert']['status']=="1"){echo 'checked="true"';}?> value="1" >Yes &nbsp;
                             <input type="radio" name="status" <?php if($data[0]['auditCert']['status']=="0"){echo 'checked="true"';}?>  value="0">No
                       
                            <p>
                            
                            <p>
                            <label>validated By </label>
                            <input class="w3-input" type="text" name="validator" value="<?php echo $data[0]['auditCert']['validatedBy'];?>"></p>

                            <p>
                            <label>Valid </label>
                            <br>
                            <input type="radio" name="examine" <?php if($data[0]['auditCert']['valid']=="1"){echo 'checked="true"';}?> value="1" >Yes &nbsp;
                             <input type="radio" name="examine" <?php if($data[0]['auditCert']['valid']=="0"){echo 'checked="true"';}?>  value="0">No
                         
                            <p>
                            <label>Issued Date </label>
                            <input class="w3-input" type="date" name="idate" value="<?php echo $data[0]['auditCert']['issuedate'];?>"></p>
                         
                            <p>
                            <label>Expiry Date </label>
                            <input class="w3-input" type="date" name="edate" value="<?php echo $data[0]['auditCert']['expdate'];?>"></p>
                         
                            <p>
                            <label>upload certificate </label>
                            <input class="w3-input" type="file" name="userfile" value="<?php echo $data[0]['auditCert']['path'];?>"></p>
                            <input type="hidden" name="file" value="<?php echo $data[0]['auditCert']['path'];?>">

                            <p>
                            <label>Remark </label>
                            <input class="w3-input" type="text" name="remark" value="<?php echo $data[0]['auditCert']['remark'];?>"></p>
                         
                         
                            <br>

                            <input type="hidden" name="web_id" value="<?php  echo $data[0]['_id'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >


                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>

