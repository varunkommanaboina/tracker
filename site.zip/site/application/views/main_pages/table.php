

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/DataTables/datatables.min.css"/>
 
 <script type="text/javascript" src="<?php echo base_url(); ?>assets/DataTables/datatables.min.js"></script>

<style>
table.dataTable.no-footer {
    border-bottom: 1px solid #ccc; 
    border-top: 1px solid #ccc;

}
</style>

 <table id="example" class="display w3-table-all" style="width:100%;font-size:10px;" >
         <thead >
             <tr class="w3-teal">
                 <th>Name</th>
                 <th>Position</th>
                 <th>Office</th>
                 <th>Extn.</th>
                 <th>Start date</th>
                 <th>Position</th>
                 <th>Office</th>
                 <th>Extn.</th>
                 <th>Start date</th>
                 <th>Office</th>
                 <th>Extn.</th>
                 <th>Start date</th>
                 <th>Office</th>
               


              
         
                 
             </tr>
         </thead>
        
     </table>
 
 
 
 <script>
 $(document).ready(function() {
     $('#example').DataTable( {
       
         "ajax": {
            "url": "<?php echo $path;?>",
            "type": "POST",
            "dataSrc": "port",
            "data": {
                "collection":"<?php echo $collection;?>",
                "id":"<?php echo $id;?>",
                "object":"<?php echo $object;?>"
            }
        },
         "columns": [
             { "data": "portNo" },
             { "data": "portName" },
             { "data": "reqBy" },
             { "data": "reason" },
             { "data": "timePeriod" },
             { "data": "securityThreat" },
             { "data": "from" },
             { "data": "to" },
             { "data": "timePeriod" },
             { "data": "from" },
             { "data": "to" },
             { "data": "timePeriod" },
             { "data": "from" },
           
         ],
        
     } );
 } );
 
 </script>
