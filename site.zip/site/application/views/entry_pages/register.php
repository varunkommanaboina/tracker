
						<br><?php echo validation_errors(); ?>
						<?php echo form_open('users/register'); ?>
                        <div class="w3-section">
                    
													
													<label><b>Username</b></label>
													<input class="w3-input w3-border w3-margin-bottom" type="text" name="name" required>
													<label><b>User email</b></label>
													<input class="w3-input w3-border w3-margin-bottom" type="text" name="email" required>
													<label><b>password</b></label>
													<input class="w3-input w3-border w3-margin-bottom" type="password" name="password" required>
													<label><b>confirm password</b></label>
													<input class="w3-input w3-border w3-margin-bottom" type="password" name="password2" required>

													  <input class="w3-button w3-block w3-green w3-section w3-padding" type="submit" name="submit" value="Register" onclick="return(submitreg());">

                        </div>
						<?php echo form_close(); ?>
            
