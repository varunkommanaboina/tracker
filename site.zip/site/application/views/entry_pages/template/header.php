<!DOCTYPE html>
<html>
<title>Tracker</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/w3.css">
<link href="https://fonts.googleapis.com/css?family=Anton" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
 <script src="js/jquery.min.js"></script>
 <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
 <link href="https://fonts.googleapis.com/css?family=Averia+Libre|Rammetto+One" rel="stylesheet">
<body >
<style>
body{
  background-image: url("<?php echo base_url(); ?>assets/css/bg.jpeg");
}
.w3-myfont {


      font-family: 'Rammetto One', cursive;

      font-family: 'Averia Libre', cursive;


}

</style>
<div class="row">.</div>
<div class="row">
            <div class="col-sm-8" style="">
               <h1 class="w3-myfont" style="color:#e0ff33;font-size:42px;text-align:center;padding-top:260px;"><b>We Hope This Tool Will Make Your Life Easier @ workplace</b></h1>
		<h3 class="w3-myfont" style="color:#e0ff33;text-align:center;padding-top:30px;"><b>Now bits and bytes of Information on your finger tips </b></h3>
            </div>
            
            <div class="col-sm-4" style="margin-top:50px;">
                      <div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width:300px;border-radius:10px;font-size:10px;padding:10px;">
                       <div class="w3-left" style="width:100%"><div><image src="<?php echo base_url(); ?>assets/css/logo.png" style="height:50px;"></image></div></div>
                        <div class="w3-center" style="font-family: 'Anton', sans-serif; font-size:25px;">
                         MY TRACKER
                        </div>
                        <div class="w3-center" style="font-family: 'Anton', sans-serif; font-size:15px;">
                        <?php echo $title;?>
                        </div>
                        <div class="w3-center">

                          <img src="<?php echo base_url(); ?>assets/css/avatar/avatar.png" alt="Avatar" style="width:20%" class="w3-circle w3-margin-top">
                        </div>
