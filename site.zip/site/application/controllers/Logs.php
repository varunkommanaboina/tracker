<?php
	class Logs extends CI_Controller{
	
		public function sr(){
			$data['collection']=$this->uri->segment(3, 0);
			$where=array('_id'=>new MongoId($this->uri->segment(4, 0)));

			$select =array('_id','SrNo');
			$deselect =array();
			$order =array();
			$data['data']=$this->collection->get($data['collection'], $where,$select,$deselect,$order);



			$data['srno'] =array();
			foreach ( $data['data'][0]['SrNo'] as $data1){
				$where=array('_id'=>new MongoId($data1));
				$push =$this->collection->get('SR', $where,'','',$order);
				array_push($data['srno'],$push[0]);
			}
			

			if (count($data) > 0){				
				$title['title'] = 'Service Requests';
				$this->load->view('main_pages/template/header',$title);
				$this->load->view('main_pages/logs/sr', $data);
				$this->load->view('main_pages/template/footer');
			}
			else
			{

			}
			
		}

		public function comments(){
			$data['collection']=$this->uri->segment(3, 0);
			$where=array('_id'=>new MongoId($this->uri->segment(4, 0)));
			$select =array('_id','comments');
			$deselect =array();
			$order =array();
			$data['data']=$this->collection->get($data['collection'], $where,$select,$deselect,$order);

				echo "<pre>";

				print_r($data['data']);
				echo "</pre>";
			
		}

		public function tl(){
			$data['collection']=$this->uri->segment(3, 0);
			$data['id_original']=$this->uri->segment(4, 0);

			
		}



	}
