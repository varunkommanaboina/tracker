<?php
	class Logs extends CI_Controller{
	
		public function sr(){
			$data['collection']=$this->uri->segment(3, 0);
			$where=array('_id'=>new MongoId($this->uri->segment(4, 0)));

			$select =array();
			$deselect =array();
			$order =array();
			$data['data']=$this->collection->get($data['collection'], $where,$select,$deselect,$order);



			$data['srno'] =array();
			foreach ( $data['data'][0]['SrNo'] as $data1){
				$where=array('_id'=>new MongoId($data1));
				$push =$this->collection->get('SR', $where,'','',$order);
				array_push($data['srno'],$push[0]);
			}
			

			if (count($data) > 0){				
				$title['title'] = 'Service Requests';
				$this->load->view('main_pages/template/header',$title);
				$this->load->view('main_pages/logs/sr', $data);
				$this->load->view('main_pages/template/footer');
			}
			else
			{

			}
			
		}

		public function sr_insert(){
			$this->form_validation->set_rules('sr_number', 'comment field should  not be empty', 'required');
			$this->form_validation->set_rules('assignet_to', 'comment field should  not be empty', 'required');
			$this->form_validation->set_rules('status', 'comment field should  not be empty', 'required');
			$this->form_validation->set_rules('title', 'comment field should  not be empty', 'required');
			$this->form_validation->set_rules('description', 'comment field should  not be empty', 'required');
			$this->form_validation->set_rules('solution', 'comment field should  not be empty', 'required');

			$current =$this->input->post('current');
			$comment =$this->input->post('comment');
			$collection =$this->input->post('collection');
			$id =$this->input->post('id');
			
			$where=array('_id'=>new MongoId($id));
			
			$data =array(
				"srno"=>$this->input->post('sr_number'),
				"date"=>"date",
				"requestRaisedBy"=>$this->session->userdata('username'),
				"AssignedTo"=>$this->input->post('assignet_to'),
				"title"=>$this->input->post('title'),
				"Desscription"=>$this->input->post('description'),
				"solution"=>$this->input->post('solution'),
				"status"=>$this->input->post('status'),
				"comments"=>array(
					
				)

				

			);
			if($this->form_validation->run() === FALSE){

				redirect($current);
			}else{
							$inserted_id =$this->collection->insert('SR',$data);
							$this->collection->push($inserted_id,$collection,$where,'SrNo');
							redirect($current);
			}


			
	}

		public function comments(){
			$data['collection']=$this->uri->segment(3, 0);
			$where=array('_id'=>new MongoId($this->uri->segment(4, 0)));
			$select =array();
			$deselect =array();
			$order =array();
			$data['data']=$this->collection->get($data['collection'], $where,$select,$deselect,$order);

				
 

				if (count($data) > 0){				
				$title['title'] = 'Comments';
				$this->load->view('main_pages/template/header',$title);
				$this->load->view('main_pages/logs/comments', $data);
				$this->load->view('main_pages/template/footer');
				}
				else
				{

				}
			
		}

		public function comments_insert(){
				$this->form_validation->set_rules('comment', 'comment field should  not be empty', 'required');
				$current =$this->input->post('current');
				$comment =$this->input->post('comment');
				$collection =$this->input->post('collection');
				
				$data =array(
					"commentid"=> mt_rand (100000000,1000000000),
					"commentby"=>$this->session->userdata('username'),
					"comment"=>$comment,
					"date"=>"d432"
					

				);
				if($this->form_validation->run() === FALSE){

					redirect($current);
				}else{


								$id=$this->input->post('id');
								$where=array('_id'=>new MongoId($id));
								$this->collection->push($data,$collection,$where,'comments');
								redirect($current);
				}


				
		}

		public function tl(){
			$data['collection']=$this->uri->segment(3, 0);
			$data['id_original']=$this->uri->segment(4, 0);

			
			$where=array('_id'=>new MongoId($this->uri->segment(4, 0)));
			$select =array();
			$deselect =array();
			$order =array();
			$data['data']=$this->collection->get($data['collection'], $where,$select,$deselect,$order);



				if (count($data) > 0){				
				$title['title'] = 'Tracker logs';
				$this->load->view('main_pages/template/header',$title);
				$this->load->view('main_pages/logs/trackerlogs', $data);
				$this->load->view('main_pages/template/footer');
				}
				else
				{

				}


		}



	}
