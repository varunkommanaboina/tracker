<?php
	class Home extends CI_Controller{
		// Register user
		public function index(){
            $data['title'] = 'home page';
                $this->load->view('main_pages/template/header', $data);
				$this->load->view('main_pages/home');
				$this->load->view('main_pages/template/footer');
			
		}

		public function calender(){
			$title['title']= 'calender';
			
                $this->load->view('main_pages/template/header',$title);
				$this->load->view('main_pages/calender');
				$this->load->view('main_pages/template/footer');
			
		}

		public function message(){
			$data['title'] = 'redirects page';
			$data['message']='you are now registerd';
		   $this->load->view('static_pages/home',$data);
		   
		   }
		
		public function thumbnails(){

			$data['title']="HOME";

			$this->load->view('main_pages/template/header',$data);
			$this->load->view('main_pages/thumbnails/server');
			$this->load->view('main_pages/template/footer');

		}
		   
//----------------data tables------------------

		
		
	public function data_table_cotroller(){
			$collection =$_POST["collection"];
			$object =$_POST["object"];
			$id =$_POST["id"];
		
			$data['data']=$this->Data_tables->sub_object($collection,$object,$id);
	
			echo json_encode($data['data'][0]);
		
		}

// http://localhost:81/site/home/data_tables_page/VM/port/5c2680d45d5bac6011000029
		public function data_tables_page(){
			
			$data['collection']=$this->uri->segment(3, 0);
			$data['object']=$this->uri->segment(4, 0);
			$data['id']=$this->uri->segment(5, 0);

			
			
			$data['title'] = 'table';
			$data['path'] = base_url().'home/data_table_cotroller';
				$this->load->view('main_pages/template/header', $data);
				$this->load->view('main_pages/table',$data);
				$this->load->view('main_pages/template/footer');
		}
//---------------------------------------------------------
       
    }   