<?php
	class Home extends CI_Controller{
		// Register user
		public function index(){
            $data['title'] = 'home page';
                $this->load->view('main_pages/template/header', $data);
				$this->load->view('main_pages/home');
				$this->load->view('main_pages/template/footer');
			
        }
       
    }   