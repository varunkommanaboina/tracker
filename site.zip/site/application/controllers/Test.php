<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Test extends CI_Controller {

		public function index()
		{ 
			$this->load->view('template/home.php');
		}
		public function output(){
	
			//$toupdate = $this ->mongo_db->select(array('port'),array('_id'))->get('test');
			$data= $this->mongo_db->select(array(),array('name'))
			->where(array('_id' => new MongoId('5c012095275b2fc80d00002a')))->get('test');
			if (count($data) > 0){
			echo '<pre>';
			print_r($data);
			echo '</pre>';
			echo base_url();
			echo $data[0]['_id'];
			}
			else
			{
			}
		}
		public function table(){
		$this->load->library('table');

		$this->table->set_heading('Name', 'Color', 'Size');
		$this->table->add_row('Fred', 'Blue', 'Small');
		$this->table->add_row('Mary', 'Red', 'Large');
		$this->table->add_row('John', 'Green', 'Medium');
		
		echo $this->table->generate();
		
		$this->table->clear();
		
		$this->table->set_heading('Name', 'Day', 'Delivery');
		$this->table->add_row('Fred', 'Wednesday', 'Express');
		$this->table->add_row('Mary', 'Monday', 'Air');
		$this->table->add_row('John', 'Saturday', 'Overnight');
		
		echo $this->table->generate(); 
		
		}

		public function calender(){
			$this->load->library('calendar');

			$prefs = array(
				'show_next_prev'  => TRUE,
				'next_prev_url'   => 'http://example.com/index.php/calendar/show/'
		);
		
		$this->load->library('calendar', $prefs);
		
		echo $this->calendar->generate($this->uri->segment(3), $this->uri->segment(4));
		}

		public function date(){
			
			//$toupdate = $this ->mongo_db->select(array('port'),array('_id'))->get('test');
			$data= $this->mongo_db->select(array(),array('comments'))
			->where_between('date', '2018-11-08 00:00:01','2018-11-09 00:00:13' )->get('shiftRegister');
		
			echo '<pre>';
			print_r($data);
			echo '</pre>';
		
		}
		
		public function test1(){
			$query = $this->mongo_db->get_where('test', array('name' => 'varudasdn'));
			if(count($query) > 0){
				echo 'true';
			} else {
				return false;
			}
		}
}