<?php
	class VM extends CI_Controller{ 
		
		
				public function insert(){


							$this->form_validation->set_rules('web_name', 'web/app name', 'required');
							$this->form_validation->set_rules('vm_id', 'vm id', 'required');
							$this->form_validation->set_rules('type', 'type select', 'required');
							$current=$this->input->post('current'); 
							if($this->form_validation->run() === FALSE){
								redirect($current);
													 
							} else {
										$insert_type=$this->input->post('type'); 
										
										$id=$this->input->post('vm_id');
										$name= $this->input->post('web_name'); //ID or name
														if ($insert_type == "new"){
																	$data = array(
																		"VM_ID"=>new MongoId($id),
																		"hostingDetails"=>(object)array(
																				"hostingType"=>"staging",
																				"date"=>"date",
																				"remark"=>"remarks if any"
																		),
																		"type"=>"web application",
																		"appName"=>$name,
																		"deptname"=>"itipanaji",
																		"vendorDetails"=>(object)array(
																				"vendor"=>"vendorName",
																				"contactPerson"=>"text",
																				"email"=>"email@email.com",
																				"contactNo"=>"43243423432",
																				"designation"=>"developer",
																						),
																		"connectivity"=>(object)array(
																				"VPN"=>"VPN collection id",
																				"RDP"=>"rdp collection id"
																			),
																		"url"=>"http://wenbsite.com",
																		"auditCert"=>(object)array(
																				"status"=>"0",
																				"valid"=> "0",
																				"validatedBy"=>"company",
																				"issuedate"=>"date",
																				"expdate"=>"date",
																				"path"=>"soft copy path",
																				"remark"=>"text"
																		),
																		"ssl"=>(object)array(
																			"status"=>"0",
																			"expiration"=>""
																		),
																		"webServer"=>"apache",
																		"databaseSoftware"=>"mysql",
																		"visits"=>array(),
																		"SrNo"=>array(),
																		
																		"comments"=>(object)array(),
																		"trackerLogs"=>(object)array(
																			(object)array(
																				"date"=>"date",
																				"log"=>"mytrackerLogssql",
																			)
																		)
														
																);
					 											 
																$insert_id=$this->collection->insert('web',$data);//create new web doc
																
																$where=array('_id'=>new MongoId($id));
																$this->collection->push($insert_id,'VM',$where,'webapps'); //push newly created web Doc ID to VM apps array

																// Set message
																$this->session->set_flashdata('added_VM', 'esxi server is created');
																redirect($current);
													
															}else if ($insert_type == "migrate"){
																
																$result= $this->mongo_db->select(array('webapps'))->where(array('_id' => new MongoId($id)))->get('VM');
																if(in_array(new MongoId($name),$result[0]['webapps'])){
																	redirect('alredy exist $current');
																}else{
																		$where=array('_id'=>new MongoId($id));
																		$this->collection->push(new MongoId($name),'VM',$where,'webapps'); 
																		// Set message
																		$this->session->set_flashdata('added_VM', 'esxi server is created');
																		redirect($current);
																}

																


															}
									}


					}

					public function edit_basic(){
						//$this->form_validation->set_rules('cloud', 'cloud', 'required');
						$this->form_validation->set_rules('vm_function', 'Vm function', 'required');
						$this->form_validation->set_rules('vm_name', 'Vm name', 'required');
						$this->form_validation->set_rules('type', 'server type', 'required');

						
						if($this->form_validation->run() === FALSE){

														
						} else {

							$id=$this->input->post('vm_id');
							$current=$this->input->post('current');                        
							$data=array(
							'VMFunction' => $this->input->post('vm_function'),
							'hostName' => $this->input->post('vm_name'),
							'serverType' => $this->input->post('type')          
							);
							$where =array('_id'=>new MongoId($id));
							$this->collection->edit($where,$data,'VM');
							// Set message
							$this->session->set_flashdata('added_VM', 'esxi server is created');
							redirect($current);
							
						}



                }  
                



                public function edit_clone(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
					$this->form_validation->set_rules('c_name', 'clone name', 'required');
                    $this->form_validation->set_rules('c_date', 'clone date', 'required');
                    $this->form_validation->set_rules('remark', 'remark', 'required');

					
					if($this->form_validation->run() === FALSE){

													
					} else {

                        $id=$this->input->post('vm_id');
                        $current=$this->input->post('current');                        
						$data=array(
						'clone.name' => $this->input->post('c_name'),
						'clone.date' => $this->input->post('c_date'),
						'clone.remarks' => $this->input->post('remark')          
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'VM');
						// Set message
						$this->session->set_flashdata('added_VM', 'esxi server is created');
						redirect($current);
						
					}



				} 

				public function edit_hardware(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
					$this->form_validation->set_rules('ram', 'RAM', 'required');
                    $this->form_validation->set_rules('hdd', 'HDD', 'required');
                    $this->form_validation->set_rules('processor', 'Processor', 'required');

					
					if($this->form_validation->run() === FALSE){

													
					} else {

                        $id=$this->input->post('vm_id');
                        $current=$this->input->post('current');                        
						$data=array(
						'vHardware.ram' => $this->input->post('ram'),
						'vHardware.HDD' => $this->input->post('hdd'),
						'vHardware.processor' => $this->input->post('processor')          
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'VM');
						// Set message
						$this->session->set_flashdata('added_VM', 'esxi server is created');
						redirect($current);
						
					}



                } 
                


                public function edit_software_info(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
                    $this->form_validation->set_rules('os', 'operating system', 'required');
                    $this->form_validation->set_rules('antivirus', 'antivirus', 'required');
                    $this->form_validation->set_rules('licence', 'licence', 'required');
                    $this->form_validation->set_rules('date', 'date', 'required');
                   

					
					if($this->form_validation->run() === FALSE){

													
					} else {

                        $id=$this->input->post('vm_id');
                        $current=$this->input->post('current');                         
						$data=array(
                        'os' => $this->input->post('os'),
                        'antiVirus.antiVirus' => $this->input->post('antivirus'),
                        'antiVirus.licence' => $this->input->post('licence'),
                        'antiVirus.expiryDate' => $this->input->post('date')

						       
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'VM');
						// Set message
						$this->session->set_flashdata('added_VM', 'esxi server is created');
						redirect($current);
						
					}



				} 


				public function edit_network_info(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
               
                    $this->form_validation->set_rules('private_ip', 'private ip', 'required');
					
                   
                   
 
					
					if($this->form_validation->run() === FALSE){
						
													
					} else {

                        $id=$this->input->post('vm_id');
                        $current=$this->input->post('current');                        
						$data=array(
                        'ips.public' => $this->input->post('public_ip'),
                        'ips.private' => $this->input->post('private_ip'),
                        'ips.gateway' => $this->input->post('gateway_ip'),
                        'internet' => $this->input->post('internet')

						       
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'VM');
						// Set message
						$this->session->set_flashdata('added_VM', 'esxi server is created');
						redirect($current);
						
					}



				}
       
    }   
