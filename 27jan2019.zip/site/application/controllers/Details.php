<?php
	class Details extends CI_Controller{
		
		public function single(){
	
		$data['collection']=$this->uri->segment(3, 0);
		$data['id_original']=$this->uri->segment(4, 0);

		
		$data['id']= explode('.',$data['id_original']);
				
					if($data['collection']=='ESXI'){
					
						$title['title']='ESXI Details' ;
						$da =$data['id'][0];
					
					}else if($data['collection']=='VM'){
						$title['title']='<a href="'.base_url().'details/single/ESXI/'.$data['id'][0].'">ESXI</a> < VM  Details';
						$da =$data['id'][1];
					}else if($data['collection']=='web'){
						$title['title']='<a href="'.base_url().'details/single/ESXI/'.$data['id'][0].'">ESXI</a> < <a href="'.base_url().'details/single/VM/'.$data['id'][0].'.'.$data['id'][1].'">VM </a> < Web Details';
						$da =$data['id'][2];
					}

					

					$data['data']=$this->collection->get($data['collection'], $da);

					if (count($data) > 0){				

						$this->load->view('main_pages/template/header',$title);
						$this->load->view('main_pages/collections/'.$data['collection'], $data);
						$this->load->view('main_pages/template/footer');
					}
					else
					{

					}


		}


		public function all(){
					$data['collection']=$this->uri->segment(3, 0);
		
					if($data['collection']=='ESXI'){
							
						$title['title']='ESXI' ;
						
					
					}else if($data['collection']=='VM'){
					
					}else if($data['collection']=='web'){
						
					}

					$data['data']=$this->collection->all($data['collection']);

				
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
					$this->form_validation->set_rules('server_name', 'server name', 'required');
					if($this->form_validation->run() === FALSE){

						
						$this->load->view('main_pages/template/header',$title);
						$this->load->view('main_pages/collections/all_esxi', $data);
						$this->load->view('main_pages/template/footer');
					
					} else {
						$data = array(
							'cloud' => $this->input->post('cloud'),
							'serverName' => $this->input->post('server_name'),
							'serverIp' =>"",
							"vms"=>array(),
							"hardware"=>(object)array(
									  "ram"=>"",
									  "HDD"=>"",
									  "processor"=>""
							),
							"SrNo"=>array()
									
					   
						);
						$cloud = $this->input->post('cloud');
						$server_name = $this->input->post('server_name');
						$this->collection->insert($data,'ESXI');
						// Set message
						$this->session->set_flashdata('added_esxi', 'esxi server is created');
						redirect('details/all/ESXI');
						
					}


		}



		
       
    }   