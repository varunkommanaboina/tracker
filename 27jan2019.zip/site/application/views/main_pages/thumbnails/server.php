
<style>
a.card {
    text-decoration: none !important;
}

.w3-quarter{
    padding:0px 15px;

}
h4{
    padding:5px 0px !important;
}

</style>


<div class="w3-quarter" >

 
               <a class="card"  href="<?php echo base_url();?>details/all/ESXI" ><div class="w3-blue w3-center w3-hover-shadow w3-center" >
                <p><h3  style="padding:20px 5px;">Physical servers</h3></p>
                </div></a>

              <a class="card" href="" ><div class="w3-card w3-orange w3-center w3-hover-shadow w3-center" >
              <p><h3  style="padding:20px 5px;">Physical servers</h3></p>
                </div></a>


               <a class="card" href="" ><div class="w3-card w3-red w3-center w3-hover-shadow w3-center" >
               <p><h3  style="padding:20px 5px;">Physical servers</h3></p>
                </div></a>

                 <a class="card" href="" ><div class="w3-card w3-yellow w3-center w3-hover-shadow w3-center" >
                 <p><h3  style="padding:20px 5px;">Physical servers</h3></p>
                </div></a>


                <a class="card" href="" ><div class="w3-card w3-purple w3-center w3-hover-shadow w3-center" >
                <p><h3  style="padding:20px 5px;">Physical servers</h3></p>
                </div></a>

                 <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                 <p><h3  style="padding:20px 5px;">Physical servers</h3></p>
                </div></a>

</div>






<div class="w3-quarter" >

<a class="card"  href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>

              <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>


               <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>

                 <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>


                <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>

</div>





<div class="w3-quarter" >


             <a class="card"  href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>

              <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>


               <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>

                 <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>


                <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>

</div>


<div class="w3-quarter" >


           <a class="card"  href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>

              <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>


               <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>

                 <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>


                <a class="card" href="" ><div class="w3-card w3-teal w3-center w3-hover-shadow w3-center" >
                <p style="padding:10px 5px;">w3-card sadsadsadsakj sadsajlnd ksandsandsand sakdn sadsjandksankdnsakjd bnsakdsk dsakdh sadsahdksa</p>
                </div></a>

</div>
