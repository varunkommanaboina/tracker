


<div class="w3-third" >
               



                 <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

                    <header class="w3-container w3-blue">
                    <h5 class="w3-left"><b>Website/Application</b></h5> 
                    <div class="w3-right"><b> 
                     <a href="#"><i class="fas fa-edit" style="font-size:18px;padding-top:8px;"></i></a> &nbsp;
                     <a href="#"><i class="fas fa-trash" style="font-size:18px;padding-top:8px;"></i></a>
                    </b></div>
                    </header>

                            <div class="w3-container" style="padding-top:5px;">
                            <p>URL : <?php echo $data[0]['url'] ?></p>
                            <p>Type : <?php echo $data[0]['type'] ?> </p>
                            <p>Name : <?php echo $data[0]['appName'] ?> </p>
                            <p>Dept : <?php echo $data[0]['deptname'] ?> </p>
                            </div>
                </div>


                <div class="w3-card-4"   style="margin:0px 5px 10px 5px">
                    <header class="w3-container w3-blue">
                    <h5 class="w3-left"><b>Virtual Machine</b></h5> 
                    <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
                    </header>

                        <div class="w3-container" style="padding-top:5px;">
                        <p>Server Name: <?php echo $data[0]['vm_id'] ?></p>
                        <p>Web server: <?php echo $data[0]['webServer'] ?></p>
                        <p>Database : <?php echo $data[0]['databaseSoftware'] ?></p>
                        </div>

                </div>

</div>


<div class="w3-third">

                 <div class="w3-card-4"   style="margin:0px 5px 10px 5px" >

                        <header class="w3-container w3-blue">
                        <h5 class="w3-left"><b>Hosting</b></h5> 
                        <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
                        </header>

                            <div class="w3-container" style="padding-top:5px;">
                            <p>Hosting Type : <?php echo $data[0]['hostingDetails']['hostingType'] ?> </p>
                            <p>Hosted Date : <?php echo $data[0]['hostingDetails']['hostedDate'] ?> </p>
                            <p>Remark : <?php echo $data[0]['hostingDetails']['remark'] ?></p>
                            </div>


                 </div>


                <div class="w3-card-4"  style="margin:0px 5px 10px 5px" >

                    <header class="w3-container w3-blue">
                    <h5 class="w3-left"><b>Developer</b></h5> 
                    <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
                    </header>

                        <div class="w3-container" style="padding-top:5px;">
                        <p>Vendor Name : <?php echo $data[0]['vendorDetails']['vendor'] ?> </p>
                        <p>Contact Person : <?php echo $data[0]['vendorDetails']['contactPerson'] ?> </p>
                        <p>Email : <?php echo $data[0]['vendorDetails']['email'] ?> </p>
                        <p>Contact Number : <?php echo $data[0]['vendorDetails']['contactNo'] ?></p>
                        <p>Designation : <?php echo $data[0]['vendorDetails']['designation'] ?></p>
                        </div>

                </div>
                    
                <div class="w3-card-4"  style="margin:0px 5px 10px 5px" >

                    <header class="w3-container w3-blue">
                    <h5 class="w3-left"><b>Logs</b></h5> 
                    <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
                    </header>

                        <div class="w3-container" style="padding-top:5px;">
                        <p>Service Requests  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
                        <p>Comments    <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
                        <p>Visits  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
                        <p>Tracker Logs  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
                        </div>

                </div>


                
</div>

<div class="w3-third">
                    <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

                        <header class="w3-container w3-blue">
                        <h5 class="w3-left"><b>SSL Certificate</b></h5> 
                        <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
                        </header>

                                <div class="w3-container" style="padding-top:5px;">
                                <p>Status : <?php echo $data[0]['ssl']['status'] ?> </p>
                                <p>Installed Date : <?php echo $data[0]['ssl']['expiration'] ?></p>
                                <p>Expiry Date : <?php echo $data[0]['ssl']['installed'] ?></p>
                                </div>


                    </div>

                    <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

                        <header class="w3-container w3-blue">
                        <h5 class="w3-left"><b>Audit Certificate</b></h5> 
                        <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
                        </header>

                                <div class="w3-container" style="padding-top:5px;">
                                <p>Audit Status : <?php echo $data[0]['auditCert']['status'] ?></p>
                                <p>validated By : <?php echo $data[0]['auditCert']['validatedBy'] ?></p>
                                <p>Valid : <?php echo $data[0]['auditCert']['valid'] ?></p>
                                <p>Issued Date : <?php echo $data[0]['auditCert']['issuedate'] ?></p>
                                <p>Expiry Date : <?php echo $data[0]['auditCert']['expdate'] ?></p>
                                <p>Open certificate <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
                                <p>Remark : <?php echo $data[0]['auditCert']['remark'] ?></p>
                                </div>

                    </div>


                    <div class="w3-card-4"  style="margin:0px 5px 10px 5px" >

                            <header class="w3-container w3-blue">
                            <h5 class="w3-left"><b>Vendor Connectivity</b></h5> 
                            <a href="#"><i class="fas fa-edit w3-right" style="font-size:18px;padding-top:8px;"></i></a>
                            </header>

                                    <div class="w3-container" style="padding-top:5px;">
                                    <p>RDP : YES  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
                                    <p>VPN : YES  <a href="#"><i class="fas fa-external-link-alt w3-right" style="font-size:18px;"></i></a></p>
                                    </div>

                        

                    </div>

</div>




