<div class="w3-third"  >
               



               <div class="w3-card-4"  style="margin:0px 5px 10px 5px; ">

              <header class="w3-container w3-blue">
              <h5 class="w3-left"><b>Servers List</b></h5> 
              <a href="#"  onclick="document.getElementById('id01').style.display='block'"><i class="fas fa-plus w3-right w3-button w3-circle" style="margin-top:3px;padding:8px"></i></a>
              </header>

              <div class="w3-container" style="padding-top:5px;">
            
             
              <?php  
                    $clouds=array();
                    echo '<b><p>Server Name<i class="w3-right" style="font-size:15px;">cloud</i></p></b>';
                    foreach($data as $value){

                        echo  '<p><a href="'.base_url().'details/single/ESXI/'.$value['_id'].'">'.$value['serverName'].'</a><i class="w3-right" style="font-size:15px;">'.$value['cloud'].'</i></p>';
                        array_push($clouds,$value['cloud']);
                        
                    }
              ?>            
              </div>
              </div>


</div>






 <div id="id01" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id01').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Add Physical machine</h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('details/all/ESXI'); ?>
                            <p>
                            <label>Select Cloud</label>
                            <select class="w3-select" name="cloud">
                                <?php 
                                    $clouds=array_unique($clouds);
                                    foreach ($clouds as $cloud ){
                                        echo '<option value="'.$cloud.'">'.$cloud.'</option>';
                                    }
                                    
                                
                                ?>
                            </select>
                            </p>

                            <p>
                            <label>Server Name</label>
                            <input class="w3-input" type="text" name="server_name"></p>
                         

                            <p>
                            
                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>