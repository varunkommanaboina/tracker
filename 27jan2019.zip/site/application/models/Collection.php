<?php
class Collection extends CI_Model{
	
		public function get($collection,$id){
			
			
			
			$data['data'] =$this->mongo_db->where(array('_id' => new MongoId($id)))->get($collection);
			
				if (count($data) > 0){
				return $data['data'];
				}
				else
				{
					return false;
				}

		}

		public function all($collection){
			$data['data'] =$this->mongo_db->order_by(array('cloud' => 'ASC'))->get($collection);

			if (count($data) > 0){
				return $data['data'];
				}
				else
				{
					return false;
				}
		}

		public function insert($collection,$data){
			return $this->mongo_db->insert($collection, $data);
		}

		public function edit($data,$id){
			//edit esxi
			return $this->mongo_db->where(array('_id'=>new MongoId($id)))->set($data)->update('ESXI');

		}


		public function add_vm($data,$collection){	  
			$id=$this->input->post('esxi_id');
			$mongo_id = $this->insert($collection,$data);
			$this->mongo_db->where(array('_id'=>new MongoId($id)))->push('vms',$mongo_id )->update('ESXI');
		}

}

	