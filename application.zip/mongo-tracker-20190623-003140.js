
/** ESXI indexes **/
db.getCollection("ESXI").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** SR indexes **/
db.getCollection("SR").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** VM indexes **/
db.getCollection("VM").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** VPN indexes **/
db.getCollection("VPN").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** visits indexes **/
db.getCollection("visits").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** volumes indexes **/
db.getCollection("volumes").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** web indexes **/
db.getCollection("web").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** ESXI records **/
db.getCollection("ESXI").insert({
  "_id": ObjectId("5d0f0018275b2f8001000035"),
  "cloud": "Application",
  "serverName": "GOASDCAPP01",
  "serverIp": "10.189.47.1",
  "vms": [
    ObjectId("5d0f1df0275b2f8401000036"),
    ObjectId("5d0f2687275b2f8401000038")
  ],
  "hardware": {
    "ram": "100",
    "HDD": "10000",
    "processor": "40",
    "processor_cores": "5",
    "processor_core": null
  },
  "make": "CISCO",
  "model": "CISCO 120",
  "os": "ESXI OS",
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-06-23T04:29:12.0Z"),
      "comment": "dsadas"
    },
    {
      "commentid": NumberInt(958082212),
      "commentby": null,
      "comment": "<p>sds adasd</p>\r\n",
      "date": "date"
    },
    {
      "commentid": NumberInt(576041076),
      "commentby": null,
      "comment": "<p>dsa das</p>\r\n",
      "date": "date"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5d0f0026275b2f8401000030"),
  "cloud": "Application",
  "serverName": "GOASDCAPP02",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": "",
    "processor_cores": ""
  },
  "make": "",
  "model": "",
  "os": "",
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-06-23T04:29:26.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5d0f0044275b2f8001000036"),
  "cloud": "ems",
  "serverName": "GOASDCEMS01",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": "",
    "processor_cores": ""
  },
  "make": "",
  "model": "",
  "os": "",
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-06-23T04:29:56.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5d0f0055275b2f8401000031"),
  "cloud": "ems",
  "serverName": "GOASDCEMS02",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": "",
    "processor_cores": ""
  },
  "make": "",
  "model": "",
  "os": "",
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-06-23T04:30:13.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5d0f0067275b2f8001000037"),
  "cloud": "database",
  "serverName": "GOASDCDB01",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": "",
    "processor_cores": ""
  },
  "make": "",
  "model": "",
  "os": "",
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-06-23T04:30:31.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5d0f0076275b2f8401000032"),
  "cloud": "database",
  "serverName": "GOASDCDB02",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": "",
    "processor_cores": ""
  },
  "make": "",
  "model": "",
  "os": "",
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-06-23T04:30:46.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});

/** SR records **/

/** VM records **/
db.getCollection("VM").insert({
  "_id": ObjectId("5d0f1df0275b2f8401000036"),
  "ESXI_HOST": ObjectId("5d0f0018275b2f8001000035"),
  "VMFunction": "HMIS",
  "hostName": "GOSDCHMISAPP",
  "date": "2019-06-23",
  "status": "offline",
  "user_group": "DEPT",
  "vHardware": {
    "ram": "3",
    "HDD": "500",
    "HDD_Utilized": "200",
    "processor": "3",
    "remark": "dsda "
  },
  "volume": "APP DATA 01",
  "serverType": "stagging",
  "RDlogins": [
    
  ],
  "ips": {
    "public": "",
    "private": "",
    "gateway": ""
  },
  "port": [
    {
      "portNo": "3307",
      "portName": "mysql",
      "reqBy": "Db team",
      "reason": "testing",
      "timePeriod": "wedsaasdas",
      "securityThreat": "sadsadasd",
      "from": "dasdas",
      "to": "dsadasd",
      "remark": "asdasda"
    }
  ],
  "internet": "",
  "os": "windows 2012R2",
  "patches": {
    "patch": "patch id collection",
    "date": "12-07-1018",
    "updatedBy": "arjun",
    "status": "yes",
    "comments": "comments"
  },
  "softwaresInstalled": [
    {
      "name": "wamp",
      "licence": "no",
      "remarks": "text"
    },
    {
      "name": "ms sql",
      "licence": "yes",
      "remarks": "text"
    }
  ],
  "antiVirus": {
    "antiVirus": "type",
    "licence": "text",
    "expiryDate": "date   "
  },
  "storage": {
    "Backupdate": "date",
    "sourcecodeDir": "",
    "sourcecodeDirSize": "",
    "backupTap": "yes",
    "backupToTapeOn": "date",
    "backupToTapeby": ""
  },
  "webapps": [
    ObjectId("5d0f2585275b2f7c03000030"),
    ObjectId("5d0f2699275b2f800100003d")
  ],
  "SrNo": [
    
  ],
  "visits": [
    
  ],
  "comments": [
    {
      "commentId": "",
      "commentby": "",
      "date": "",
      "comment": ""
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "clone": {
    "name": "HMIS CLONE",
    "date": "2019-06-23",
    "remarks": "remarks if anyddd"
  },
  "thirdParty": {
    "softwares": "dsad sads a",
    "client_justification": "dasdsa dsadsad",
    "remarks": "sadsadsadsadddsadsadasssssa dasdsa adsd"
  }
});
db.getCollection("VM").insert({
  "_id": ObjectId("5d0f2687275b2f8401000038"),
  "ESXI_HOST": ObjectId("5d0f0018275b2f8001000035"),
  "VMFunction": "HMIS 2",
  "hostName": "",
  "date": "date",
  "status": "offline",
  "user_group": "",
  "vHardware": {
    "ram": "",
    "HDD": "",
    "HDD_Utilized": "",
    "processor": "",
    "remark": ""
  },
  "volume": "APP DATA 2",
  "serverType": "",
  "RDlogins": [
    
  ],
  "ips": {
    "public": "",
    "private": "",
    "gateway": ""
  },
  "port": [
    
  ],
  "internet": "",
  "os": "windows 2012R2",
  "patches": {
    "patch": "patch id collection",
    "date": "12-07-1018",
    "updatedBy": "arjun",
    "status": "yes",
    "comments": "comments"
  },
  "softwaresInstalled": [
    {
      "name": "wamp",
      "licence": "no",
      "remarks": "text"
    },
    {
      "name": "ms sql",
      "licence": "yes",
      "remarks": "text"
    }
  ],
  "antiVirus": {
    "antiVirus": "type",
    "licence": "text",
    "expiryDate": "date"
  },
  "storage": {
    "Backupdate": "date",
    "sourcecodeDir": "",
    "sourcecodeDirSize": "",
    "backupTap": "yes",
    "backupToTapeOn": "date",
    "backupToTapeby": ""
  },
  "webapps": [
    
  ],
  "SrNo": [
    
  ],
  "visits": [
    
  ],
  "comments": [
    {
      "commentId": "",
      "commentby": "",
      "date": "",
      "comment": ""
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "clone": {
    "name": "",
    "date": "",
    "remarks": ""
  },
  "thirdParty": {
    "softwares": "",
    "client_justification": "",
    "remarks": "sadsadsadsadddsadsadassss"
  }
});

/** VPN records **/
db.getCollection("VPN").insert({
  "_id": ObjectId("5d0f2422275b2f800100003c"),
  "vpno": "338162385",
  "vpntype": "web application",
  "destination": "10.189.47.176",
  "VmName": "hmis",
  "service": "service",
  "date": "2019-06-23",
  "vpn_username": "sadsadasdasds",
  "server_username": "dsadsadasdsd",
  "requester": "requester",
  "vendor": "vendorNamedddg rgregreg",
  "contact": "contact",
  "remark": "dsada sdsa dasd asd   a sadsadsa",
  "LOU": "226136947.jpg"
});

/** visits records **/

/** volumes records **/
db.getCollection("volumes").insert({
  "_id": ObjectId("5d0f0098275b2f8001000038"),
  "Cluster_name": "Application",
  "Volume name": "APP DATA 01",
  "lunno": "269083723",
  "allocated_space": "1000",
  "used_by": "dept",
  "date": "2019-06-23"
});
db.getCollection("volumes").insert({
  "_id": ObjectId("5d0f00b5275b2f8401000033"),
  "Cluster_name": "Application",
  "Volume name": "APP DATA 2",
  "lunno": "620767175",
  "allocated_space": "3000",
  "used_by": "dept",
  "date": "2019-06-23"
});
db.getCollection("volumes").insert({
  "_id": ObjectId("5d0f00c7275b2f8001000039"),
  "Cluster_name": "Application",
  "Volume name": "APP DATA 03",
  "lunno": "774612641",
  "allocated_space": "200",
  "used_by": "dept",
  "date": "2019-06-23"
});
db.getCollection("volumes").insert({
  "_id": ObjectId("5d0f161b275b2f8401000034"),
  "Cluster_name": "ems",
  "Volume name": "EMS DATA01",
  "lunno": "962618390",
  "allocated_space": "10000",
  "used_by": "DCO",
  "date": "2019-06-23"
});
db.getCollection("volumes").insert({
  "_id": ObjectId("5d0f165c275b2f800100003a"),
  "Cluster_name": "database",
  "Volume name": "DATABASE DATA 01",
  "lunno": "617938162",
  "allocated_space": "10000",
  "used_by": "DCO",
  "date": "2019-06-23"
});

/** web records **/
db.getCollection("web").insert({
  "_id": ObjectId("5d0f2585275b2f7c03000030"),
  "VM_ID": ObjectId("5d0f1df0275b2f8401000036"),
  "hostingDetails": {
    "hostingType": "staging",
    "date": "2019-06-08",
    "remark": "remarks if anydsadas d",
    "status": "online",
    "type": "staging dsadas "
  },
  "type": "web application",
  "appName": "10.189.47.176/hmis/login.aspx",
  "deptname": "itipanaji 3",
  "vendorDetails": {
    "vendor": "vendorName iti",
    "contactPerson": "sweta",
    "email": "sweta@gmail.com",
    "contactNo": "43243423432",
    "designation": "developer das"
  },
  "connectivity": {
    "VPN": "VPN collection id",
    "RDP": "rdp collection id"
  },
  "url": "10.189.47.176/hmis/login.aspx",
  "auditCert": {
    "status": "1",
    "valid": "1",
    "validatedBy": "company SOC",
    "issuedate": "2019-06-23",
    "expdate": "2019-06-08",
    "path": "110344036.jpg",
    "remark": "textdsa dasd"
  },
  "ssl": {
    "status": "1",
    "expiration": "2019-06-06"
  },
  "webServer": "apache33",
  "databaseSoftware": "mysql333",
  "visits": [
    
  ],
  "SrNo": [
    
  ],
  "comments": [
    
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ]
});
db.getCollection("web").insert({
  "_id": ObjectId("5d0f2699275b2f800100003d"),
  "VM_ID": ObjectId("5d0f2687275b2f8401000038"),
  "hostingDetails": {
    "hostingType": "staging",
    "date": "date",
    "remark": "remarks if any",
    "status": ""
  },
  "type": "web application",
  "appName": "10.189.47.176/hmis 1/login.aspx",
  "deptname": "itipanaji",
  "vendorDetails": {
    "vendor": "vendorName",
    "contactPerson": "text",
    "email": "email@email.com",
    "contactNo": "43243423432",
    "designation": "developer"
  },
  "connectivity": {
    "VPN": "VPN collection id",
    "RDP": "rdp collection id"
  },
  "url": "http://wenbsite.com",
  "auditCert": {
    "status": "0",
    "valid": "0",
    "validatedBy": "company",
    "issuedate": "date",
    "expdate": "date",
    "path": "soft copy path",
    "remark": "text"
  },
  "ssl": {
    "status": "0",
    "expiration": ""
  },
  "webServer": "apache",
  "databaseSoftware": "mysql",
  "visits": [
    
  ],
  "SrNo": [
    
  ],
  "comments": [
    
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ]
});
