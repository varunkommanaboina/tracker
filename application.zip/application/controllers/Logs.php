<?php
	class Logs extends CI_Controller{
	
		public function sr(){
			$data['collection']=$this->uri->segment(3, 0);
			$data['id_original']=$this->uri->segment(4, 0);
			
			$data['id']= explode('.',$data['id_original']);

			$select =array();
			$deselect =array();
			$order =array();
			


			if ($data['collection']== 'ESXI'){
				$title['title'] ="Service Requests < <a href=\"".base_url()."details/single/ESXI/".$this->uri->segment(4, 0)."\">Go Back</a>";
				$da =$data['id'][0];
			}else if($data['collection']== 'VM'){
				$title['title'] ="Service Requests < <a href=\"".base_url()."details/single/VM/".$this->uri->segment(4, 0)."\">Go Back</a>";
				$da =$data['id'][1];
			}else if($data['collection']== 'web'){
					$title['title'] ="Service Requests < <a href=\"".base_url()."details/single/web/".$this->uri->segment(4, 0)."\">Go Back</a>";
					$da =$data['id'][2];
					
								
			}

			$where=array('parent_ID'=>new MongoId($da));
			$data['parentid']=$da;
			$data['data']=$this->collection->get('SR', $where,$select,$deselect,$order);

			$data['srno'] =array();

			

			if (count($data) > 0){				
				$title['title'] = $title['title'];
				$this->load->view('main_pages/template/header',$title);
				$this->load->view('main_pages/logs/sr', $data);
				$this->load->view('main_pages/template/footer');
			}
			else
			{

			}
			
		}

		public function sr_single(){
			$data['id_original']=$this->uri->segment(3, 0);
			$where=array('_id'=>new MongoId($data['id_original']));
		

			$data['data']=$this->collection->get('SR', $where,'','',$order =array());
			$title['title']="Service Request";

			if (count($data) > 0){				
				$title['title'] = $title['title'];
				$this->load->view('main_pages/template/header',$title);
				$this->load->view('main_pages/logs/sr_single', $data);
				$this->load->view('main_pages/template/footer');
			}
			else
			{

			}

		}

		public function sr_insert(){
			$this->form_validation->set_rules('sr_number', 'comment field should  not be empty', 'required');
			$this->form_validation->set_rules('assignet_to', 'comment field should  not be empty', 'required');
			$this->form_validation->set_rules('status', 'comment field should  not be empty', 'required');
			$this->form_validation->set_rules('title', 'comment field should  not be empty', 'required');
			$this->form_validation->set_rules('description', 'comment field should  not be empty', 'required');
			$this->form_validation->set_rules('solution', 'comment field should  not be empty', 'required');

			$current =$this->input->post('current');
			$comment =$this->input->post('comment');
			$collection =$this->input->post('collection');
			$id =$this->input->post('id');
			
			$where=array('_id'=>new MongoId($id));
			
			$data =array(
				"srno"=>$this->input->post('sr_number'),
				"parent_collection"=>$collection,
				"parent_ID"=>new MongoId($id),
				"date"=>"date",
				"requestRaisedBy"=>$this->session->userdata('username'),
				"AssignedTo"=>$this->input->post('assignet_to'),
				"title"=>$this->input->post('title'),
				"Desscription"=>$this->input->post('description'),
				"solution"=>$this->input->post('solution'),
				"status"=>$this->input->post('status'),
				"comments"=>array(
					
				)

				

			);
			if($this->form_validation->run() === FALSE){

				redirect($current);
			}else{
							$inserted_id =$this->collection->insert('SR',$data);
							//$this->collection->push($inserted_id,$collection,$where,'SrNo');
							redirect($current);
			}


			
		}


		public function delete_sr(){
		
			$this->form_validation->set_rules('id', 'should  not be empty', 'required');
		//	$this->form_validation->set_rules('collection', 'should  not be empty', 'required');
			
			$id =new MongoId($this->input->post('id'));
			$where=array('_id'=>$id);
			$collection =$this->input->post('collection');
			
			if($this->form_validation->run() === FALSE){

				redirect($current);
			}else{
							$this->collection->delete_doc($where, $collection);
							
							echo '<script>window.close();</script>';
			}



		}

		public function visit_single(){
			$data['id_original']=$this->uri->segment(3, 0);
			$where=array('_id'=>new MongoId($data['id_original']));
		

			$data['data']=$this->collection->get('visits', $where,'','',$order =array());
			$title['title']="vendor visit";

			if (count($data) > 0){				
				$title['title'] = $title['title'];
				$this->load->view('main_pages/template/header',$title);
				$this->load->view('main_pages/logs/visit_single', $data);
				$this->load->view('main_pages/template/footer');
			}
			else
			{

			}

		}

		public function visits(){
			$data['collection']=$this->uri->segment(3, 0);
			$data['id_original']=$this->uri->segment(4, 0);
			
			$data['id']= explode('.',$data['id_original']);

			$select =array();
			$deselect =array();
			$order =array();
			


			if ($data['collection']== 'ESXI'){
				$title['title'] ="Service Requests < <a href=\"".base_url()."details/single/ESXI/".$this->uri->segment(4, 0)."\">Go Back</a>";
				$da =$data['id'][0];
			}else if($data['collection']== 'VM'){
				$title['title'] ="Service Requests < <a href=\"".base_url()."details/single/VM/".$this->uri->segment(4, 0)."\">Go Back</a>";
				$da =$data['id'][1];
			}else if($data['collection']== 'web'){
					$title['title'] ="Service Requests < <a href=\"".base_url()."details/single/web/".$this->uri->segment(4, 0)."\">Go Back</a>";
					$da =$data['id'][2];
					
								
			}

			$where=array('parent_ID'=>new MongoId($da));
			$data['parentid']=$da;
			$data['data']=$this->collection->get('visits', $where,$select,$deselect,$order);

			

			

			if (count($data) > 0){				
				$title['title'] = $title['title'];
				$this->load->view('main_pages/template/header',$title);
				$this->load->view('main_pages/logs/visits', $data);
				$this->load->view('main_pages/template/footer');
			}
			else
			{

			}
			
		}

		public function visit_insert(){
			//$this->form_validation->set_rules('sr_number', 'comment field should  not be empty', 'required');
			

			$current =$this->input->post('current');
		//	$comment =$this->input->post('comment');
		//	$collection =$this->input->post('collection');
		//	$id =$this->input->post('id');
			
		//	$where=array('_id'=>new MongoId($id));
			
			$data = array(
				"parent_collection"=>$this->input->post('parent_collection'),
				"parent_ID"=>new MongoID($this->input->post('parent_id')),
				"date" =>$this->input->post('date'),
				"from" =>$this->input->post('from'),
				"to" =>$this->input->post('to'),
				"VisitPurpose" => $this->input->post('purpose'),
				
				"Visitors"=>array(
							  (object)array(
								"name"=> $this->input->post('1_name'),
								"designation"=> $this->input->post('1_des'),
								"dept"=> $this->input->post('1_dep'),
								"mobile"=> $this->input->post('1_mob'),
							  ),
							  (object)array(
								"name"=> $this->input->post('2_name'),
								"designation"=> $this->input->post('2_des'),
								"dept"=> $this->input->post('2_dep'),
								"mobile"=> $this->input->post('2_mob'),
							  ),
							  (object)array(
								"name"=> $this->input->post('3_name'),
								"designation"=> $this->input->post('3_des'),
								"dept"=> $this->input->post('3_dep'),
								"mobile"=> $this->input->post('3_mob'),
							  ),
							  (object)array(
								"name"=> $this->input->post('4_name'),
								"designation"=> $this->input->post('4_des'),
								"dept"=> $this->input->post('4_dep'),
								"mobile"=> $this->input->post('4_mob'),
							  ),
							  (object)array(
								"name"=> $this->input->post('5_name'),
								"designation"=> $this->input->post('5_des'),
								"dept"=> $this->input->post('5_dep'),
								"mobile"=> $this->input->post('5_mob'),
							  )
							),
				"signAnddate"=>$this->input->post('snd'),
				"approvalByItg"=>(object)array(
								"nameOfTheApproving"=>$this->input->post('itg_name'),
								"signature&date"=>$this->input->post('itg_snd'),
								"Designation"=>$this->input->post('itg_des'),
								"seal"=>$this->input->post('itg_seal'),
							),
				"approvalByDCO"=>(object)array(
								"nameOfTheApproving"=>$this->input->post('dco_name'),
								"signature&date"=>$this->input->post('dco_snd'),
								"Designation"=>$this->input->post('dco_des'),
								"seal"=>$this->input->post('dco_seal'),
								
							  ),
				"comments"=>array(
							
							  )
				);
			//if($this->form_validation->run() === FALSE){

			//	redirect($current);
		//	}else{
							$inserted_id =$this->collection->insert('visits',$data);
							//$this->collection->push($inserted_id,$collection,$where,'visits');
							redirect($current);
		//	}


			
		}


		

		public function comments(){
			$data['collection']=$this->uri->segment(3, 0);
			$data['id_original']=$this->uri->segment(4, 0);
			$select =array();
			$deselect =array();
			$order =array();
			
			$data['id']= explode('.',$data['id_original']);
			if ($data['collection']== 'ESXI'){
				$title['title'] ="Comments < <a href=\"".base_url()."details/single/ESXI/".$this->uri->segment(4, 0)."\">Go Back</a>";
				$da =$data['id'][0];
			}else if ($data['collection']== 'VM'){
				$title['title'] ="Comments < <a href=\"".base_url()."details/single/VM/".$this->uri->segment(4, 0)."\">Go Back</a>";
				$da =$data['id'][1];
			}else if ($data['collection']== 'web'){
				$title['title'] ="Comments < <a href=\"".base_url()."details/single/web/".$this->uri->segment(4, 0)."\">Go Back</a>";
				$da =$data['id'][2];
			}

			$where=array('_id'=>new MongoId($da));
			$data['data']=$this->collection->get($data['collection'], $where,$select,$deselect,$order);
	
 

				if (count($data) > 0){				
				$title['title'] = $title['title'];
				$this->load->view('main_pages/template/header',$title);
				$this->load->view('main_pages/logs/comments', $data);
				$this->load->view('main_pages/template/footer');
				}
				else
				{

				}
			
		}

		public function comments_insert(){
				$this->form_validation->set_rules('comment', 'comment field should  not be empty', 'required');
				$current =$this->input->post('current');
				$comment =$this->input->post('comment');
				$collection =$this->input->post('collection');
				$id =$this->input->post('id');
				$data =(object)array(
					"commentid"=> mt_rand (100000000,1000000000),
					"commentby"=>$this->session->userdata('username'),
					"comment"=>$comment,
					"date"=>"date"
					

				);
				
				if($this->form_validation->run() === FALSE){

					redirect($current);
				}else{


								$id=$this->input->post('id');
								$where=array('_id'=>new MongoId($id));
								$this->collection->push($data,$collection,$where,'comments');
								redirect($current);
				}


				
		}

		public function tl(){
			$data['collection']=$this->uri->segment(3, 0);
			$data['id_original']=$this->uri->segment(4, 0);
			$data['id']= explode('.',$data['id_original']);
			
			
			$select =array();
			$deselect =array();
			$order =array();
			

			if ($data['collection']== 'ESXI'){
				$title['title'] ="Tracker Logs < <a href=\"".base_url()."details/single/ESXI/".$data['id_original']."\">Go Back</a>";
				$da =$data['id'][0];

			}else if($data['collection']== 'VM'){
				$title['title'] ="Tracker Logs < <a href=\"".base_url()."details/single/VM/".$data['id_original']."\">Go Back</a>";
				$da =$data['id'][1];
			}else if($data['collection']== 'web'){
				$title['title'] ="Tracker Logs < <a href=\"".base_url()."details/single/web/".$data['id_original']."\">Go Back</a>";
				$da =$data['id'][2];
			}

			$where=array('_id'=>new MongoId($da));
			$data['data']=$this->collection->get($data['collection'], $where,$select,$deselect,$order);

			if (count($data) > 0){				
				$title['title'] = $title['title'];
				$this->load->view('main_pages/template/header',$title);
				$this->load->view('main_pages/logs/trackerlogs', $data);
				$this->load->view('main_pages/template/footer');
			}else{
			
			}

			


		}


		



	}
