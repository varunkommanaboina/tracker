<?php
	class WEB extends CI_Controller{
		
		 
				

				public function edit_basic(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
					$this->form_validation->set_rules('url', 'url', 'required');
                    $this->form_validation->set_rules('type', 'type', 'required');
                    $this->form_validation->set_rules('name', 'name', 'required');

					
			 		if($this->form_validation->run() === FALSE){
						
													
					} else {

                        $id=$this->input->post('web_id');
                        $current=$this->input->post('current');                        
						$data=array(
						'url' => $this->input->post('url'),
						'type' => $this->input->post('type'),
						'appName' => $this->input->post('name'), 
						'deptname' => $this->input->post('dname'),
						'hostingDetails.status' => $this->input->post('web_status')         
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'web');
						// Set message
						$this->session->set_flashdata('edited', 'esxi server is created');
						redirect($current);
						
					}



                }  
				
				
				public function db_basic(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
					$this->form_validation->set_rules('dbsoftware', 'dbsoftware', 'required');			
			 		if($this->form_validation->run() === FALSE){
						
													
					} else {

                        $id=$this->input->post('web_id');
                        $current=$this->input->post('current');                        
						$data=array(
						'webServer' => $this->input->post('wserver'),
						'databaseSoftware' => $this->input->post('dbsoftware')
						         
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'web');
						// Set message
						$this->session->set_flashdata('edited', 'esxi server is created');
						redirect($current);
						
					}



				}  
				



				public function edit_hosting(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
					$this->form_validation->set_rules('type', 'type', 'required');			
			 		if($this->form_validation->run() === FALSE){
						
													
					} else {

                        $id=$this->input->post('web_id');
                        $current=$this->input->post('current');                        
						$data=array(
						'hostingDetails.type' => $this->input->post('type'),
						'hostingDetails.date' => $this->input->post('date'),
						'hostingDetails.remark' => $this->input->post('remark')
						         
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'web');
						// Set message
						$this->session->set_flashdata('edited', 'esxi server is created');
						redirect($current);
						
					}



				}  
				

				public function edit_vendor(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
					$this->form_validation->set_rules('vendor', 'custmer name', 'required');			
			 		if($this->form_validation->run() === FALSE){
						
													
					} else {

                        $id=$this->input->post('web_id');
                        $current=$this->input->post('current');                        
						$data=array(
						'vendorDetails.vendor' => $this->input->post('vendor'),
						'vendorDetails.contactPerson' => $this->input->post('cperson'),
						'vendorDetails.email' => $this->input->post('cemail'),
						'vendorDetails.contactNo' => $this->input->post('cnumber'),
						'vendorDetails.designation' => $this->input->post('desig')
						         
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'web');
						// Set message
						$this->session->set_flashdata('edited', 'esxi server is created');
						redirect($current);
						
					}



				}  
				


				public function edit_ssl(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
					$this->form_validation->set_rules('status', 'status', 'required');			
			 		if($this->form_validation->run() === FALSE){
						
													
					} else {

                        $id=$this->input->post('web_id');
                        $current=$this->input->post('current');                        
						$data=array(
						'ssl.status' => $this->input->post('status'),
						'ssl.expiration' => $this->input->post('date')
						
						         
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'web');
						// Set message
						$this->session->set_flashdata('edited', 'esxi server is created');
						redirect($current);
						
					}



				}  
				


				public function edit_audit(){
				
					$this->form_validation->set_rules('status', 'status', 'required');
							
			 		if($this->form_validation->run() === FALSE){
						
													
					} else {

                        $id=$this->input->post('web_id');
						$current=$this->input->post('current');   
						                     
						$where =array('_id'=>new MongoId($id));
						

							$file_name =mt_rand (100000000,1000000000);
							$file_exr = '';
							$file_string='';

							$this->load->helper(array('form', 'url'));
							$config['upload_path']          = './uploads/audit/';
							$config['allowed_types']        = 'gif|jpg|png|pdf|txt';
							$config['file_name']        = $file_name;
							$config['max_size']             = 1024;
						

							$this->load->library('upload', $config);

                                            if ( ! $this->upload->do_upload('userfile'))
                                            {
                                                    //$error = array('error' => $this->upload->display_errors());

                                                    //$this->load->view('test_pages/upload_form', $error);

                                                    $file_string=$this->input->post('file');

                                            }
                                            else
                                            {
                                                        if (file_exists('./uploads/audit/'.$this->input->post('file'))) {
                                                            unlink('./uploads/audit/'.$this->input->post('file'));
                                                        } else {
                                                            
                                                        }

                                                    $upload = array('upload_data' => $this->upload->data());
                                                    $file_string =$file_name.$upload['upload_data']['file_ext'];

                                                   
                                                    
                                                
											}
											

											$data=array(
												'auditCert.status' => $this->input->post('status'),
												'auditCert.valid' => $this->input->post('examine'),
												'auditCert.issuedate' => $this->input->post('idate'),
												'auditCert.expdate' => $this->input->post('edate'),
												'auditCert.path' =>  $file_string,
												'auditCert.remark' => $this->input->post('remark'),
												'auditCert.validatedBy' => $this->input->post('validator'),
												
														
												);
											$this->collection->edit($where,$data,'web');
											$this->session->set_flashdata('edited', 'esxi server is created');
											
										// Set message
										redirect($current);

                    }


 }  

 






				
                


                


				
       
    }   
