
		



<style>





table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #4CAF50;
  color: white;
}


label{

	color: #009688!important;
	font-size:16px;
	padding:3px 0px;

}




</style>


<div class="w3-card-4"  style="margin:0px 5px 10px 5px">

		<header class="w3-container w3-blue">
		<p><b class="w3-left" style="padding-top:10px">
					<?php if($this->uri->segment(3, 0) ==! ''){ echo '#'.$this->uri->segment(3, 0); }else {echo '';} ?>
			</b>
			<b class="w3-right" style="padding:5px 0px">
		
			</b>
			
			</p> 

		</header>

		<?php 

			

			
			

		?>


			<div class="w3-container" style="padding-top:5px;">
										
							
			<div class="w3-container w3-margin-top">
											<?php echo validation_errors(); ?>
                            <?php echo form_open_multipart('VM/edit_vpn'); ?>

								<div class="w3-half" style="padding:10px;">
								
								<p>
								<label>Destination:</label>
								<input class="w3-input" type="text" name="destination" value="<?php echo $data[0]['destination'];?>"></p>
								<p>

								<p>
								<label>VPN Type:</label>
								<input class="w3-input" type="text" name="type" value="<?php echo $data[0]['vpntype'];?>" ></p>

								<p>
								<label>VM Name:</label>
								<input class="w3-input" type="text" name="vmname"  value="<?php echo $data[0]['VmName'];?>" ></p>

								<p>
								<label>Service:</label>
								<input class="w3-input" type="text" name="service" value="<?php echo $data[0]['service'];?>"  ></p>

								<p>
								<label>Req By:</label>
								<input class="w3-input" type="text" name="reqby"  value="<?php echo $data[0]['requester'];?>" ></p>

								<p>
								<label>Vendor:</label>
								<input class="w3-input" type="text" name="vendor" value="<?php echo $data[0]['vendor'];?>"   ></p>

								<p>
								<label>Effective from:</label>
								<input class="w3-input" type="date" name="date" value="<?php echo $data[0]['date'];?>"  ></p>
								

								</div>
								<div class="w3-half" style="padding:10px;">
							
								<p>
								<label>VPN Username:</label>
								<input class="w3-input" type="text" name="vusername" value="<?php echo $data[0]['vpn_username'];?>"  ></p>
								<p>
								<label>Server Username:</label>
								<input class="w3-input" type="text" name="susername"  value="<?php echo $data[0]['server_username'];?>" ></p>

							
								<p>
								<label>Contact:</label>
								<input class="w3-input" type="text" name="contact" value="<?php echo $data[0]['contact'];?>"  ></p>

								<p>
								<label>LOU:</label>
								<input class="w3-input" type="file" name="userfile"   ></p>

								<label>Remark:</label>
								<textarea class="w3-input" type="text" name="remark" style="width: 538px; height: 212px;" ><?php echo $data[0]['remark'];?> </textarea></p>						

								<p>
								<input type="hidden" name="current" value="<?php echo current_url();?>">
								<input type="hidden" name="vpno" value="<?php echo $data[0]['vpno'];?>" >
								<input type="hidden" name="file" value="<?php echo $data[0]['LOU'];?>" >
								
							
								<input class="w3-button w3-round w3-teal" type="submit"></p>
								</div>
							<?php echo form_close();?>
							</form>
						
                        </div>

							<br>	

			
							

  





			</div>








</div>







<style>

label {    
	font-weight: 200;
	margin-bottom: 0px;
	margin-top:0px;

}

.w3-input {
    padding: 2px;
}

</style>
 

