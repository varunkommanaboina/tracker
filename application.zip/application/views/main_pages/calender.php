
<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8' />
<link href='<?php echo base_url();?>assets/calender/fullcalendar/packages/core/main.css' rel='stylesheet' />
<link href='<?php echo base_url();?>assets/calender/fullcalendar/packages/daygrid/main.css' rel='stylesheet' />
<link href='<?php echo base_url();?>assets/calender/fullcalendar/packages/timegrid/main.css' rel='stylesheet' />
<link href='<?php echo base_url();?>assets/calender/fullcalendar/packages/list/main.css' rel='stylesheet' />
<script src='<?php echo base_url();?>assets/calender/fullcalendar/packages/core/main.js'></script>
<script src='<?php echo base_url();?>assets/calender/fullcalendar/packages/interaction/main.js'></script>
<script src='<?php echo base_url();?>assets/calender/fullcalendar/packages/daygrid/main.js'></script>
<script src='<?php echo base_url();?>assets/calender/fullcalendar/packages/timegrid/main.js'></script>
<script src='<?php echo base_url();?>assets/calender/fullcalendar/packages/list/main.js'></script>
<script>

  document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
      plugins: [ 'interaction', 'dayGrid', 'timeGrid', 'list' ],
      header: {
        left: 'prev,next today',
        center: 'title',
       // right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
        right: 'dayGridMonth,listMonth'
      },
     
      navLinks: true, // can click day/week names to navigate views
      businessHours: true, // display business hours
      defaultDate: '06-25-2019',
      editable: true,
            
      
      events: [
        {
          title: 'Meeting',
          start: '2019-06-23',
      
        },
        {
          title: 'SSL Expiry',
					start: '2019-06-03',
					description:'dasdsadsdsadsa dsa dsadsa dsa dsa dsa dasd sa das dasd',
      
        }
        ,
        {
          title: 'Audit Expiry',
          start: '2019-06-12',
      
        }
        ,
        {
          title: 'Birthday',
          start: '2019-06-18', 
      
				},



				

				<?php		
							$date_events = $data;
							if ($date_events == ""){
									
							}else{
								foreach($date_events as $single){

									if($type =="ssl"){
											echo "{";
											echo "title:'SSL expiry :".$single['appName']."',";
											echo "start:'".$single['ssl']['expiration']."',";
											echo "color:'red'";
											echo "},";
									}else if($type =="events"){

											echo "{";
											echo "title:'".$single['event_title']."',";
											echo "start:'".$single['date']."',";
											echo "},";
									}
									
									

								}
							}
							
							
				
				
				?>


                ]

      
    });

    calendar.render();
  });

</script>
<style>


.w3-col.m8, .w3-twothird {
    width: 60.66666%;
}
.w3-col.m8, .w3-third {
    width: 38.66666%;
	
}
   #calendar {
            
            max-width: 720px;
            margin: auto 10px;
            font-size:11px;
            }

</style>
</head>
<body>

						<div class="w3-twothird">   <div id='calendar'></div> </div>

						<div class="w3-third" >   
						
											
																																<header class="w3-container w3-green"> 
																																		
																																			<h4 class="w3-left">Search Events</h4>
																																			<i class="fas fa-plus w3-right w3-button w3-circle w3-teal"  onclick="document.getElementById('id04').style.display='block'" style="margin-top:5px;padding:8px"></i>

																																	</header>
																																	
																																			<div class="w3-container w3-margin-top">
																																			<?php echo validation_errors(); ?>
                          						  <?php echo form_open_multipart('home/search_events'); ?>

																														
																															
																														

																															<p>
																															<label>display</label><br>
																															<input type="radio"  name="type"  value="0">Only my &nbsp;
                            																	<input type="radio"  name="type"  value="1"> All  
																															</p>
																														<br>
																															<p>
																															<input type="hidden" name="current" value="<?php echo current_url();?>">
																														
																															<input class="w3-button w3-round w3-teal" type="submit"></p>
																															</div>
																															<?php echo form_close();?>
																																																
																													
																																	

																																				<footer class="w3-container w3-green">
																																			<p></p>
																																			</footer>
																														




															
											
											
											
											
											
											
				 </div>

</body>
</html>



</div>

</div>


</body>
</html>




<div id="id04" class="w3-modal" style="padding-top:10px;">
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:50%;">
                    <header class="w3-container w3-green"> 
                        <span onclick="document.getElementById('id04').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Add New VPN login</h4>
                    </header>
                    
                        <div class="w3-container  w3-margin-top">
											<?php echo validation_errors(); ?>
                            <?php echo form_open_multipart('home/add_event'); ?>


																																	
																															<p>
																															<label>Event Title</label>
																															<input class="w3-input" type="text" name="title" ></p>
																															<p>

																														
																															<p>
																															<label>date</label>
																															<input class="w3-input" type="date" name="date"  ></p>

																															

																															<p>
																															<label>reference</label>
																															<input class="w3-input" type="text" name="reference"  ></p>
																															
																													

																														
																															<p>
																															<label>Description</label>
																															<textarea class="w3-input" rows="5" type="text" name="decription"  ></textarea></p>

																															<p>
																															<label>display</label><br>
																															<input type="radio"  name="type"  value="0">Only me &nbsp;
                            																	<input type="radio"  name="type"  value="1"> All  
																															</p>
																														<br>
																															<p>
																															<input type="hidden" name="current" value="<?php echo current_url();?>">
																														
																												

																															<input class="w3-button w3-round w3-teal" type="submit"></p>

																														
																													
							
											<?php echo form_close();?>
									
						
                        </div>

                          <footer class="w3-container w3-green">
                        <p></p>
                        </footer>
                </div>
</div>







