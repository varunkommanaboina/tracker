
		



<style>





table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #4CAF50;
  color: white;
}




</style>


<div class="w3-card-4"  style="margin:0px 5px 10px 5px">

		<header class="w3-container w3-blue">
		<p><b class="w3-left" style="padding-top:10px">
				<?php echo  $data[0]['VMFunction'];?>
			</b>
			<b class="w3-right" style="padding:5px 0px">
			<a  style="width:100%;text-decoration:none;padding:5px 10px;" href="#" onclick="addnew()" class="w3-btn w3-teal">ADD NEW</a>
			</b>
			
			</p> 

		</header>


			<div class="w3-container" style="padding-top:5px;">
										
							
						<?php

							


							echo '<table>
								<tr>
								<th>Srno</th>
								<th>RD login</th>
								<th>reqBy</th>
								<th>reason</th>
								<th>remark</th>
								<th>delete</th>
								</tr>';
							
							$arrlength = count($data[0]['RDlogins']);
							
							$x=0;

							for ($i=0;$i<$arrlength;$i++){

								$x++;

								echo '<tr>';
								echo	'<td>'.$x.'</td>';
								echo	'<td>'.$data[0]['RDlogins'][$i]['rdName'].'</td>';
								echo 	'<td>'.$data[0]['RDlogins'][$i]['reqBy'].'</td>';
								echo 	'<td>'.$data[0]['RDlogins'][$i]['reason'].'</td>';
								echo 	'<td>'.$data[0]['RDlogins'][$i]['remark'].'</td>';
								echo 	'<td><i class="fas fa-trash w3-button w3-circle w3-red w3-hover-red" onclick="delete_p(\''.$data[0]['_id'].'\',\''.$data[0]['RDlogins'][$i]['rdno'].'\')" style="margin-top:3px;padding:8px"></i></td>';

								echo '</tr>';
								


							}

							echo '</table>'
						


						

						?>
							<br>

			
							

  





			</div>








</div>

<script>
function popup(srno,id) {

	document.getElementById("popup_title").innerHTML ="#"+srno;
	document.getElementById("id").value =id;
	document.getElementById('id02').style.display="block";
	document.getElementById("editor1").value="";

 
}

function delete_p(id,port) {
	document.getElementById("popup_title_delete").innerHTML ="#"+port;
	document.getElementById("did").value =id;
	document.getElementById("rd").value =port;
	document.getElementById('id04').style.display="block";

}

function addnew() {
document.getElementById('id03').style.display="block";
}


</script>

 <script src="<?php echo base_url();?>assets/ckeditor/ckeditor.js"></script>

<style>

label {    
	font-weight: 200;
	margin-bottom: 0px;
	margin-top:0px;

}

.w3-input {
    padding: 2px;
}

</style>
 
<div id="id03" class="w3-modal" style="padding-top:10px;">
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:80%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id03').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Add New RD login or overwrite existing one</h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
						<?php echo validation_errors(); ?>
                            <?php echo form_open('VM/add_rd'); ?>

								<p>
								<label>RD login:</label>
								<input class="w3-input" type="text" name="rd_login"></p>
								<p>

								<p>
								<label>Req By</label>
								<input class="w3-input" type="text" name="reqby"  ></p>
								
								<p>								
								<label>reason</label>
								<textarea class="w3-input" type="text" name="reason"></textarea></p>

								<label>remark</label>
								<textarea class="w3-input" type="text" name="remark"></textarea></p>						

								<p>
								<input type="hidden" name="current" value="<?php echo current_url();?>">
								<input type="hidden" name="id" value="<?php echo $data[0]['_id'];?>">
								<input class="w3-button w3-round w3-teal" type="submit"></p>
							<?php echo form_close();?>
							</form>
						
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>



<div id="id04" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:50%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id04').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4 id="popup_title_delete"></h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
						<?php echo validation_errors(); ?>
                            <?php echo form_open('VM/delete_rd'); ?>
										<p style="font-size:20px;text-align:center;"><b>Are you sure want to delete this RD login</b></p><br>
								<input type="hidden" name="current" value="<?php echo current_url();?>" >
								<input type="hidden" name="id" id="did">

							
								<input type="hidden" name="rd" id="rd" >
						
								<input class="w3-btn w3-round w3-red "  value="Yes" style="margin-top:5px;width:200px;margin-left:120px;" type="submit">
								<input class="w3-btn w3-round w3-blue w3-hover-blue" value="No" onclick="document.getElementById('id04').style.display='none'" style="margin-top:5px;margin-left:20px;">
								<?php echo form_close();?>
							</form>
							<br>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>