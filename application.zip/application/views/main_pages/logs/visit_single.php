
		



<style>

table{

		width:100%;
		border: 2px solid black;
}

th{
	text-align: center;
    background: #f4f4ee;
    padding: 1px 8px;
    color: #666;
	border: 2px solid #fff;

}

td {
    background: #e3ebe2;
    padding: 1px 2px 1px 10px;
	color: #666;
	border: 2px solid #fff;
}

tr {
	border: 2px solid #fff;
	color: #666;
	border: 2px solid #fff;

}



</style>


<div class="w3-card-4"  style="margin:0px 5px 10px 5px">

		

			<div class="w3-container" style="padding-top:15px;">
										
			<table>
									<tr style="background-color:#000;color:#fff">
									<th colspan="7" style="background-color:#000;color:#fff;text-align:center">visitor Access request form</th>
									</tr>

								<tr style="background-color:#ccc;color:#000" >
								<th style="width:60px">Sr no</th>
								<th>name</th>
								<th>designation</th>
								<th>department</th>
								<th>mobile no</th>
								<th colspan="7" >&nbsp;</th>
								
								
								</tr>


								<?php
								$counter =0; 
								foreach ($data[0]['Visitors'] as $visitor){
									$counter++;	
									echo '<tr>';
									echo '<td>'.$counter.'</td>';
									echo '<td>'.$visitor['name'].'</td>';
									echo '<td>'.$visitor['designation'].'</td>';
									echo '<td>'.$visitor['dept'].'</td>';
									echo '<td>'.$visitor['mobile'].'</td>';
									echo '<td  colspan="7" >&nbsp;</td>';
								
									echo '</tr>';


								}

								?>

								
								<tr >
								<td colspan="2" style="background-color:#ccc;color:#000">purose of visit</td>
								<td colspan="5"><?php echo $data[0]['VisitPurpose'];?></td>
								
								</tr>
							
									<tr >
								<td colspan="2" style="background-color:#ccc;color:#000">Signature and date</td>
								<td colspan="5"><?php echo $data[0]['signAnddate'];?></td>
								
								</tr>
									<tr >
								<td colspan="2" style="background-color:#ccc;color:#000">date</td>
								<td colspan="5"><?php echo $data[0]['date'];?></td>
								
								</tr>
								<tr >
								<td colspan="2" style="background-color:#ccc;color:#000">from</td>
								<td colspan="5"><?php echo $data[0]['from'];?></td>
								
								</tr>
								<tr >
								<td colspan="2" style="background-color:#ccc;color:#000">to</td>
								<td colspan="5"><?php echo $data[0]['to'];?></td>
								
								</tr>
								<tr style="background-color:#000;color:#fff">
									<th colspan="7" style="background-color:#000;color:#fff;text-align:center">Approval by ITG</th>
									</tr>
									<tr>
								<td colspan="2" style="background-color:#ccc;color:#000">Name of the Approving</td>
								<td colspan="2"><?php echo $data[0]['approvalByItg']['nameOfTheApproving'];?></td>
								<td colspan="2" style="background-color:#ccc;color:#000">Designation</td>
								<td colspan="2"><?php echo $data[0]['approvalByItg']['Designation'];?></td>
								
								</tr>
								<tr>
								<td colspan="2" style="background-color:#ccc;color:#000">Signature and date</td>
								<td colspan="2"><?php echo $data[0]['approvalByItg']['signature&date'];?></td>
								<td colspan="2" style="background-color:#ccc;color:#000">Seal of the dept/Org</td>
								<td colspan="2"><?php echo $data[0]['approvalByItg']['Designation'];?></td>
								
								</tr>
								<tr>
									<th colspan="7" style="text-align:center">&nbsp;</th>
									</tr>
								<tr>
									<th colspan="7" style="background-color:#000;color:#fff;text-align:center">DCO project manager Approval</th>
									</tr>
									<tr>
								<td colspan="2" style="background-color:#ccc;color:#000">Name of the Approving</td>
								<td colspan="2"><?php echo $data[0]['approvalByDCO']['nameOfTheApproving'];?></td>
								<td colspan="2" style="background-color:#ccc;color:#000">Designation</td>
								<td colspan="2"><?php echo $data[0]['approvalByDCO']['Designation'];?></td>
								
								</tr>
								<tr>
								<td colspan="2" style="background-color:#ccc;color:#000">Signature and date</td>
								<td colspan="2"><?php echo $data[0]['approvalByDCO']['signature&date'];?></td>
								<td colspan="2" style="background-color:#ccc;color:#000">Seal of the dept/Org</td>
								<td colspan="2"><?php echo $data[0]['approvalByDCO']['signature&date'];?></td>
								
								</tr>
								
								<tr>
									<th colspan="5" style="text-align:center">&nbsp;</th>
									<th colspan="1" style="text-align:center"><a  style="width:100%;text-decoration:none;" href="#" onclick="popup('<?php echo $data[0]['_id'];?>');" class="w3-btn w3-teal">ADD</a></th>
									<th colspan="1" style="text-align:center"><a  style="width:100%;text-decoration:none;padding:2px" href="#" onclick="delete_sr('<?php echo $data[0]['_id'];?>');" class="w3-btn"><i class="fas fa-trash w3-button w3-circle w3-red" style="margin-top:3px;padding:8px"></i></a></th>
									</tr>
								
								</table>
								
							<?php

								echo '<div class="container">';
							krsort($data[0]['comments']);
							foreach ($data[0]['comments'] as $comments){
								
								$comment ='<h5><b>['.$comments['date'].']</b>&nbsp;&nbsp;'.$comments['commentby'].'</h5>'.$comments['comment'];

								echo $comment;

							}

							echo '</div>';	
							echo '<br>';


							?>
			
			</div>

</div>

<script>
function popup(id) {

	document.getElementById("popup_title").innerHTML ="#"+id;
	document.getElementById("id").value =id;
	document.getElementById('id02').style.display="block";
	document.getElementById("editor1").value="";

 
}
function delete_sr(id) {
	document.getElementById("popup_title_delete").innerHTML ="#"+id;
	document.getElementById("did").value =id;
	document.getElementById('id04').style.display="block";

}




function addnew() {



document.getElementById('id03').style.display="block";


}
</script>

 <script src="<?php echo base_url();?>assets/ckeditor/ckeditor.js"></script>

<div id="id02" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:90%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id02').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4 id="popup_title"></h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
						<?php echo validation_errors(); ?>
                            <?php echo form_open('logs/comments_insert'); ?>

								<textarea name="comment" id="editor1" rows="100" cols="80">
									
								</textarea>
								<script>
								
									CKEDITOR.replace( 'comment' );
								</script>
								<input type="hidden" name="current" value="<?php echo current_url();?>" >
								<input type="hidden" name="id" id="id">
								<input type="hidden" name="collection" value="visits" >
								<input class="w3-button w3-round w3-blue" value="submit" style="margin-top:5px" type="submit">
								<?php echo form_close();?>
							</form>
							<br>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>

<div id="id04" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:50%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id04').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4 id="popup_title_delete"></h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
						<?php echo validation_errors(); ?>
                            <?php echo form_open('logs/delete_sr'); ?>
										<p style="font-size:20px;text-align:center;"><b>Are you sure want to delete this Visit</b></p><br>
								<input type="hidden" name="current" value="<?php echo current_url();?>" >
								<input type="hidden" name="id" id="did">
							
								<input type="hidden" name="collection" value="visits" >
						
								<input class="w3-btn w3-round w3-red "  value="Yes" style="margin-top:5px;width:200px;margin-left:120px;" type="submit">
								<input class="w3-btn w3-round w3-blue w3-hover-blue" value="No" onclick="document.getElementById('id04').style.display='none'" style="margin-top:5px;margin-left:20px;">
								<?php echo form_close();?>
							</form>
							<br>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>


<div id="id03" class="w3-modal" style="padding-top:20px;">
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:80%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id03').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Add New Service Request</h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
						<?php echo validation_errors(); ?>
                            <?php echo form_open('logs/sr_insert'); ?>

								<p>
								<label>Sr Number:</label>
								<input class="w3-input" type="text" name="sr_number"></p>
								<p>

								<p>
								<label>Assigned to:</label>
								<input class="w3-input" type="text" name="assignet_to"  ></p>
								<p>
								<p>
								<label>Status:</label>
								<input class="w3-input" type="text" name="status"></p>

								<p>
								<label>Title:</label>
								<input class="w3-input" type="text" name="title"></p>
								<p>
								<label>Description:</label>
								<textarea class="w3-input" type="text" name="description"></textarea></p>
								<p>
								<label>Solution:</label>
								<textarea class="w3-input" type="text" name="solution"></textarea></p>						

								<p>
								<input type="hidden" name="current" value="<?php echo current_url();?>">
								<input type="hidden" name="collection" value="<?php echo $this->uri->segment(3, 0);?>">
								<input type="hidden" name="id" value="<?php echo $data[0]['_id'] ;?>">
								<input class="w3-button w3-round w3-teal" type="submit"></p>
							<?php echo form_close();?>
							</form>
							<br>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>



