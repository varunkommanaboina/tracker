
		



<style>
table{

		width:100%;
}

th{
	text-align: right;
    background: #f4f4ee;
    padding: 1px 8px;
    color: #666;
	border: 2px solid #fff;
}

td {
    background: #e3ebe2;
    padding: 1px 8px;
}

tr {
	border: 2px solid #fff;

}

</style>

 <script src="<?php echo base_url();?>assets/ckeditor/ckeditor.js"></script>


<div class="w3" style="">
              






			  <div class="w3-card-4"  style="margin:0px 5px 10px 5px;">

					<header class="w3-container w3-blue">
					<h5 class="w3-left"><b><?php
						if ($collection == 'ESXI'){
						echo 'ESXI : '.$data[0]['serverName'];

						}else if ($collection == 'VM'){
							echo 'VM : '.$data[0]['VMFunction'];
	
						}else if ($collection == 'web'){
							echo 'Web/App : '.$data[0]['appName'];
	
						}
						
						?></b></h5> 
					
					</header>

						<div class="w3-container" style="padding-top:5px;">
					
						
						

							   <?php echo validation_errors(); ?>
                            <?php echo form_open('logs/comments_insert'); ?>

								<textarea name="comment" id="editor1" rows="100" cols="80">
									
								</textarea>
								<script>
									// Replace the <textarea id="editor1"> with a CKEditor
									// instance, using default configuration.
									CKEDITOR.replace( 'comment' );
								</script>
								<input type="hidden" name="current" value="<?php echo current_url();?>" >
								<input type="hidden" name="id" value="<?php echo $data[0]['_id'];?>" >
								<input type="hidden" name="collection" value="<?php echo $this->uri->segment(3, 0);?>" >
								<input class="w3-button w3-round w3-blue" value="comment" style="margin-top:5px" type="submit">
								<?php echo form_close();?>
							</form>
							
							<br>

						<?php
							$commnets_all =$data[0]['comments'];

							krsort($commnets_all);
							foreach ( $commnets_all as $comments){
		
								$comment ='<div class="container"><h5 class="w3-text-teal" ><b >['.$comments['date'].']</b>&nbsp;&nbsp;'.$comments['commentby'].'</h5>'.$comments['comment'].'</div>';
						
								echo $comment;
							
							}
							echo '<br>';
							

						?>
						<br>

						</div>


			
			 </div>


			


</div>

	






