<div class="w3-container w3-third">

<br><?php echo validation_errors(); ?>
					<?php echo form_open('home/contact_add'); ?>
                        <div class="w3-section">
                          <label><b>Query / Feedback / Suggestion :</b></label>
                          <textarea class="w3-input w3-border w3-margin-bottom" style="width:600px;height:400px;" type="text" placeholder="Type here" name="message" ></textarea>
                          
						  <input class="w3-button w3-block w3-green w3-section w3-padding" type="submit" name="submit" value="Submit">
                          
                        </div>
                      <?php echo form_close(); ?>



</div>


