
		



<style>





table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #4CAF50;
  color: white;
}


label{

	color: #009688!important;
	font-size:16px;
	padding:3px 0px;

}




</style>


<div class="w3-card-4"  style="margin:0px 5px 10px 5px">

		<header class="w3-container w3-blue">
		<p><b class="w3-left" style="padding-top:10px">
					<?php if($this->uri->segment(3, 0) ==! ''){ echo '#'.$this->uri->segment(3, 0); }else {echo '';} ?>
			</b>
			<b class="w3-right" style="padding:5px 0px">
		
			</b>
			
			</p> 

		</header>

	

			<div class="w3-container" style="padding-top:5px;">
										
							
			<div class="w3-container w3-margin-top">
							<?php echo validation_errors(); ?>
                            <?php echo form_open_multipart('VM/edit_tape'); ?>

								<div class="w3-half" style="padding:10px;">
								
								<p>
								<label>Job ID:</label>
								<input class="w3-input" type="text" name="job_id" value="<?php echo $data[0]['job_id'];?>"></p>
								<p>

								<p>
								<label>Job Name:</label>
								<input class="w3-input" type="text" name="job_name" value="<?php echo $data[0]['job_name'];?>" ></p>

								<p>
								<label>Hostname:</label>
								<input class="w3-input" type="text" name="hostname"  value="<?php echo $data[0]['hostname'];?>" ></p>

								</div>
								<div class="w3-half" style="padding:10px;">
								<p>
								<label>Tape backup initiated date:</label>
								<input class="w3-input" type="date" name="date" value="<?php echo $data[0]['date'];?>"  ></p>

								<p>
								<label>Path:</label>
								<input class="w3-input" type="text" name="path"  value="<?php echo $data[0]['source_path'];?>" ></p>

								
								<p>
								<input type="hidden" name="current" value="<?php echo current_url();?>">
								<input type="hidden" name="tape_id" value="<?php echo $data[0]['tape_id'];?>" ></p>
								
								
								<p>
								
								<input class="w3-button w3-round w3-teal" type="submit"  style="margin:10px 20px 0px 20px;">
								<input class="w3-button w3-round w3-green" onclick="document.getElementById('id08').style.display='block'"  value=" Add " style="margin:10px 20px 0px 20px;width:80px" ></p>
								</div>
							<?php echo form_close();?>
							</form>
						
                        </div>

							<br>	

			
							

  





			</div>








</div>




<div class="w3-container" style="padding-top:5px;">
										
							
										<?php
				
											
					
				
											echo '<table>
												<tr>
												<th>Date</th>
												<th>size</th>
												<th>status</th>
												<th>remark</th>
											
												</tr>';

											$entry=	$data[0]['backup'];
											
											$arrlength = count($entry);
											
											$x=0;

											$arrlength1=$arrlength -1 ;
				
											for ($i=$arrlength1;$i>=0;$i--){
				
											
												echo '<tr>';
												
												echo	'<td>'.$entry[$i]['date'].'</td>';
												echo 	'<td>'.$entry[$i]['size'].'</td>';
												echo 	'<td>'.$entry[$i]['status'].'</td>';
												echo 	'<td>'.$entry[$i]['remark'].'</td>';
											//	echo 	'<td><i class="fas fa-trash w3-button w3-circle w3-red w3-hover-red" onclick="delete_p(\''.$data[$i]['vpno'].'\')" style="margin-top:3px;padding:8px"></i></td>';
											//	echo 	'<td><a href="'.base_url().'VM/vpn_edit_page/'.$data[$i]['vpno'].'"<i class="fas fa-edit w3-button w3-circle w3-green w3-hover-black"  style="margin-top:3px;padding:8px"></i></a></td>';
										//		echo  '<td><a href="'.base_url().'uploads/lou/'.$data[$i]['LOU'].'" ><i class="fas fa-external-link-alt w3-button w3-circle w3-green w3-hover-black"  style="margin-top:3px;padding:8px"></i></a></td>';
												echo '</tr>'; 
												
				
				
											}
				
											echo '</table>'
										
				
				 
										
				
										?>
											<br>
				
							
											
				
				  
				
				
				
				
				
							</div>






<style>

label {    
	font-weight: 200;
	margin-bottom: 0px;
	margin-top:0px;

}

.w3-input {
    padding: 2px;
}

</style>
 

 <div id="id08" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id08').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Add Tape Backup entry</h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('VM/add_tape_entry'); ?>
                          
                           

                            <p>
                            <label>Date</label>
                            <input class="w3-input" type="date" name="date"></p>

														<p>
                            <label>Size</label>
                            <input class="w3-input" type="text" name="size"></p>
														
														<p>
                            <label>status</label>
                            <input class="w3-input" type="text" name="status"></p>

														<p>
                            <label>remark</label>
                            <input class="w3-input" type="text" name="remark"></p>
                            
                           
                            
						
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >
							<input type="hidden" name="tape_id" value="<?php echo $data[0]['tape_id'];?>" >

														<p>
                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>
