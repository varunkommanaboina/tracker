<div class="w3-third"  >
               



               <div class="w3-card-4"  style="margin:0px 5px 10px 5px; ">

              <header class="w3-container w3-blue">
              <h5 class="w3-left"><b>Servers List</b></h5> 
              <a href="#"  onclick="document.getElementById('id01').style.display='block'"><i class="fas fa-plus w3-right w3-button w3-circle" style="margin-top:3px;padding:8px"></i></a>
              </header>

              <div class="w3-container" style="padding-top:5px;">
            
             
              <?php  
                    $clouds=array();
					
					
					echo '<table>
						
					<tr>
					<td><b>Server Name</b></td>
					<td class="w3-right"><b>Cluster</b></td>
				
					</tr>';

                    foreach($data as $value){

					
						

						echo '				
					<tr>
					<td><a href="'.base_url().'details/single/ESXI/'.$value['_id'].'">'.$value['serverName'].'</a></td>
					<td><i class="w3-right" style="font-size:15px;">'.$value['cloud'].'</i></td>
					
					</tr>';
						
						
						
						
						

                        array_push($clouds,$value['cloud']);
                        
					}
					

					echo '</table>';
              ?>            
              </div>
              </div>


</div>



<div class="w3-twothird"  >
               



               <div class="w3-card-4"  style="margin:0px 5px 10px 5px; ">

              <header class="w3-container w3-blue">
              <h5 class="w3-left"><b>virtual volume's List</b></h5> 
              <a href="#"  onclick="document.getElementById('id02').style.display='block'"><i class="fas fa-plus w3-right w3-button w3-circle" style="margin-top:3px;padding:8px"></i></a>
              </header>

              <div class="w3-container" style="padding-top:5px;">
			  <style>





table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}



th {
  background-color: #4CAF50;
  color: white;
  size:25px;
  
  
}




</style> 
             
              <?php  
                    $clouds=array();
					
					$select=array();
					$deselect=array();
					$where=array();
					$order=array('Cluster_name'=>'DESC');
					$volumes=$this->collection->get('volumes', $where,$select,$deselect,$order);


						

					echo '<table>
						
					<tr>
					<td colspan="5"><b>Voulme</b></td>
					<td colspan="2"><b>Cluster</b></td>
					<td colspan="1"><b>Edit</b></td>
					<td colspan="1"><b>Delete</b></td>
					</tr>';

                    foreach($volumes as $volume){

					
						

						echo '				
					<tr>
					<td colspan="5" >'.$volume['Volume name'].'</td>
					<td colspan="2">'.$volume['Cluster_name'].'</td>
					<td colspan="1"><i class="fas fa-edit  w3-button w3-circle w3-blue" onclick="edit_v(\''.$volume['lunno'].'\')" style="margin-top:3px;padding:8px"></i></td>
					<td colspan="1"><i class="fas fa-trash  w3-button w3-circle w3-red" onclick="delete_p(\''.$volume['lunno'].'\')" style="margin-top:3px;padding:8px"></i></td>
					</tr>';
						
						
						
						
						

                        array_push($clouds,$value['cloud']);
                        
					}
					

					echo '</table>';
              ?>            
              </div>
              </div>


</div>

<script>
function delete_p(id) {
	document.getElementById("popup_title_delete").innerHTML ="#"+id;
	document.getElementById("did").value =id;

	document.getElementById('id04').style.display="block";

}
</script>




 <div id="id01" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id01').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Add Physical machine</h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('details/all/ESXI'); ?>
                            <p>
                            <label>Select Cluster</label>
                            <select class="w3-select" name="cloud">
                            <option value="Application">Application</option>
                            <option value="database">database</option>
                            <option value="ems">ems</option>
                                <?php 
                                   // $clouds=array_unique($clouds);
                                   // foreach ($clouds as $cloud ){
                                      //  echo '<option value="'.$cloud.'">'.$cloud.'</option>';
                                  //  }
                                    
                                
                                ?>
                            </select>
                            </p>

                            <p>
                            <label>Server Name</label>
                            <input class="w3-input" type="text" name="server_name"></p>
                         

                            <p>
                            
                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>



			<div id="id02" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id02').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Add Virtual Volume</h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('details/insert_volume'); ?>
							<p>
                            <label>Volume Name</label>
                            <input class="w3-input" type="text" name="volume"></p>	
							<p>
                            <label>Allocate Volume Size</label>
                            <input class="w3-input" type="text" name="space"></p>	
							<p>
                            <label>Volume Used By </label>
                            <input class="w3-input" type="text" name="use"></p>

							<p>
                            <label>Allocated date</label>
                            <input class="w3-input" type="date" name="date"></p>
						    <p>
                            <label>Select Cluster</label>
                            <select class="w3-select" name="cloud">
                            <option value="Application">Application</option>
                            <option value="database">database</option>
                            <option value="ems">ems</option>
                                <?php 
                                   // $clouds=array_unique($clouds);
                                   // foreach ($clouds as $cloud ){
                                      //  echo '<option value="'.$cloud.'">'.$cloud.'</option>';
                                  //  }
                                    
                                
                                ?>
                            </select>
                            </p>

							<input type="hidden" name="current" value="<?php echo current_url();?>">

                      
                            <p>
                            
                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>



			<div id="id04" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:50%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id04').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4 id="popup_title_delete"></h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
						<?php echo validation_errors(); ?>
                            <?php echo form_open('Details/delete_volume'); ?>
										<p style="font-size:20px;text-align:center;"><b>Are you sure want to delete this virtual volume</b></p><br>
								<input type="hidden" name="current" value="<?php echo current_url();?>" >
								<input type="hidden" name="vid" id="did">

							
								
						
								<input class="w3-btn w3-round w3-red "  value="Yes" style="margin-top:5px;width:200px;margin-left:120px;" type="submit">
								<input class="w3-btn w3-round w3-blue w3-hover-blue" value="No" onclick="document.getElementById('id04').style.display='none'" style="margin-top:5px;margin-left:20px;">
								<?php echo form_close();?>
							</form>
							<br>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
</div>
