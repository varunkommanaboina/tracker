<style>
               .w3-hover-red:hover {
                  color: #fff!important;
                  background-color: #f44336!important;
               }
 </style>
 

<div class="w3-third" >
               



               <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

              <header class="w3-container w3-blue">
              <h5 class="w3-left"><b>Basic</b></h5> 
                <div class="w3-right">
                  <a href="#"  onclick="document.getElementById('id02').style.display='block'" ><i class="fas fa-edit w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a>
                  <a href="#"><i class="w3-hover-red fas fa-trash w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a> 
                </div>
              </header>

              <div class="w3-container" style="padding-top:5px;">
              <p>ID : <?php echo $data[0]['_id']?></p>
              <p>VM Function : <?php echo $data[0]['VMFunction']?></p>
              <p>HostName : <?php echo $data[0]['hostName']?></p>
							<p>Created on : <?php echo $data[0]['date']?></p>
              <p>Server type : <?php echo $data[0]['serverType']?></p>
              <p>Status : <?php echo $data[0]['status']?></p>
              <p>used by : <?php echo $data[0]['user_group']?></p>
             

               <p>RD logins <a target="_blank" href="<?php echo base_url().'VM/rds/'.$data[0]['_id']?>" ><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
							 <p>VPN logins <a target="_blank" href="<?php echo base_url().'VM/VPN/'.$data[0]['ips']['private']?>" ><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
							
							 <p>ADD to Tape
							 <?php 
								if ($data[0]['tape'] == ""){
									echo '<a onclick="document.getElementById(\'id08\').style.display=\'block\'"><b><i class="fas fa-plus w3-button w3-circle w3-right" style="padding:5px;margin-right:3px;"></i></a>';
								}
								else {
									echo '<a  href="'.base_url().'vm/tape/'.$data[0]['tape'].'"><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></a>';
								}
					 
								
							?> 
							</p>
           
             

                           
              </div>
              </div>

              
            <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

            <header class="w3-container w3-blue">
            <h5 class="w3-left"><b>Clone</b></h5> 
              <div class="w3-right">
                  <a href="#" onclick="document.getElementById('id01').style.display='block'"><i class="fas fa-edit w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a>
                  
                </div>
            </header>

            <div class="w3-container" style="padding-top:5px;">
           
            <p>Name: <?php echo $data[0]['clone']['name']?></p>
            <p>date: <?php echo $data[0]['clone']['date']?></p>
            <p>remark: <?php echo $data[0]['clone']['remarks'];?></p>


                        
            </div>
            </div>


                        
             <div class="w3-card-4"  style="margin:0px 5px 10px 5px">

            <header class="w3-container w3-blue">
            <h5 class="w3-left"><b>Virtual Hardware</b></h5> 
            <div class="w3-right">
                  <a href="#" onclick="document.getElementById('id03').style.display='block'" ><i class="fas fa-edit w3-button w3-circle" style="margin-top:3px;padding:8px"></i></a>
                  
                </div>
            </header>

            <div class="w3-container" style="padding-top:5px;">
            <p>RAM : <?php echo $data[0]['vHardware']['ram']?></p>
            <p>HDD : <?php echo $data[0]['vHardware']['HDD']?></p>
            <p>HDD utilized : <?php echo $data[0]['vHardware']['HDD_Utilized']?></p>
            <p>Remark : <?php echo $data[0]['vHardware']['remark']?></p>

            <p>Provessor : <?php echo $data[0]['vHardware']['processor']?></p>
       

                        
            </div>
            </div>
                        
</div>






<div class="w3-third"  >
               



               <div class="w3-card-4"  style="margin:0px 5px 10px 5px; ">

              <header class="w3-container w3-blue">
              <h5 class="w3-left"><b>Softwares Info</b></h5> 
              <div class="w3-right">
                  <a href="#"  onclick="document.getElementById('id04').style.display='block'"  ><i class="fas fa-edit w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a>
                  
                </div>
              </header>

              <div class="w3-container" style="padding-top:5px;">
              <p>Operationg system : <?php echo $data[0]['os']?></p>
              <p>Antivirus : <?php if($data[0]['antiVirus']['antiVirus'] !== ""){ echo 'Yes';}else { echo 'No';} ?></p>
            
              <p>Third party Softwares <a onclick="document.getElementById('id07').style.display='block'"  ><b><i class="fas fa-edit w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p> 
             
             

                           
              </div>
              </div>


            <div class="w3-card-4"  style="margin:0px 5px 10px 5px" >

            <header class="w3-container w3-blue">
            <h5 class="w3-left"><b>Network</b></h5> 
            <div class="w3-right">
                  <a href="#"  onclick="document.getElementById('id06').style.display='block'"><i class="fas fa-edit w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a>
                  
                </div>
            </header>

            <div class="w3-container" style="padding-top:5px;">
            <p>Public IP : <?php echo $data[0]['ips']['public']?></p>
            <p>Private IP : <?php echo $data[0]['ips']['private']?></p>
            <p>Gateway IP : <?php echo $data[0]['ips']['gateway']?></p>
            <p>Internet : <?php if($data[0]['internet'] == "1" ){echo "Yes"; }else{echo "No";}?></p>
            <p>Ports <a target="_blank" href="<?php echo base_url().'VM/ports/'.$data[0]['_id']?>" ><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
            
          
            </div>

            </div>
                        
             <div class="w3-card-4"  style="margin:0px 5px 10px 5px" >

            <header class="w3-container w3-blue">
            <h5 class="w3-left"><b>Logs</b></h5> 
            </header>

            <div class="w3-container" style="padding-top:5px;">
           
            <p>Service Requests <a href="<?php echo base_url().'logs/sr/VM/'.$id[0].'.'.$data[0]['_id']?>" ><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
           
            <p>Comments <a href="<?php echo base_url().'logs/comments/VM/'.$id[0].'.'.$data[0]['_id']?>" ><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
           
            <p>Visits <a href="<?php echo base_url().'logs/visits/VM/'.$id[0].'.'.$data[0]['_id']?>" ><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
          
            
            <p>Tracker Logs <a href="<?php echo base_url().'logs/tl/VM/'.$id[0].'.'.$data[0]['_id']?>" ><b><i class="fas fa-external-link-alt w3-button w3-circle w3-right" style="padding:5px"></i></b></a></p>
            </div>

            </div>



</div>




<div class="w3-third"  >
               



               <div class="w3-card-4"  style="margin:0px 5px 10px 5px; ">

              <header class="w3-container w3-blue">
              <h5 class="w3-left"><b>Websites/Applications</b></h5> 
              <div class="w3-right">
                  <a href="#"  onclick="document.getElementById('id05').style.display='block'"><i class="fas fa-plus w3-button w3-circle " style="margin-top:3px;padding:8px"></i></a>
                  
                </div>
              </header>

              <div class="w3-container" style="padding-top:5px;">
            
               
              <?php if($data[0]['webapps'] !== "" ){ 
                                
                                foreach ($data[0]['webapps'] as $value) {

                                $data['data']= $this->mongo_db->where(array('_id' => new MongoId($value)))->get('web');
                                echo '<p><a href="'.base_url().'details/single/web/'.$id_original.'.'.$value.'">'.$data['data'][0]['appName'].'</a></p>';

                                }
                }
              ?>
             
            
              
              
             
            
            
             

                           
              </div>
              </div>


</div>




 <div id="id01" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id01').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Update Basic details</h4>
                    </header>
                    
                    <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('VM/edit_clone'); ?>
                          
                            <p id="basicExample">
                            <label>clone name</label>
                            <input class="w3-input date" type="text" name="c_name" value="<?php echo $data[0]['clone']['name'];?>"></p>
                       
                            <p>
                            
                            <p>
                            <label>clone date</label>
                            <input class="w3-input" type="date" name="c_date" value="<?php echo $data[0]['clone']['date'];?>"></p>
                           
                            <p>

                            <p>
                            <label>Remark</label>
                            <input class="w3-input" type="text" name="remark" value="<?php echo $data[0]['clone']['remarks'];?>"></p>                        
                            <p>
                            <br>

                            <input type="hidden" name="vm_id" value="<?php  echo $data[0]['_id'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >

                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>





 <div id="id02" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id02').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Update basic details</h4>
                    </header>
                    
                    <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('VM/edit_basic'); ?>
                          
                            <p>
                            <label>Vm Function:</label>
                            <input class="w3-input" type="text" name="vm_function" value="<?php echo $data[0]['VMFunction'];?>"></p>
                       
                            <p>
                            
                            <p>
                            <label>Host Name:</label>
                            <input class="w3-input" type="text" name="vm_name" value="<?php echo $data[0]['hostName'];?>"></p>

														<p>
                            <label>Created on:</label>
                            <input class="w3-input" type="date" name="date" value="<?php echo $data[0]['date'];?>"></p>
                           
                            <p>

                              <p>
                            <label>used by:</label>
                            <input class="w3-input" type="text" name="ugroup" value="<?php echo $data[0]['user_group'];?>"></p>
                           
                            <p>
                            <p>
                            <label>Server type:</label>
                            <select class="w3-select" name="type" >
                            
                            <?php
                                  $typelist = array('stagging','production');
                                  $stype=$data[0]['serverType'];
                                  foreach ($typelist as $type ){
                                    if($type == $stype){
                                        $selected ='selected';
                                       
                                    echo '<option   selected="'.$selected.' " value="'.$stype.'">'.$stype.'</option>';
                                    }else{
                                     echo '<option    " value="'.$type.'">'.$type.'</option>';
                                    }

                                     
                                 }


                            ?>
                            </select>                       
                            <p>


                            <p>
                            <label>VM status:</label>
                            <select class="w3-select" name="vm_status" >
                            
                            <?php
                                  $typelist = array('online','offline');
                                  $stype=$data[0]['status'];
                                  foreach ($typelist as $type ){
                                    if($type == $stype){
                                        $selected ='selected';
                                       
                                    echo '<option   selected="'.$selected.' " value="'.$stype.'">'.$stype.'</option>';
                                    }else{
                                     echo '<option    " value="'.$type.'">'.$type.'</option>';
                                    }

                                     
                                 }


                            ?>
                            </select>                       
                            <p>
                            <br>

                            <input type="hidden" name="vm_id" value="<?php  echo $data[0]['_id'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >

                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>



 <div id="id03" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id03').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Update Basic details</h4>
                    </header>
                    
                    <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('VM/edit_hardware'); ?>
                          
                            <p>
                            <label>RAM</label>
                            <input class="w3-input" type="text" name="ram" value="<?php echo $data[0]['vHardware']['ram'];?>"></p>
                       
                            <p>
                            
                            <p>
                            <label>HDD</label>
                            <input class="w3-input" type="text" name="hdd" value="<?php echo $data[0]['vHardware']['HDD'];?>"></p>

                            <p>
                            <label>HDD utilized</label>
                            <input class="w3-input" type="text" name="hdd_uti" value="<?php echo $data[0]['vHardware']['HDD_Utilized'];?>"></p>

                           
                            <p>

                            <p>
                            <label>Processor</label>
                            <input class="w3-input" type="text" name="processor" value="<?php echo $data[0]['vHardware']['processor'];?>"></p>                        
                            <p>


                            <p>
                            <label>Remark</label>
                            <input class="w3-input" type="text" name="hardware_remark" value="<?php echo $data[0]['vHardware']['remark'];?>"></p>
                            <br>

                            <input type="hidden" name="vm_id" value="<?php  echo $data[0]['_id'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >

                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>




            <div id="id04" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id04').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Update sofware info details</h4>
                    </header>
                    
                    <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('VM/edit_software_info'); ?>
                          
                            <p>
                            <label>operating system</label>
                            <input class="w3-input" type="text" name="os" value="<?php echo $data[0]['os'];?>"></p>
                       
                            <p>

                             <p>
                            <label>anti virus type</label>
                            <input class="w3-input" type="text" name="antivirus" value="<?php echo $data[0]['antiVirus']['antiVirus'];?>"></p>
                       
                            <p>

                             <p>
                            <label>anti virus license</label>
                            <input class="w3-input" type="text" name="licence" value="<?php echo $data[0]['antiVirus']['licence'];?>"></p>
                       
                            <p>

                             <p>
                            <label>anti virus expiry date</label>
                            <input class="w3-input" type="text" name="date" value="<?php echo $data[0]['antiVirus']['expiryDate'];?>"></p>
                       
                            <p>
                            
                                                     
                            <br>

                            <input type="hidden" name="vm_id" value="<?php  echo $data[0]['_id'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >

                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>


            


            <div id="id06" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id06').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Update Network details</h4>
                    </header>
                    
                    <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('VM/edit_network_info'); ?>
                          
                            <p>
                            <label>Public IP</label>
                            <input class="w3-input" type="text" name="public_ip" value="<?php echo $data[0]['ips']['public'];?>"></p>
                       
                            <p>
                            <p>
                            <label>Private IP</label>
                            <input class="w3-input" type="text" name="private_ip" value="<?php echo $data[0]['ips']['private'];?>"></p>
                       
                            <p>
                            <p>
                            <label>Gateway IP</label>
                            <input class="w3-input" type="text" name="gateway_ip" value="<?php echo $data[0]['ips']['gateway'];?>"></p>
                       
                           



                            <label>Internet</label><br>

                            <input type="radio" name="internet" <?php if($data[0]['internet']=="1"){echo 'checked="true"';}?> value="1" >Yes &nbsp;
                            <input type="radio" name="internet" <?php if($data[0]['internet']=="0"){echo 'checked="true"';}?>  value="0">No

                                 


                                 



                            <br>                       
                            <br>

                            <input type="hidden" name="vm_id" value="<?php  echo $data[0]['_id'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >

                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>
 


             <div id="id05" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id05').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Add New Web/App</h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('VM/insert'); ?>
                          
                            <input type="radio"  name="type" onclick="my1();" value="new"> New &nbsp;
                            <input type="radio"  name="type" onclick="my2();" value="migrate"> Migrate   
                               

                            <p>
                            <br>
                            <label id="change">Web/App Name</label>
                            <input class="w3-input" type="text" name="web_name"></p>
                            <input type="hidden" name="vm_id" value="<?php  echo $data[0]['_id'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >
                            <p>
                            
                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>



             <div id="id07" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id07').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Additional Softwares installed</h4>
                    </header>
                    
                    <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('VM/additional_soft'); ?>
                          
                            <p>
                            <label>Softwares</label>
                            <textarea class="w3-input" type="text" name="soft" ><?php echo $data[0]['thirdParty']['softwares'];?></textarea></p>
                       
                            <p>
                            <p>
                            <label>client justification</label>
                            <textarea class="w3-input" type="text" name="just" ><?php echo $data[0]['thirdParty']['client_justification'];?></textarea></p>
                       
                            <p>
                            <p>
                            <label>remarks</label>
                            <textarea class="w3-input" type="text" name="remarks"><?php echo $data[0]['thirdParty']['remarks'];?></textarea></p>
                    
                            <br>                       
                            <br>

                            <input type="hidden" name="vm_id" value="<?php  echo $data[0]['_id'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >

                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>



						<div id="id08" class="w3-modal" >
                <div class="w3-modal-content w3-animate-zoom w3-card-4" style="width:40%;">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id08').style.display='none'" 
                        class="w3-button w3-display-topright">&times;</span>
                        <h4>Add to Tape Backup</h4>
                    </header>
                    
                        <div class="w3-container w3-margin-top">
                            <?php echo validation_errors(); ?>
                            <?php echo form_open('VM/add_tape'); ?>
                          
                           

                            <p>
                            <label>Job ID</label>
                            <input class="w3-input" type="text" name="job_id"></p>

														<p>
                            <label>Job Name</label>
                            <input class="w3-input" type="text" name="job_name"></p>
														
														<p>
                            <label>Path</label>
                            <input class="w3-input" type="text" name="path"></p>

														<p>
                            <label>Date</label>
                            <input class="w3-input" type="date" name="date"></p>
                            
                           
                            
														<input type="hidden" name="hostname" value="<?php  echo $data[0]['hostName'];?>">
                            <input type="hidden" name="current" value="<?php echo current_url();?>" >
														<input type="hidden" name="id" value="<?php echo $data[0]['_id'];?>" >

														<p>
                            <input class="w3-button w3-round w3-teal" type="submit"></p>
                            <?php echo form_close();?>
                        </div>

                          <footer class="w3-container w3-teal">
                        <p></p>
                        </footer>
                </div>
            </div>



           

<script>
function my1() {
  document.getElementById("change").innerHTML = "Web/App Name";
}
function my2() {
  document.getElementById("change").innerHTML = "Web/App migrate ID";
}
</script>
