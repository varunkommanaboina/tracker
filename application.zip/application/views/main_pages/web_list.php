
		



<style>





table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #4CAF50;
  color: white;
}




</style>



		

			<div class="w3-container" style="padding-top:5px;">
										
							
						<?php

							
	

							echo '<table>
								<tr>
								<th>App Name</th>
								<th>deptname</th>
								<th>type</th>
								<th>hostingDetails</th>
								<th>vendorName</th>
								<th>contactNo</th>
							
								</tr>';
							
							$arrlength = count($data);
							
							$x=0;


							for ($i=0;$i<$arrlength;$i++){

								$x++;

								echo '<tr>';
								
								echo	'<td>'.$data[$i]['appName'].'</td>';
								echo 	'<td>'.$data[$i]['deptname'].'</td>';
								echo 	'<td>'.$data[$i]['type'].'</td>';
								echo 	'<td>'.$data[$i]['hostingDetails']['hostingType'].'</td>';
								echo 	'<td>'.$data[$i]['vendorDetails']['vendor'].'</td>';
								echo 	'<td>'.$data[$i]['vendorDetails']['contactNo'].'</td>';
								echo '</tr>'; 
								


							}

							echo '</table>'
						

 
						

						?>
							<br>

			
							

  





			</div>







