<div class="row">.</div>
<div class="row">
            <div class="col-sm-8" style="">
            <h1 class="w3-myfont" style="color:#e0ff33;font-size:42px;text-align:center;padding-top:260px;"><b>We Hope This Tool Will Make Your Life Easier @ workplace</b></h1>
						<h3 class="w3-myfont" style="color:#e0ff33;text-align:center;padding-top:30px;"><b>Now bits and bytes of Information on your finger tips </b></h3>
            </div>
            
            <div class="col-sm-4" style="margin-top:50px;">
                      <div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width:300px;border-radius:10px;font-size:10px;padding:10px;">
                       <div class="w3-left" style="width:100%"><div><image src="<?php echo base_url(); ?>assets/css/logo.png" style="height:50px;"></image></div></div>
                        <div class="w3-center" style="font-family: 'Anton', sans-serif; font-size:25px;">
                         MY TRACKER
                        </div>
                        <div class="w3-center" style="font-family: 'Anton', sans-serif; font-size:15px;">
                        <?php echo $title;?>
                        </div>
                        <div class="w3-center">

                          <img src="<?php echo base_url(); ?>assets/css/avatar/avatar.png" alt="Avatar" style="width:20%" class="w3-circle w3-margin-top">
                        </div>
                   
									    <br><?php echo validation_errors(); ?>
					             <?php echo form_open('users/login'); ?>
                        <div class="w3-section">
                          <label><b>Username</b></label>
                          <input class="w3-input w3-border w3-margin-bottom" type="text" placeholder="Enter Username" name="username" >
                          <label><b>Password</b></label>
                          <input class="w3-input w3-border" type="password" placeholder="Enter Password" name="password" >
						              <input class="w3-button w3-block w3-green w3-section w3-padding" type="submit" name="submit" value="Login">
                          
                        </div>
                      <?php echo form_close(); ?>

                       

