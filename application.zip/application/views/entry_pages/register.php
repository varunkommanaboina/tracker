<div class="row">.</div>
<div class="row">
            <div class="col-sm-6" style="">
            <h1 class="w3-myfont" style="color:#e0ff33;font-size:42px;text-align:center;padding-top:260px;"><b>We Hope This Tool Will Make Your Life Easier @ workplace</b></h1>
						<h3 class="w3-myfont" style="color:#e0ff33;text-align:center;padding-top:30px;"><b>Now bits and bytes of Information on your finger tips </b></h3>
            </div>
            
            <div class="col-sm-6" style="">
                      <div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width:600px;border-radius:10px;font-size:10px;padding:7px 7px 1px 7px;">
                       <div class="w3-left" style="width:100%"><div><image src="<?php echo base_url(); ?>assets/css/logo.png" style="height:50px;"></image></div></div>
                        <div class="w3-center" style="font-family: 'Anton', sans-serif; font-size:25px;">
                         MY TRACKER
                        </div>
                        <div class="w3-center" style="font-family: 'Anton', sans-serif; font-size:15px;">
                        <?php echo $title;?>
                        </div>
                        <div class="w3-center">

                          <img src="<?php echo base_url(); ?>assets/css/avatar/avatar.png" alt="Avatar" style="width:20%" class="w3-circle w3-margin-top">
                        </div>
					
						<br><?php echo validation_errors(); ?>
						<?php echo form_open('users/register'); ?>
                        <div class="w3-section">
                    
													<div class="w3-half" style="padding-right:10px;">
													<label><b>Username</b></label>
													<input class="w3-input w3-border w3-margin-bottom" type="text" name="name" required>
													<label><b>User email</b></label>
													<input class="w3-input w3-border w3-margin-bottom" type="text" name="email" required>
													<label><b>DOB</b></label>
													<input class="w3-input w3-border w3-margin-bottom" type="date" name="DOB" required>
													<label><b>password</b></label>
													<input class="w3-input w3-border w3-margin-bottom" type="password" name="password" required>
													<label><b>confirm password</b></label>
													<input class="w3-input w3-border w3-margin-bottom" type="password" name="password2" required>
													
													</div>
													<div class="w3-half" style="padding-left:10px;">
													<label><b>EmpID</b></label>
													<input class="w3-input w3-border w3-margin-bottom" type="text" name="empid" required>
													<label><b>DOJ</b></label>
													<input class="w3-input w3-border w3-margin-bottom" type="date" name="DOJ" required>
													<label><b>level</b></label>
													<input class="w3-input w3-border w3-margin-bottom" type="text" name="level" required>
													<label><b>department</b></label>
													<input class="w3-input w3-border w3-margin-bottom" type="text" name="dept" required>
													<label><b>designation</b></label>
													<input class="w3-input w3-border w3-margin-bottom" type="text" name="desig" required>
													</div>

													  <input class="w3-button w3-block w3-green w3-section w3-padding" type="submit" name="submit" value="Register" >

                        </div>
						<?php echo form_close(); ?>
            
