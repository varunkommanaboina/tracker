<!DOCTYPE html>
<html>
<title>Tracker</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/w3.css">
<link href="https://fonts.googleapis.com/css?family=Anton" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
 <script src="js/jquery.min.js"></script>
 <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
 <link href="https://fonts.googleapis.com/css?family=Averia+Libre|Rammetto+One" rel="stylesheet">
<body >
<style>
body{
  background-image: url("<?php echo base_url(); ?>assets/css/bg.jpeg");
}
.w3-myfont {


      font-family: 'Rammetto One', cursive;

      font-family: 'Averia Libre', cursive;


}

</style>

