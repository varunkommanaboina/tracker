
/** ESXI indexes **/
db.getCollection("ESXI").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** SR indexes **/
db.getCollection("SR").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** VM indexes **/
db.getCollection("VM").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** VPN indexes **/
db.getCollection("VPN").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** calendar indexes **/
db.getCollection("calendar").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** employee indexes **/
db.getCollection("employee").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** patches indexes **/
db.getCollection("patches").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** port indexes **/
db.getCollection("port").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** shiftRegister indexes **/
db.getCollection("shiftRegister").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** tape_backup indexes **/
db.getCollection("tape_backup").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** test indexes **/
db.getCollection("test").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** visits indexes **/
db.getCollection("visits").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** volumes indexes **/
db.getCollection("volumes").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** web indexes **/
db.getCollection("web").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** ESXI records **/
db.getCollection("ESXI").insert({
  "_id": ObjectId("5d0f0018275b2f8001000035"),
  "cloud": "Application",
  "serverName": "GOASDCAPP01",
  "serverIp": "10.189.47.1",
  "vms": [
    
  ],
  "hardware": {
    "ram": "100",
    "HDD": "10000",
    "processor": "40",
    "processor_cores": "5",
    "processor_core": null
  },
  "make": "CISCO",
  "model": "CISCO 120",
  "os": "ESXI OS",
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-06-23T04:29:12.0Z"),
      "comment": "dsadas"
    },
    {
      "commentid": NumberInt(958082212),
      "commentby": null,
      "comment": "<p>sds adasd</p>\r\n",
      "date": "date"
    },
    {
      "commentid": NumberInt(576041076),
      "commentby": null,
      "comment": "<p>dsa das</p>\r\n",
      "date": "date"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5d0f0026275b2f8401000030"),
  "cloud": "Application",
  "serverName": "GOASDCAPP02",
  "serverIp": "",
  "vms": [
    ObjectId("5d0f6da45d5bacfc2000002a"),
    ObjectId("5d0f6d965d5bacfc20000029")
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": "",
    "processor_cores": ""
  },
  "make": "",
  "model": "",
  "os": "",
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-06-23T04:29:26.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5d0f0044275b2f8001000036"),
  "cloud": "ems",
  "serverName": "GOASDCEMS01",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": "",
    "processor_cores": ""
  },
  "make": "",
  "model": "",
  "os": "",
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-06-23T04:29:56.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5d0f0055275b2f8401000031"),
  "cloud": "ems",
  "serverName": "GOASDCEMS02",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": "",
    "processor_cores": ""
  },
  "make": "",
  "model": "",
  "os": "",
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-06-23T04:30:13.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5d0f0067275b2f8001000037"),
  "cloud": "database",
  "serverName": "GOASDCDB01",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": "",
    "processor_cores": ""
  },
  "make": "",
  "model": "",
  "os": "",
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-06-23T04:30:31.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5d0f0076275b2f8401000032"),
  "cloud": "database",
  "serverName": "GOASDCDB02",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": "",
    "processor_cores": ""
  },
  "make": "",
  "model": "",
  "os": "",
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-06-23T04:30:46.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});

/** SR records **/

/** VM records **/
db.getCollection("VM").insert({
  "_id": ObjectId("5d0f6d965d5bacfc20000029"),
  "ESXI_HOST": ObjectId("5d0f0026275b2f8401000030"),
  "VMFunction": "HMIS APP 01",
  "hostName": "",
  "date": "date",
  "status": "offline",
  "user_group": "",
  "vHardware": {
    "ram": "",
    "HDD": "",
    "HDD_Utilized": "",
    "processor": "",
    "remark": ""
  },
  "volume": "APP DATA 03",
  "serverType": "",
  "RDlogins": [
    
  ],
  "ips": {
    "public": "",
    "private": "",
    "gateway": ""
  },
  "port": [
    
  ],
  "internet": "",
  "os": "windows 2012R2",
  "patches": {
    "patch": "patch id collection",
    "date": "12-07-1018",
    "updatedBy": "arjun",
    "status": "yes",
    "comments": "comments"
  },
  "softwaresInstalled": [
    {
      "name": "wamp",
      "licence": "no",
      "remarks": "text"
    },
    {
      "name": "ms sql",
      "licence": "yes",
      "remarks": "text"
    }
  ],
  "antiVirus": {
    "antiVirus": "type",
    "licence": "text",
    "expiryDate": "date"
  },
  "storage": {
    "Backupdate": "date",
    "sourcecodeDir": "",
    "sourcecodeDirSize": "",
    "backupTap": "yes",
    "backupToTapeOn": "date",
    "backupToTapeby": ""
  },
  "webapps": [
    ObjectId("5d1141e7275b2f800100003f")
  ],
  "SrNo": [
    
  ],
  "visits": [
    
  ],
  "comments": [
    {
      "commentId": "",
      "commentby": "",
      "date": "",
      "comment": ""
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "clone": {
    "name": "",
    "date": "",
    "remarks": ""
  },
  "thirdParty": {
    "softwares": "",
    "client_justification": "",
    "remarks": "sadsadsadsadddsadsadassss"
  },
  "tape": "376820497"
});
db.getCollection("VM").insert({
  "_id": ObjectId("5d0f6da45d5bacfc2000002a"),
  "ESXI_HOST": ObjectId("5d0f0026275b2f8401000030"),
  "VMFunction": "HMIS APP 02",
  "hostName": "",
  "date": "date",
  "status": "offline",
  "user_group": "",
  "vHardware": {
    "ram": "",
    "HDD": "",
    "HDD_Utilized": "",
    "processor": "",
    "remark": ""
  },
  "volume": "APP DATA 2",
  "serverType": "",
  "RDlogins": [
    
  ],
  "ips": {
    "public": "",
    "private": "",
    "gateway": ""
  },
  "port": [
    
  ],
  "internet": "",
  "os": "windows 2012R2",
  "patches": {
    "patch": "patch id collection",
    "date": "12-07-1018",
    "updatedBy": "arjun",
    "status": "yes",
    "comments": "comments"
  },
  "softwaresInstalled": [
    {
      "name": "wamp",
      "licence": "no",
      "remarks": "text"
    },
    {
      "name": "ms sql",
      "licence": "yes",
      "remarks": "text"
    }
  ],
  "antiVirus": {
    "antiVirus": "type",
    "licence": "text",
    "expiryDate": "date"
  },
  "storage": {
    "Backupdate": "date",
    "sourcecodeDir": "",
    "sourcecodeDirSize": "",
    "backupTap": "yes",
    "backupToTapeOn": "date",
    "backupToTapeby": ""
  },
  "webapps": [
    ObjectId("5d0f707f5d5bacfc2000002c"),
    ObjectId("5d0f70705d5bacfc2000002b")
  ],
  "SrNo": [
    
  ],
  "visits": [
    
  ],
  "comments": [
    {
      "commentId": "",
      "commentby": "",
      "date": "",
      "comment": ""
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "clone": {
    "name": "",
    "date": "",
    "remarks": ""
  },
  "thirdParty": {
    "softwares": "",
    "client_justification": "",
    "remarks": "sadsadsadsadddsadsadassss"
  },
  "tape": ""
});

/** VPN records **/
db.getCollection("VPN").insert({
  "_id": ObjectId("5d0f2422275b2f800100003c"),
  "vpno": "338162385",
  "vpntype": "web application",
  "destination": "10.189.47.176",
  "VmName": "hmis",
  "service": "service",
  "date": "2019-06-23",
  "vpn_username": "sadsadasdasds",
  "server_username": "dsadsadasdsd",
  "requester": "requester",
  "vendor": "vendorNamedddg rgregreg",
  "contact": "contact",
  "remark": "dsada sdsa dasd asd   a sadsadsa",
  "LOU": "226136947.jpg"
});

/** calendar records **/
db.getCollection("calendar").insert({
  "_id": ObjectId("5d127ead275b2f005f000029"),
  "event_id": "660352287",
  "emp_name": "varun",
  "event_title": "new post by me",
  "date": "2019-06-01",
  "reference": "dsadsad ",
  "decription": "sad sadsadsad",
  "display": "0",
  "comments": [
    
  ]
});
db.getCollection("calendar").insert({
  "_id": ObjectId("5d127ebd275b2f005f00002a"),
  "event_id": "747234541",
  "emp_name": "varun",
  "event_title": "dasd sads dsadsadas",
  "date": "2019-06-02",
  "reference": "dsa dasd sads dsa dsa",
  "decription": "d asdssdasd a",
  "display": "1",
  "comments": [
    
  ]
});
db.getCollection("calendar").insert({
  "_id": ObjectId("5d127ed7275b2f005f00002b"),
  "event_id": "155303976",
  "emp_name": "dilip",
  "event_title": "sad sadsadsd",
  "date": "2019-06-01",
  "reference": " dsadsad",
  "decription": "sadsadas d asdad",
  "display": "0",
  "comments": [
    
  ]
});

/** employee records **/
db.getCollection("employee").insert({
  "_id": ObjectId("5c268c9f5d5bac4417000029"),
  "name": "varun",
  "email": "varun@gmail.com",
  "password": "5f4dcc3b5aa765d61d8327deb882cf99",
  "DOB": "",
  "empid": "",
  "DOJ": "",
  "Plevel": "",
  "dept": "",
  "designation": "",
  "locked": NumberInt(0),
  "gender": "",
  "username": {
    "fname": "",
    "lname": ""
  }
});
db.getCollection("employee").insert({
  "_id": ObjectId("5d1309e4275b2f3011000029"),
  "name": "dilip",
  "email": "dilip@gmail.com",
  "password": "5f4dcc3b5aa765d61d8327deb882cf99",
  "empid": "343242342",
  "DOB": "2019-06-12",
  "DOJ": null,
  "Plevel": "2",
  "dept": "server",
  "designation": "server admin",
  "locked": "0",
  "gender": "",
  "username": {
    "fname": "",
    "lname": ""
  }
});
db.getCollection("employee").insert({
  "_id": ObjectId("5d130a68275b2f5c5e000029"),
  "name": "ragesh",
  "email": "ragesh@gmail.com",
  "password": "5f4dcc3b5aa765d61d8327deb882cf99",
  "empid": "434234",
  "DOB": "2019-06-14",
  "DOJ": null,
  "Plevel": "2",
  "dept": "server",
  "designation": "developer",
  "locked": "0",
  "gender": "",
  "username": {
    "fname": "",
    "lname": ""
  }
});

/** patches records **/

/** port records **/
db.getCollection("port").insert({
  "_id": ObjectId("5be5b876275b2f5016000044"),
  "portNo": "80",
  "portName": "http",
  "reqBy": "client",
  "reason": "test",
  "timePeriod": "1hr",
  "securityThreat": "sql injection",
  "from": "10.189.47.75",
  "to": "10.189.47.74"
});
db.getCollection("port").insert({
  "_id": ObjectId("5be5b8bd275b2f2011000031"),
  "portNo": "80",
  "portName": "http",
  "reqBy": "client",
  "reason": "test",
  "timePeriod": "1hr",
  "securityThreat": "sql injection",
  "from": "10.189.47.75",
  "to": "10.189.47.74"
});
db.getCollection("port").insert({
  "_id": ObjectId("5be5b8ce275b2f5016000045"),
  "portNo": "80",
  "portName": "http",
  "reqBy": "client",
  "reason": "test",
  "timePeriod": "1hr",
  "securityThreat": "sql injection",
  "from": "10.189.47.75",
  "to": "10.189.47.74"
});

/** shiftRegister records **/
db.getCollection("shiftRegister").insert({
  "_id": ObjectId("5be48768275b2f201100002e"),
  "date": "2018-11-08 00:00:01",
  "name": "varun",
  "shift": NumberInt(1),
  "Activities": [
    "dasdasda",
    "asdasdasd",
    "dasdasdasdas",
    "adsdasdsa"
  ],
  "comments": [
    {
      "commentBy": "varun",
      "date": ISODate("2018-11-08T18:58:48.0Z"),
      "comment": "sample comment"
    },
    {
      "commentBy": "varun",
      "date": ISODate("2018-11-08T18:58:48.0Z"),
      "comment": "sample comment 2"
    }
  ]
});
db.getCollection("shiftRegister").insert({
  "_id": ObjectId("5be4877f275b2fe40b00002f"),
  "date": "2018-11-09 00:00:12",
  "name": "nagesh",
  "shift": NumberInt(1),
  "Activities": [
    "dasdasda",
    "asdasdasd",
    "dasdasdasdas",
    "adsdasdsa"
  ],
  "comments": [
    {
      "commentBy": "varun",
      "date": ISODate("2018-11-08T18:59:11.0Z"),
      "comment": "sample comment"
    },
    {
      "commentBy": "varun",
      "date": ISODate("2018-11-08T18:59:11.0Z"),
      "comment": "sample comment 2"
    }
  ]
});
db.getCollection("shiftRegister").insert({
  "_id": ObjectId("5c0452f95d5bac4c04000029"),
  "date": "2018-11-19",
  "name": "nagesh",
  "shift": NumberInt(1),
  "Activities": [
    "dasdasda",
    "asdasdasd",
    "dasdasdasdas",
    "adsdasdsa"
  ],
  "comments": [
    {
      "commentBy": "varun",
      "date": ISODate("2018-11-08T18:59:11.0Z"),
      "comment": "sample comment"
    },
    {
      "commentBy": "varun",
      "date": ISODate("2018-11-08T18:59:11.0Z"),
      "comment": "sample comment 2"
    }
  ]
});

/** tape_backup records **/
db.getCollection("tape_backup").insert({
  "_id": ObjectId("5d112080275b2f840100003a"),
  "tape_id": "376820497",
  "job_id": "1323233213dsadsad",
  "job_name": "hmis backup3333sdasd",
  "hostname": "33333333sadsadasd",
  "date": "2019-06-07",
  "source_path": "c://4adsa/dasddsa31232133asdsad",
  "backup": [
    {
      "entry_id": "487225358",
      "date": "2019-06-01",
      "size": "32",
      "status": "dsdsdd",
      "remark": "remarks if anyddd"
    },
    {
      "entry_id": "715277381",
      "date": "2019-06-02",
      "size": "32",
      "status": "dsdsdd",
      "remark": "remarks if anyddd"
    },
    {
      "entry_id": "839235597",
      "date": "2019-06-04",
      "size": "32",
      "status": "success",
      "remark": "remarks if anyddd"
    }
  ]
});

/** test records **/
db.getCollection("test").insert({
  "_id": ObjectId("5c48ed7f5d5bac881d000029"),
  "cloud": null,
  "serverName": null,
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": ""
  },
  "SrNo": [
    
  ]
});

/** visits records **/

/** volumes records **/
db.getCollection("volumes").insert({
  "_id": ObjectId("5d0f0098275b2f8001000038"),
  "Cluster_name": "Application",
  "Volume name": "APP DATA 01",
  "lunno": "269083723",
  "allocated_space": "1000",
  "used_by": "dept",
  "date": "2019-06-23"
});
db.getCollection("volumes").insert({
  "_id": ObjectId("5d0f00b5275b2f8401000033"),
  "Cluster_name": "Application",
  "Volume name": "APP DATA 2",
  "lunno": "620767175",
  "allocated_space": "3000",
  "used_by": "dept",
  "date": "2019-06-23"
});
db.getCollection("volumes").insert({
  "_id": ObjectId("5d0f00c7275b2f8001000039"),
  "Cluster_name": "Application",
  "Volume name": "APP DATA 03",
  "lunno": "774612641",
  "allocated_space": "200",
  "used_by": "dept",
  "date": "2019-06-23"
});
db.getCollection("volumes").insert({
  "_id": ObjectId("5d0f161b275b2f8401000034"),
  "Cluster_name": "ems",
  "Volume name": "EMS DATA02",
  "lunno": "962618390",
  "allocated_space": "20000",
  "used_by": "DCOo",
  "date": "2019-06-21"
});
db.getCollection("volumes").insert({
  "_id": ObjectId("5d0f165c275b2f800100003a"),
  "Cluster_name": "database",
  "Volume name": "DATABASE DATA 01",
  "lunno": "617938162",
  "allocated_space": "10000",
  "used_by": "DCO",
  "date": "2019-06-23"
});

/** web records **/
db.getCollection("web").insert({
  "_id": ObjectId("5d0f70705d5bacfc2000002b"),
  "VM_ID": ObjectId("5d0f6da45d5bacfc2000002a"),
  "hostingDetails": {
    "hostingType": "staging",
    "date": "date",
    "remark": "remarks if any",
    "status": ""
  },
  "type": "web application",
  "appName": "10.189.47.176/hmis1111",
  "deptname": "itipanaji",
  "vendorDetails": {
    "vendor": "vendorName",
    "contactPerson": "text",
    "email": "email@email.com",
    "contactNo": "43243423432",
    "designation": "developer"
  },
  "connectivity": {
    "VPN": "VPN collection id",
    "RDP": "rdp collection id"
  },
  "url": "http://wenbsite.com",
  "auditCert": {
    "status": "0",
    "valid": "0",
    "validatedBy": "company",
    "issuedate": "date",
    "expdate": "date",
    "path": "soft copy path",
    "remark": "text"
  },
  "ssl": {
    "status": "0",
    "expiration": ""
  },
  "webServer": "apache",
  "databaseSoftware": "mysql",
  "visits": [
    
  ],
  "SrNo": [
    
  ],
  "comments": [
    
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ]
});
db.getCollection("web").insert({
  "_id": ObjectId("5d0f707f5d5bacfc2000002c"),
  "VM_ID": ObjectId("5d0f6da45d5bacfc2000002a"),
  "hostingDetails": {
    "hostingType": "staging",
    "date": "date",
    "remark": "remarks if any",
    "status": ""
  },
  "type": "web application",
  "appName": "10.189.47.176/hmis2222",
  "deptname": "itipanaji",
  "vendorDetails": {
    "vendor": "vendorName",
    "contactPerson": "text",
    "email": "email@email.com",
    "contactNo": "43243423432",
    "designation": "developer"
  },
  "connectivity": {
    "VPN": "VPN collection id",
    "RDP": "rdp collection id"
  },
  "url": "http://wenbsite.com",
  "auditCert": {
    "status": "0",
    "valid": "0",
    "validatedBy": "company",
    "issuedate": "date",
    "expdate": "date",
    "path": "soft copy path",
    "remark": "text"
  },
  "ssl": {
    "status": "1",
    "expiration": "2019-06-13"
  },
  "webServer": "apache",
  "databaseSoftware": "mysql",
  "visits": [
    
  ],
  "SrNo": [
    
  ],
  "comments": [
    
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ]
});
db.getCollection("web").insert({
  "_id": ObjectId("5d1141e7275b2f800100003f"),
  "VM_ID": ObjectId("5d0f6d965d5bacfc20000029"),
  "hostingDetails": {
    "hostingType": "staging",
    "date": "date",
    "remark": "remarks if any",
    "status": ""
  },
  "type": "web application",
  "appName": "10.189.47.176/hmis/login.aspx",
  "deptname": "itipanaji",
  "vendorDetails": {
    "vendor": "vendorName",
    "contactPerson": "text",
    "email": "email@email.com",
    "contactNo": "43243423432",
    "designation": "developer"
  },
  "connectivity": {
    "VPN": "VPN collection id",
    "RDP": "rdp collection id"
  },
  "url": "http://wenbsite.com",
  "auditCert": {
    "status": "0",
    "valid": "0",
    "validatedBy": "company",
    "issuedate": "date",
    "expdate": "date",
    "path": "soft copy path",
    "remark": "text"
  },
  "ssl": {
    "status": "0",
    "expiration": ""
  },
  "webServer": "apache",
  "databaseSoftware": "mysql",
  "visits": [
    
  ],
  "SrNo": [
    
  ],
  "comments": [
    
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ]
});
