
/** ESXI indexes **/
db.getCollection("ESXI").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** SR indexes **/
db.getCollection("SR").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** VM indexes **/
db.getCollection("VM").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** VPN indexes **/
db.getCollection("VPN").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** employee indexes **/
db.getCollection("employee").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** patches indexes **/
db.getCollection("patches").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** port indexes **/
db.getCollection("port").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** shiftRegister indexes **/
db.getCollection("shiftRegister").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** test indexes **/
db.getCollection("test").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** visits indexes **/
db.getCollection("visits").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** web indexes **/
db.getCollection("web").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** ESXI records **/
db.getCollection("ESXI").insert({
  "_id": ObjectId("5cbf2ef4275b2fe81c00002f"),
  "cloud": "Application",
  "serverName": "APP01",
  "serverIp": "10.189.47.14",
  "vms": [
    ObjectId("5cbf81a8275b2fd40b00002c")
  ],
  "hardware": {
    "ram": "3",
    "HDD": "250",
    "processor": "120",
    "processor_core": "33"
  },
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-04-23T15:27:48.0Z"),
      "comment": "dsadas"
    },
    {
      "commentid": NumberInt(745599443),
      "commentby": "varun",
      "comment": "<p>test</p>\r\n",
      "date": "date"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ],
  "make": "434343 fdfdsfdsdsdasd",
  "model": "43434dsadsad",
  "os": "dsadasd"
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5cbf2efd275b2fe81c000030"),
  "cloud": "Application",
  "serverName": "APP02",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "3",
    "HDD": "300",
    "processor": "3"
  },
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-04-23T15:27:57.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5cbf2f08275b2fe81c000031"),
  "cloud": "Application",
  "serverName": "APP03",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": ""
  },
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-04-23T15:28:08.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5cbf2f12275b2fe81c000032"),
  "cloud": "database",
  "serverName": "DB01",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": ""
  },
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-04-23T15:28:18.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5cbf2f1c275b2fe81c000033"),
  "cloud": "database",
  "serverName": "DB02",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": ""
  },
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-04-23T15:28:28.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5cbf2f29275b2fe81c000034"),
  "cloud": "ems",
  "serverName": "EMS01",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": ""
  },
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-04-23T15:28:41.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});
db.getCollection("ESXI").insert({
  "_id": ObjectId("5cbf2f34275b2fe81c000035"),
  "cloud": "ems",
  "serverName": "EMS03",
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": ""
  },
  "comments": [
    {
      "commentid": "43243242",
      "commentby": "varun",
      "date": ISODate("2019-04-23T15:28:52.0Z"),
      "comment": "dsadas"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "SrNo": [
    
  ]
});

/** SR records **/
db.getCollection("SR").insert({
  "_id": ObjectId("5cbf81d3275b2fd40b00002d"),
  "srno": "S1234",
  "parent_collection": "VM",
  "parent_ID": ObjectId("5cbf81a8275b2fd40b00002c"),
  "date": "date",
  "requestRaisedBy": "varun",
  "AssignedTo": "varun",
  "title": "test",
  "Desscription": "test",
  "solution": "test",
  "status": "closed",
  "comments": [
    {
      "commentid": NumberInt(555395311),
      "commentby": "varun",
      "comment": "<p>dasd sdasd</p>\r\n",
      "date": "date"
    },
    {
      "commentid": NumberInt(704281522),
      "commentby": "varun",
      "comment": "<p>sa das dasd</p>\r\n",
      "date": "date"
    }
  ]
});

/** VM records **/
db.getCollection("VM").insert({
  "_id": ObjectId("5cbf81a8275b2fd40b00002c"),
  "ESXI_HOST": ObjectId("5cbf2ef4275b2fe81c00002f"),
  "VMFunction": "hmis",
  "hostName": "sdsadsad",
  "vHardware": {
    "ram": "3",
    "HDD": "5000",
    "processor": "44",
    "HDD_Utilized": "50",
    "remark": "can be reductied"
  },
  "serverType": "production",
  "RDlogins": [
    
  ],
  "ips": {
    "public": "",
    "private": "",
    "gateway": ""
  },
  "port": [
    
  ],
  "internet": "",
  "os": "windows 2012R2",
  "patches": {
    "patch": "patch id collection",
    "date": "12-07-1018",
    "updatedBy": "arjun",
    "status": "yes",
    "comments": "comments"
  },
  "softwaresInstalled": [
    {
      "name": "wamp",
      "licence": "no",
      "remarks": "text"
    },
    {
      "name": "ms sql",
      "licence": "yes",
      "remarks": "text"
    }
  ],
  "antiVirus": {
    "antiVirus": "type",
    "licence": "text",
    "expiryDate": "date"
  },
  "storage": {
    "Backupdate": "date",
    "sourcecodeDir": "",
    "sourcecodeDirSize": "",
    "backupTap": "yes",
    "backupToTapeOn": "date",
    "backupToTapeby": ""
  },
  "webapps": [
    ObjectId("5cbf83b1275b2f480d00002d")
  ],
  "SrNo": [
    
  ],
  "visits": [
    
  ],
  "comments": [
    {
      "commentId": "",
      "commentby": "",
      "date": "",
      "comment": ""
    },
    {
      "commentid": NumberInt(276495062),
      "commentby": "varun",
      "comment": "<p> dsad sadsa ds</p>\r\n",
      "date": "date"
    },
    {
      "commentid": NumberInt(907263900),
      "commentby": "varun",
      "comment": "<p> dsadasd sd</p>\r\n",
      "date": "date"
    }
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ],
  "clone": {
    "name": "",
    "date": "",
    "remarks": ""
  },
  "thirdParty": {
    "softwares": "dsadsa dsadsa dsad sa",
    "client_justification": " dsadsadsa ddsadsa sadsa",
    "remarks": "sadsadsadsadddsadsadassss"
  },
  "status": "online",
  "user_group": "SDC44dd"
});

/** VPN records **/

/** employee records **/
db.getCollection("employee").insert({
  "_id": ObjectId("5c268c9f5d5bac4417000029"),
  "name": "varun",
  "email": "varun@gmail.com",
  "password": "5f4dcc3b5aa765d61d8327deb882cf99",
  "DOB": "",
  "empid": "",
  "DOJ": "",
  "Plevel": "",
  "dept": "",
  "designation": "",
  "locked": NumberInt(0),
  "gender": "",
  "username": {
    "fname": "",
    "lname": ""
  }
});
db.getCollection("employee").insert({
  "_id": ObjectId("5ca564835d5bacc802000029"),
  "name": "chaitu",
  "email": "chaitu@gmail.com",
  "password": "5f4dcc3b5aa765d61d8327deb882cf99",
  "DOB": "",
  "empid": "",
  "DOJ": "",
  "Plevel": "",
  "dept": "",
  "designation": "",
  "locked": NumberInt(0),
  "gender": "",
  "username": {
    "fname": "",
    "lname": ""
  }
});
db.getCollection("employee").insert({
  "_id": ObjectId("5ca564995d5bacc80200002a"),
  "name": "ragesh",
  "email": "ragesh@gmail.com",
  "password": "5f4dcc3b5aa765d61d8327deb882cf99",
  "DOB": "",
  "empid": "",
  "DOJ": "",
  "Plevel": "",
  "dept": "",
  "designation": "",
  "locked": NumberInt(0),
  "gender": "",
  "username": {
    "fname": "",
    "lname": ""
  }
});

/** patches records **/

/** port records **/
db.getCollection("port").insert({
  "_id": ObjectId("5be5b876275b2f5016000044"),
  "portNo": "80",
  "portName": "http",
  "reqBy": "client",
  "reason": "test",
  "timePeriod": "1hr",
  "securityThreat": "sql injection",
  "from": "10.189.47.75",
  "to": "10.189.47.74"
});
db.getCollection("port").insert({
  "_id": ObjectId("5be5b8bd275b2f2011000031"),
  "portNo": "80",
  "portName": "http",
  "reqBy": "client",
  "reason": "test",
  "timePeriod": "1hr",
  "securityThreat": "sql injection",
  "from": "10.189.47.75",
  "to": "10.189.47.74"
});
db.getCollection("port").insert({
  "_id": ObjectId("5be5b8ce275b2f5016000045"),
  "portNo": "80",
  "portName": "http",
  "reqBy": "client",
  "reason": "test",
  "timePeriod": "1hr",
  "securityThreat": "sql injection",
  "from": "10.189.47.75",
  "to": "10.189.47.74"
});

/** shiftRegister records **/
db.getCollection("shiftRegister").insert({
  "_id": ObjectId("5be48768275b2f201100002e"),
  "date": "2018-11-08 00:00:01",
  "name": "varun",
  "shift": NumberInt(1),
  "Activities": [
    "dasdasda",
    "asdasdasd",
    "dasdasdasdas",
    "adsdasdsa"
  ],
  "comments": [
    {
      "commentBy": "varun",
      "date": ISODate("2018-11-08T18:58:48.0Z"),
      "comment": "sample comment"
    },
    {
      "commentBy": "varun",
      "date": ISODate("2018-11-08T18:58:48.0Z"),
      "comment": "sample comment 2"
    }
  ]
});
db.getCollection("shiftRegister").insert({
  "_id": ObjectId("5be4877f275b2fe40b00002f"),
  "date": "2018-11-09 00:00:12",
  "name": "nagesh",
  "shift": NumberInt(1),
  "Activities": [
    "dasdasda",
    "asdasdasd",
    "dasdasdasdas",
    "adsdasdsa"
  ],
  "comments": [
    {
      "commentBy": "varun",
      "date": ISODate("2018-11-08T18:59:11.0Z"),
      "comment": "sample comment"
    },
    {
      "commentBy": "varun",
      "date": ISODate("2018-11-08T18:59:11.0Z"),
      "comment": "sample comment 2"
    }
  ]
});
db.getCollection("shiftRegister").insert({
  "_id": ObjectId("5c0452f95d5bac4c04000029"),
  "date": "2018-11-19",
  "name": "nagesh",
  "shift": NumberInt(1),
  "Activities": [
    "dasdasda",
    "asdasdasd",
    "dasdasdasdas",
    "adsdasdsa"
  ],
  "comments": [
    {
      "commentBy": "varun",
      "date": ISODate("2018-11-08T18:59:11.0Z"),
      "comment": "sample comment"
    },
    {
      "commentBy": "varun",
      "date": ISODate("2018-11-08T18:59:11.0Z"),
      "comment": "sample comment 2"
    }
  ]
});

/** test records **/
db.getCollection("test").insert({
  "_id": ObjectId("5c48ed7f5d5bac881d000029"),
  "cloud": null,
  "serverName": null,
  "serverIp": "",
  "vms": [
    
  ],
  "hardware": {
    "ram": "",
    "HDD": "",
    "processor": ""
  },
  "SrNo": [
    
  ]
});

/** visits records **/
db.getCollection("visits").insert({
  "_id": ObjectId("5cc9b4bb5d5bacf01c000029"),
  "parent_collection": "ESXI",
  "parent_ID": ObjectId("5cbf2ef4275b2fe81c00002f"),
  "date": "1-5-2019",
  "from": "00:00:00",
  "to": "00:00:00",
  "VisitPurpose": "updatation of website",
  "dept": "database",
  "Visitors": [
    {
      "name": "varun",
      "designation": "DBA",
      "dept": "database",
      "mobile": 9292929292
    },
    {
      "name": "dilip",
      "designation": "sr eng",
      "dept": "database",
      "mobile": 9292929292
    }
  ],
  "signAnddate": "yes",
  "approvalByItg": {
    "nameOfTheApproving": "name",
    "signature&date": "yes",
    "Designation": "manager"
  },
  "approvalByDCO": {
    "nameOfTheApproving": "name",
    "signature&date": "yes",
    "Designation": "manager"
  },
  "comments": [
    {
      "commentid": NumberInt(325072968),
      "commentby": "varun",
      "comment": "<p>&nbsp;sasa SAsaS</p>\r\n",
      "date": "date"
    },
    {
      "commentid": NumberInt(513465395),
      "commentby": "varun",
      "comment": "<p>SAD SADSAD</p>\r\n",
      "date": "date"
    }
  ]
});

/** web records **/
db.getCollection("web").insert({
  "_id": ObjectId("5cbf83b1275b2f480d00002d"),
  "VM_ID": ObjectId("5cbf81a8275b2fd40b00002c"),
  "hostingDetails": {
    "hostingType": "staging",
    "date": "2019-04-10",
    "remark": "remarks if anyddd777777",
    "type": "777777",
    "status": "offline"
  },
  "type": "web applicationsss",
  "appName": "10.189.47.176/hmis/login.aspxssss",
  "deptname": "itipana77",
  "vendorDetails": {
    "vendor": "vendorNameddd",
    "contactPerson": "varun",
    "email": "email@email.comddd",
    "contactNo": "43243423432ddd",
    "designation": "developerddddd"
  },
  "connectivity": {
    "VPN": "VPN collection id",
    "RDP": "rdp collection id"
  },
  "url": "http://wenbsite.comsss",
  "auditCert": {
    "status": "1",
    "valid": "1",
    "validatedBy": "c4solutions",
    "issuedate": "2019-04-17",
    "expdate": "2019-04-19",
    "path": "639625344.pdf",
    "remark": "text"
  },
  "ssl": {
    "status": "1",
    "expiration": "2019-04-15"
  },
  "webServer": "apache88",
  "databaseSoftware": "mysqlssasa77",
  "visits": [
    
  ],
  "SrNo": [
    
  ],
  "comments": [
    
  ],
  "trackerLogs": [
    {
      "date": "date",
      "log": "mytrackerLogssql"
    }
  ]
});
