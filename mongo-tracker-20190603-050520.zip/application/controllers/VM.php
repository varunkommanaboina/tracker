<?php
	class VM extends CI_Controller{ 
		
		
				public function insert(){


							$this->form_validation->set_rules('web_name', 'web/app name', 'required');
							$this->form_validation->set_rules('vm_id', 'vm id', 'required');
							$this->form_validation->set_rules('type', 'type select', 'required');
							$current=$this->input->post('current'); 
							if($this->form_validation->run() === FALSE){
								redirect($current);
													 
							} else {
										$insert_type=$this->input->post('type'); 
										
										$id=$this->input->post('vm_id');
										$name= $this->input->post('web_name'); //ID or name
														if ($insert_type == "new"){
																	$data = array(
																		"VM_ID"=>new MongoId($id),
																		"hostingDetails"=>(object)array(
																				"hostingType"=>"staging",
																				"date"=>"date",
																				"remark"=>"remarks if any",
																				"status"=>""
																		),
																		"type"=>"web application",
																		"appName"=>$name,
																		"deptname"=>"itipanaji",
																		"vendorDetails"=>(object)array(
																				"vendor"=>"vendorName",
																				"contactPerson"=>"text",
																				"email"=>"email@email.com",
																				"contactNo"=>"43243423432",
																				"designation"=>"developer",
																						),
																		"connectivity"=>(object)array(
																				"VPN"=>"VPN collection id",
																				"RDP"=>"rdp collection id"
																			),
																		"url"=>"http://wenbsite.com",
																		"auditCert"=>(object)array(
																				"status"=>"0",
																				"valid"=> "0",
																				"validatedBy"=>"company",
																				"issuedate"=>"date",
																				"expdate"=>"date",
																				"path"=>"soft copy path",
																				"remark"=>"text"
																		),
																		"ssl"=>(object)array(
																			"status"=>"0",
																			"expiration"=>""
																		),
																		"webServer"=>"apache",
																		"databaseSoftware"=>"mysql",
																		"visits"=>array(),
																		"SrNo"=>array(),
																		
																		"comments"=>(object)array(),
																		"trackerLogs"=>(object)array(
																			(object)array(
																				"date"=>"date",
																				"log"=>"mytrackerLogssql",
																			)
																		)
														
																);
					 											 
																$insert_id=$this->collection->insert('web',$data);//create new web doc
																
																$where=array('_id'=>new MongoId($id));
																$this->collection->push($insert_id,'VM',$where,'webapps'); //push newly created web Doc ID to VM apps array

																// Set message
																$this->session->set_flashdata('added_VM', 'esxi server is created');
																redirect($current);
													
															}else if ($insert_type == "migrate"){
																
																$result= $this->mongo_db->select(array('webapps'))->where(array('_id' => new MongoId($id)))->get('VM');
																if(in_array(new MongoId($name),$result[0]['webapps'])){
																	redirect('alredy exist $current');
																}else{
																		$where=array('_id'=>new MongoId($id));
																		$this->collection->push(new MongoId($name),'VM',$where,'webapps'); 
																		// Set message
																		$this->session->set_flashdata('added_VM', 'esxi server is created');
																		redirect($current);
																}

																


															}
									}


					}

					public function edit_basic(){
						//$this->form_validation->set_rules('cloud', 'cloud', 'required');
						$this->form_validation->set_rules('vm_function', 'Vm function', 'required');
						$this->form_validation->set_rules('vm_name', 'Vm name', 'required');
						$this->form_validation->set_rules('type', 'server type', 'required');

						
						if($this->form_validation->run() === FALSE){

														
						} else {

							$id=$this->input->post('vm_id');
							$current=$this->input->post('current');                        
							$data=array(
							'VMFunction' => $this->input->post('vm_function'),
							'hostName' => $this->input->post('vm_name'),
							'serverType' => $this->input->post('type'),
							'user_group' => $this->input->post('ugroup'),
							'status' => $this->input->post('vm_status'),

							);
							$where =array('_id'=>new MongoId($id));
							$this->collection->edit($where,$data,'VM');
							// Set message
							$this->session->set_flashdata('added_VM', 'esxi server is created');
							redirect($current);
							
						}



                }  
                



                public function edit_clone(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
					$this->form_validation->set_rules('c_name', 'clone name', 'required');
                    $this->form_validation->set_rules('c_date', 'clone date', 'required');
                    $this->form_validation->set_rules('remark', 'remark', 'required');

					
					if($this->form_validation->run() === FALSE){

													
					} else {

                        $id=$this->input->post('vm_id');
                        $current=$this->input->post('current');                        
						$data=array(
						'clone.name' => $this->input->post('c_name'),
						'clone.date' => $this->input->post('c_date'),
						'clone.remarks' => $this->input->post('remark')          
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'VM');
						// Set message
						$this->session->set_flashdata('added_VM', 'esxi server is created');
						redirect($current);
						
					}



				} 

				public function edit_hardware(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
					$this->form_validation->set_rules('ram', 'RAM', 'required');
                    $this->form_validation->set_rules('hdd', 'HDD', 'required');
                    $this->form_validation->set_rules('processor', 'Processor', 'required');

					
					if($this->form_validation->run() === FALSE){

													
					} else {

                        $id=$this->input->post('vm_id');
                        $current=$this->input->post('current');                        
						$data=array(
						'vHardware.ram' => $this->input->post('ram'),
						'vHardware.HDD' => $this->input->post('hdd'),
						'vHardware.processor' => $this->input->post('processor'),
						'vHardware.remark' => $this->input->post('hardware_remark'),
						'vHardware.HDD_Utilized' => $this->input->post('hdd_uti')


						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'VM');
						// Set message
						$this->session->set_flashdata('added_VM', 'esxi server is created');
						redirect($current);
						
					}



                } 
                


                public function edit_software_info(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
                    $this->form_validation->set_rules('os', 'operating system', 'required');
                    $this->form_validation->set_rules('antivirus', 'antivirus', 'required');
                    $this->form_validation->set_rules('licence', 'licence', 'required');
                    $this->form_validation->set_rules('date', 'date', 'required');
                   

					
					if($this->form_validation->run() === FALSE){

													
					} else {

                        $id=$this->input->post('vm_id');
                        $current=$this->input->post('current');                         
						$data=array(
                        'os' => $this->input->post('os'),
                        'antiVirus.antiVirus' => $this->input->post('antivirus'),
                        'antiVirus.licence' => $this->input->post('licence'),
                        'antiVirus.expiryDate' => $this->input->post('date')

						       
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'VM');
						// Set message
						$this->session->set_flashdata('added_VM', 'esxi server is created');
						redirect($current);
						
					}



				} 



				public function additional_soft(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
                   
					$this->form_validation->set_rules('soft', 'should not be null', 'required');
					$current=$this->input->post('current');
					
					if($this->form_validation->run() === FALSE){
						
													
					} else {

                        $id=$this->input->post('vm_id');
                                                 
						$data=array(
                        'thirdParty.softwares' => $this->input->post('soft'),
                        'thirdParty.client_justification' => $this->input->post('just'),
                        'thirdParty.remarks' => $this->input->post('remarks')
                       

						       
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'VM');
						// Set message
						$this->session->set_flashdata('added_VM', 'esxi server is created');
						redirect($current);
						
					}



				} 


				public function edit_network_info(){
					//$this->form_validation->set_rules('cloud', 'cloud', 'required');
               
                    $this->form_validation->set_rules('private_ip', 'private ip', 'required');
					
                   
                   
 
					
					if($this->form_validation->run() === FALSE){
						
													
					} else {

                        $id=$this->input->post('vm_id');
                        $current=$this->input->post('current');                        
						$data=array(
                        'ips.public' => $this->input->post('public_ip'),
                        'ips.private' => $this->input->post('private_ip'),
                        'ips.gateway' => $this->input->post('gateway_ip'),
                        'internet' => $this->input->post('internet')

						       
						);
						$where =array('_id'=>new MongoId($id));
						$this->collection->edit($where,$data,'VM');
						// Set message
						$this->session->set_flashdata('added_VM', 'esxi server is created');
						redirect($current);
						
					}



				}

				public function ports(){
					$data['id_original']=$this->uri->segment(3, 0);

					$select=array('port','VMFunction');
					$deselect=array();
					$where=array('_id' => new MongoId($data['id_original']));
					$order=array();
					$data['data']=$this->collection->get('VM', $where,$select,$deselect,$order);
					$title['title']='Network VM Ports';

					
					$this->load->view('main_pages/template/header',$title);
					$this->load->view('main_pages/ports', $data);
					$this->load->view('main_pages/template/footer');


				}

				public function delete_port(){
					$current=$this->input->post('current');

					$this->mongo_db->where('_id',new MongoId($this->input->post('id')))->pull('port',array('portNo'=>$this->input->post('port')))->update('VM');

					redirect($current);
				}



				public function add_port(){

						$current=$this->input->post('current');
						$id=$this->input->post('id');

										
					$data = array(
							"portNo"=>$this->input->post('p_number'),
							"portName"=>$this->input->post('port_name'),
							"reqBy"=>$this->input->post('r_by'),
							"reason"=>$this->input->post('reason'),
							"timePeriod"=>$this->input->post('description'),
							"securityThreat"=>$this->input->post('threat'),
							"from"=>$this->input->post('from'),
							"to"=>$this->input->post('to'),
							"remark"=>$this->input->post('remark')
					);

					//to delete if the same port exist
					$this->mongo_db->where('_id',new MongoId($id))->pull('port',array('portNo'=>$this->input->post('p_number')))->update('VM');
					// to add the port if dosent exist
					$this->mongo_db->push('port',$data)->where('_id',new MongoId($id))->update('VM');


					redirect($current);

				}

				public function rds(){
					$data['id_original']=$this->uri->segment(3, 0);

					$select=array('RDlogins','VMFunction');
					$deselect=array();
					$where=array('_id' => new MongoId($data['id_original']));
					$order=array();
					$data['data']=$this->collection->get('VM', $where,$select,$deselect,$order);
					$title['title']='Remote desktop logins';

					
					$this->load->view('main_pages/template/header',$title);
					$this->load->view('main_pages/rd', $data);
					$this->load->view('main_pages/template/footer');


				}



				public function delete_rd(){
					$current=$this->input->post('current');

					$this->mongo_db->where('_id',new MongoId($this->input->post('id')))->pull('RDlogins',array('rdno'=>$this->input->post('rd')))->update('VM');

					redirect($current);
				}



				public function add_rd(){

						$current=$this->input->post('current');
						$id=$this->input->post('id');

										
					$data = array(
							"rdno"=>''.mt_rand(100000000,1000000000).'',
							"rdName"=>$this->input->post('rd_login'),
							"reqBy"=>$this->input->post('reqby'),
							"reason"=>$this->input->post('reason'),
							"remark"=>$this->input->post('remark')
					);

					//to delete if the same port exist
				
					// to add the port if dosent exist
					$this->mongo_db->push('RDlogins',$data)->where('_id',new MongoId($id))->update('VM');


					redirect($current);

				}
						
    }   
