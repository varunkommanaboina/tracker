
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/DataTables/datatables.min.css"/>
 
<script type="text/javascript" src="<?php echo base_url(); ?>assets/DataTables/datatables.min.js"></script>


<table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Extn.</th>
                <th>Start date</th>
                <th>Salary</th>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Extn.</th>
                <th>Start date</th>
                <th>Salary</th>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Extn.</th>
                <th>Start date</th>
                <th>Salary</th>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Extn.</th>
                <th>Start date</th>
                <th>Salary</th>
            </tr>
        </thead>
       
    </table>



<script>
$(document).ready(function() {
    $('#example').DataTable( {
        "ajax": "<?php echo base_url(); ?>test/data_tables1",
        "columns": [
            { "data": "url" },
            { "data": "deptnmae" },
            { "data": "vendorDetails.vendor" },
            { "data": "hostingDetails.hostingType" },
            { "data": "ssl.status" },
            { "data": "auditCert.status" },
            { "data": "url" },
            { "data": "deptnmae" },
            { "data": "vendorDetails.vendor" },
            { "data": "hostingDetails.hostingType" },
            { "data": "ssl.status" },
            { "data": "auditCert.status" },
            { "data": "url" },
            { "data": "deptnmae" },
            { "data": "vendorDetails.vendor" },
            { "data": "hostingDetails.hostingType" },
            { "data": "ssl.status" },
            { "data": "auditCert.status" },
            { "data": "url" },
            { "data": "deptnmae" },
            { "data": "vendorDetails.vendor" },
            { "data": "hostingDetails.hostingType" },
            { "data": "ssl.status" },
            { "data": "auditCert.status" },
         
        ]
    } );
} );

</script>
</div>